"""
Database models for Quotaible platform
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.dialects.postgresql import JSON
from flask_login import UserMixin # <--- FIXED: ADDED FOR FLASK-LOGIN
import uuid

# Initialize SQLAlchemy
db = SQLAlchemy()

class Company(db.Model):
    """Company model for service-based businesses"""
    __tablename__ = 'companies'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    website = db.Column(db.String(255))
    business_type = db.Column(db.String(100))  # e.g., 'plumbing', 'electrical'
    
    # Branding settings
    branding_settings = db.Column(JSON, default=dict)  # colors, logo_url, theme, etc.
    
    # Subscription and features
    subscription_plan = db.Column(db.String(50), default='basic')
    features_enabled = db.Column(JSON, default=dict)  # AI bot, analytics, etc.
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    employees = db.relationship('Employee', backref='company', lazy=True, cascade='all, delete-orphan')
    inquiries = db.relationship('Inquiry', backref='company', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'website': self.website,
            'business_type': self.business_type,
            'branding_settings': self.branding_settings or {},
            'subscription_plan': self.subscription_plan,
            'features_enabled': self.features_enabled or {},
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Employee(db.Model, UserMixin): # <--- FIXED: Inherits UserMixin
    """Employee model with role-based access"""
    __tablename__ = 'employees'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    
    # Personal information
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)
    phone = db.Column(db.String(20))
    
    # Authentication
    password_hash = db.Column(db.String(255), nullable=False)
    two_fa_secret = db.Column(db.String(32))  # For TOTP 2FA
    backup_codes = db.Column(db.Text)  # Comma-separated hashed backup codes
    
    # Role and permissions
    role = db.Column(db.String(50), nullable=False)  # 'admin', 'manager', 'employee'
    is_active = db.Column(db.Boolean, default=True)
    privileges = db.Column(JSON, default=dict)  # Custom privileges
    
    # Work-related fields
    hourly_rate = db.Column(db.Numeric(10, 2))
    specializations = db.Column(JSON, default=list)  # List of job types they handle
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationships
    inquiries_assigned = db.relationship('Inquiry', backref='assigned_employee', lazy=True)
    quotes_created = db.relationship('Quote', backref='created_by_employee', lazy=True)
    appointments = db.relationship('Appointment', backref='assigned_employee', lazy=True)
    ai_interactions = db.relationship('AIInteraction', backref='employee', lazy=True)
    
    def set_password(self, password):
        """Hash and set password"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if provided password matches hash"""
        return check_password_hash(self.password_hash, password)
    
    # Required by Flask-Login (implicitly provided by UserMixin, but good to ensure it's inherited)
    # def get_id(self):
    #     return str(self.id)
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'role': self.role,
            'is_active': self.is_active,
            'privileges': self.privileges or {},
            'hourly_rate': str(self.hourly_rate) if self.hourly_rate else None,
            'specializations': self.specializations or [],
            'has_2fa': bool(self.two_fa_secret),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }

class Inquiry(db.Model):
    """Customer inquiry model"""
    __tablename__ = 'inquiries'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    assigned_employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'))
    
    # Customer information
    customer_name = db.Column(db.String(255), nullable=False)
    customer_email = db.Column(db.String(255), nullable=False)
    customer_phone = db.Column(db.String(20))
    customer_address = db.Column(db.Text)
    
    # Inquiry details
    job_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    urgency = db.Column(db.String(20), default='normal')  # 'low', 'normal', 'high', 'emergency'
    preferred_date = db.Column(db.Date)
    preferred_time = db.Column(db.String(50))
    
    # Status and tracking
    status = db.Column(db.String(50), default='new')  # 'new', 'in_progress', 'quoted', 'scheduled', 'completed', 'cancelled'
    source = db.Column(db.String(50))  # 'website', 'phone', 'referral', 'plugin'
    
    # Media
    images_urls = db.Column(JSON, default=list)  # List of image URLs
    
    # Response tracking
    response_time = db.Column(db.Integer)  # In minutes
    first_response_at = db.Column(db.DateTime)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    quotes = db.relationship('Quote', backref='inquiry', lazy=True, cascade='all, delete-orphan')
    appointments = db.relationship('Appointment', backref='inquiry', lazy=True, cascade='all, delete-orphan')
    ai_interactions = db.relationship('AIInteraction', backref='inquiry', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'assigned_employee_id': self.assigned_employee_id,
            'customer_name': self.customer_name,
            'customer_email': self.customer_email,
            'customer_phone': self.customer_phone,
            'customer_address': self.customer_address,
            'job_type': self.job_type,
            'description': self.description,
            'urgency': self.urgency,
            'preferred_date': self.preferred_date.isoformat() if self.preferred_date else None,
            'preferred_time': self.preferred_time,
            'status': self.status,
            'source': self.source,
            'images_urls': self.images_urls or [],
            'response_time': self.response_time,
            'first_response_at': self.first_response_at.isoformat() if self.first_response_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class Quote(db.Model):
    """Quote model for customer estimates"""
    __tablename__ = 'quotes'
    
    id = db.Column(db.Integer, primary_key=True)
    inquiry_id = db.Column(db.Integer, db.ForeignKey('inquiries.id'), nullable=False)
    created_by_employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    
    # Quote details
    quote_number = db.Column(db.String(50), unique=True, nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    
    # Financial information
    labor_cost = db.Column(db.Numeric(10, 2), default=0)
    materials_cost = db.Column(db.Numeric(10, 2), default=0)
    additional_costs = db.Column(db.Numeric(10, 2), default=0)
    tax_amount = db.Column(db.Numeric(10, 2), default=0)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    
    # Timeline
    estimated_duration = db.Column(db.String(100))  # e.g., "2-3 hours", "1 day"
    valid_until = db.Column(db.Date)
    
    # Status
    status = db.Column(db.String(50), default='draft')  # 'draft', 'sent', 'accepted', 'declined', 'expired'
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sent_at = db.Column(db.DateTime)
    accepted_at = db.Column(db.DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'inquiry_id': self.inquiry_id,
            'created_by_employee_id': self.created_by_employee_id,
            'quote_number': self.quote_number,
            'title': self.title,
            'description': self.description,
            'labor_cost': str(self.labor_cost) if self.labor_cost else '0.00',
            'materials_cost': str(self.materials_cost) if self.materials_cost else '0.00',
            'additional_costs': str(self.additional_costs) if self.additional_costs else '0.00',
            'tax_amount': str(self.tax_amount) if self.tax_amount else '0.00',
            'total_amount': str(self.total_amount),
            'estimated_duration': self.estimated_duration,
            'valid_until': self.valid_until.isoformat() if self.valid_until else None,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'accepted_at': self.accepted_at.isoformat() if self.accepted_at else None
        }

class Appointment(db.Model):
    """Appointment scheduling model"""
    __tablename__ = 'appointments'
    
    id = db.Column(db.Integer, primary_key=True)
    inquiry_id = db.Column(db.Integer, db.ForeignKey('inquiries.id'), nullable=False)
    assigned_employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    
    # Appointment details
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text)
    
    # Scheduling
    scheduled_date = db.Column(db.Date, nullable=False)
    scheduled_time = db.Column(db.Time, nullable=False)
    estimated_duration = db.Column(db.Integer)  # In minutes
    
    # Location
    location = db.Column(db.Text)  # Customer address or job site
    
    # Status
    status = db.Column(db.String(50), default='scheduled')  # 'scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'rescheduled'
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime)
    
    def to_dict(self):
        return {
            'id': self.id,
            'inquiry_id': self.inquiry_id,
            'assigned_employee_id': self.assigned_employee_id,
            'title': self.title,
            'description': self.description,
            'scheduled_date': self.scheduled_date.isoformat() if self.scheduled_date else None,
            'scheduled_time': self.scheduled_time.isoformat() if self.scheduled_time else None,
            'estimated_duration': self.estimated_duration,
            'location': self.location,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

class AIInteraction(db.Model):
    """AI chat interaction model"""
    __tablename__ = 'ai_interactions'
    
    id = db.Column(db.Integer, primary_key=True)
    inquiry_id = db.Column(db.Integer, db.ForeignKey('inquiries.id'), nullable=False)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'))
    
    # Interaction details
    interaction_type = db.Column(db.String(50), nullable=False)  # 'chat', 'quote_generation', 'analysis'
    user_message = db.Column(db.Text)
    ai_response = db.Column(db.Text)
    
    # Metadata
    model_used = db.Column(db.String(100))
    tokens_used = db.Column(db.Integer)
    processing_time = db.Column(db.Integer)  # In milliseconds
    
    # Security and validation
    input_sanitized = db.Column(db.Boolean, default=False)
    contains_sensitive_data = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'inquiry_id': self.inquiry_id,
            'employee_id': self.employee_id,
            'interaction_type': self.interaction_type,
            'user_message': self.user_message,
            'ai_response': self.ai_response,
            'model_used': self.model_used,
            'tokens_used': self.tokens_used,
            'processing_time': self.processing_time,
            'input_sanitized': self.input_sanitized,
            'contains_sensitive_data': self.contains_sensitive_data,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
