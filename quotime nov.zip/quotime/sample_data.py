"""
Sample data initialization for Quotaible platform
"""
from datetime import datetime, date, timedelta
from models import db, Company, Employee, Inquiry, Quote, Appointment, AIInteraction
from werkzeug.security import generate_password_hash

def init_sample_data():
    """Initialize database with sample data - SAFE VERSION"""
    
    # DO NOT drop tables - this is unsafe!
    # Only insert data if tables are empty
    if Company.query.count() > 0:
        print("Sample data already exists, skipping initialization")
        return
    
    # Create sample companies
    company1 = Company(
        name='Elite Plumbing Services',
        email='contact@eliteplumbing.com',
        phone='(555) 123-4567',
        address='123 Main St, Anytown, USA 12345',
        website='https://eliteplumbing.com',
        business_type='plumbing',
        branding_settings={
            'primary_color': '#2563eb',
            'secondary_color': '#64748b',
            'logo_url': '/assets/elite-plumbing-logo.png',
            'theme': 'professional'
        },
        subscription_plan='premium',
        features_enabled={
            'ai_bot': True,
            'analytics': True,
            'advanced_scheduling': True,
            'custom_branding': True
        }
    )
    
    company2 = Company(
        name='Spark Electric Solutions',
        email='info@sparkelectric.com',
        phone='(555) 987-6543',
        address='456 Oak Ave, Somewhere, USA 67890',
        website='https://sparkelectric.com',
        business_type='electrical',
        branding_settings={
            'primary_color': '#dc2626',
            'secondary_color': '#374151',
            'logo_url': '/assets/spark-electric-logo.png',
            'theme': 'modern'
        },
        subscription_plan='basic',
        features_enabled={
            'ai_bot': False,
            'analytics': True,
            'advanced_scheduling': False,
            'custom_branding': False
        }
    )
    
    db.session.add_all([company1, company2])
    db.session.commit()
    
    # Create sample employees
    admin = Employee(
        company_id=company1.id,
        name='System Admin',
        email='admin@quotime.com',
        phone='(555) 000-0001',
        role='admin',
        is_active=True,
        privileges={
            'manage_all_companies': True,
            'system_settings': True,
            'billing_management': True,
            'feature_toggles': True
        }
    )
    admin.set_password('admin123')
    
    manager1 = Employee(
        company_id=company1.id,
        name='John Manager',
        email='john@eliteplumbing.com',
        phone='(555) 123-4568',
        role='manager',
        is_active=True,
        hourly_rate=75.00,
        specializations=['management', 'customer_relations'],
        privileges={
            'view_analytics': True,
            'manage_employees': True,
            'approve_quotes': True,
            'schedule_appointments': True
        }
    )
    manager1.set_password('manager123')
    
    employee1 = Employee(
        company_id=company1.id,
        name='Mike Worker',
        email='mike@eliteplumbing.com',
        phone='(555) 123-4569',
        role='employee',
        is_active=True,
        hourly_rate=45.00,
        specializations=['drain_cleaning', 'pipe_repair', 'emergency_service'],
        privileges={
            'view_assigned_jobs': True,
            'update_job_status': True,
            'create_quotes': True
        }
    )
    employee1.set_password('employee123')
    
    manager2 = Employee(
        company_id=company2.id,
        name='Sarah Electric',
        email='sarah@sparkelectric.com',
        phone='(555) 987-6544',
        role='manager',
        is_active=True,
        hourly_rate=80.00,
        specializations=['electrical_systems', 'commercial_work'],
        privileges={
            'view_analytics': True,
            'manage_employees': True,
            'approve_quotes': True,
            'schedule_appointments': True
        }
    )
    manager2.set_password('manager456')
    
    employee2 = Employee(
        company_id=company2.id,
        name='Tom Electrician',
        email='tom@sparkelectric.com',
        phone='(555) 987-6545',
        role='employee',
        is_active=True,
        hourly_rate=50.00,
        specializations=['residential_wiring', 'outlet_installation', 'lighting'],
        privileges={
            'view_assigned_jobs': True,
            'update_job_status': True,
            'create_quotes': True
        }
    )
    employee2.set_password('employee456')
    
    db.session.add_all([admin, manager1, employee1, manager2, employee2])
    db.session.commit()
    
    # Create sample inquiries
    inquiry1 = Inquiry(
        company_id=company1.id,
        assigned_employee_id=employee1.id,
        customer_name='Robert Johnson',
        customer_email='robert.johnson@email.com',
        customer_phone='(555) 234-5678',
        customer_address='789 Pine St, Cityville, USA 11111',
        job_type='drain_cleaning',
        description='Kitchen sink is completely clogged. Water backing up into dishwasher.',
        urgency='high',
        preferred_date=date.today() + timedelta(days=1),
        preferred_time='morning',
        status='in_progress',
        source='website',
        images_urls=['/uploads/clogged-sink-1.jpg', '/uploads/clogged-sink-2.jpg'],
        response_time=45,
        first_response_at=datetime.utcnow() - timedelta(minutes=45)
    )
    
    inquiry2 = Inquiry(
        company_id=company1.id,
        assigned_employee_id=employee1.id,
        customer_name='Lisa Thompson',
        customer_email='lisa.thompson@email.com',
        customer_phone='(555) 345-6789',
        customer_address='321 Elm St, Townsburg, USA 22222',
        job_type='pipe_repair',
        description='Leaking pipe under bathroom sink. Small but constant drip.',
        urgency='normal',
        preferred_date=date.today() + timedelta(days=3),
        preferred_time='afternoon',
        status='quoted',
        source='phone',
        response_time=120,
        first_response_at=datetime.utcnow() - timedelta(hours=2)
    )
    
    inquiry3 = Inquiry(
        company_id=company2.id,
        assigned_employee_id=employee2.id,
        customer_name='David Wilson',
        customer_email='david.wilson@email.com',
        customer_phone='(555) 456-7890',
        customer_address='654 Maple Ave, Villageton, USA 33333',
        job_type='outlet_installation',
        description='Need 3 new outlets installed in home office. No existing wiring.',
        urgency='low',
        preferred_date=date.today() + timedelta(days=7),
        preferred_time='any',
        status='new',
        source='plugin',
        response_time=None,
        first_response_at=None
    )
    
    inquiry4 = Inquiry(
        company_id=company2.id,
        assigned_employee_id=employee2.id,
        customer_name='Maria Garcia',
        customer_email='maria.garcia@email.com',
        customer_phone='(555) 567-8901',
        customer_address='987 Cedar Rd, Hamletville, USA 44444',
        job_type='lighting',
        description='Replace all ceiling lights in 3-bedroom house with LED fixtures.',
        urgency='normal',
        preferred_date=date.today() + timedelta(days=5),
        preferred_time='weekend',
        status='scheduled',
        source='referral',
        response_time=30,
        first_response_at=datetime.utcnow() - timedelta(minutes=30)
    )
    
    db.session.add_all([inquiry1, inquiry2, inquiry3, inquiry4])
    db.session.commit()
    
    # Create sample quotes
    quote1 = Quote(
        inquiry_id=inquiry2.id,
        created_by_employee_id=employee1.id,
        quote_number='Q-001-2025',
        title='Bathroom Sink Pipe Repair',
        description='Replace leaking pipe section under bathroom sink. Includes new connecting hardware.',
        labor_cost=120.00,
        materials_cost=35.50,
        additional_costs=0.00,
        tax_amount=12.44,
        total_amount=167.94,
        estimated_duration='2-3 hours',
        valid_until=date.today() + timedelta(days=30),
        status='sent',
        sent_at=datetime.utcnow() - timedelta(hours=1)
    )
    
    quote2 = Quote(
        inquiry_id=inquiry4.id,
        created_by_employee_id=employee2.id,
        quote_number='Q-002-2025',
        title='LED Lighting Installation - 3 Bedroom House',
        description='Complete LED fixture replacement in all bedrooms, living areas, and common spaces.',
        labor_cost=480.00,
        materials_cost=285.75,
        additional_costs=50.00,
        tax_amount=65.48,
        total_amount=881.23,
        estimated_duration='1 full day',
        valid_until=date.today() + timedelta(days=45),
        status='accepted',
        sent_at=datetime.utcnow() - timedelta(days=2),
        accepted_at=datetime.utcnow() - timedelta(days=1)
    )
    
    db.session.add_all([quote1, quote2])
    db.session.commit()
    
    # Create sample appointments
    appointment1 = Appointment(
        inquiry_id=inquiry4.id,
        assigned_employee_id=employee2.id,
        title='LED Lighting Installation',
        description='Install LED fixtures throughout house as per accepted quote Q-002-2025',
        scheduled_date=date.today() + timedelta(days=5),
        scheduled_time=datetime.strptime('09:00', '%H:%M').time(),
        estimated_duration=480,  # 8 hours
        location='987 Cedar Rd, Hamletville, USA 44444',
        status='confirmed'
    )
    
    appointment2 = Appointment(
        inquiry_id=inquiry1.id,
        assigned_employee_id=employee1.id,
        title='Emergency Drain Cleaning',
        description='Clear kitchen sink blockage and inspect dishwasher connection',
        scheduled_date=date.today() + timedelta(days=1),
        scheduled_time=datetime.strptime('10:30', '%H:%M').time(),
        estimated_duration=120,  # 2 hours
        location='789 Pine St, Cityville, USA 11111',
        status='scheduled'
    )
    
    db.session.add_all([appointment1, appointment2])
    db.session.commit()
    
    # Create sample AI interactions
    ai_interaction1 = AIInteraction(
        inquiry_id=inquiry1.id,
        employee_id=employee1.id,
        interaction_type='analysis',
        user_message='Analyze this drain cleaning job for time and complexity estimates',
        ai_response='Based on the description and images, this appears to be a standard kitchen drain blockage. Estimated time: 1-2 hours. Complexity: Medium. Recommend bringing drain snake and checking garbage disposal connection.',
        model_used='gpt-4',
        tokens_used=156,
        processing_time=1200,
        input_sanitized=True,
        contains_sensitive_data=False
    )
    
    ai_interaction2 = AIInteraction(
        inquiry_id=inquiry4.id,
        employee_id=employee2.id,
        interaction_type='quote_generation',
        user_message='Generate quote for LED lighting installation in 3-bedroom house',
        ai_response='Quote generated: Labor $480 (8 hours @ $60/hr), Materials $285.75 (15 LED fixtures + hardware), Total with tax: $881.23. Timeline: 1 full day installation.',
        model_used='gpt-4',
        tokens_used=203,
        processing_time=1800,
        input_sanitized=True,
        contains_sensitive_data=False
    )
    
    db.session.add_all([ai_interaction1, ai_interaction2])
    db.session.commit()
    
    print("Sample data initialized successfully!")
    print("\nLogin Credentials:")
    print("Admin: admin@quotime.com / admin123")
    print("Manager 1: john@eliteplumbing.com / manager123")
    print("Employee 1: mike@eliteplumbing.com / employee123")
    print("Manager 2: sarah@sparkelectric.com / manager456")
    print("Employee 2: tom@sparkelectric.com / employee456")
    
    return {
        'companies': [company1, company2],
        'employees': [admin, manager1, employee1, manager2, employee2],
        'inquiries': [inquiry1, inquiry2, inquiry3, inquiry4],
        'quotes': [quote1, quote2],
        'appointments': [appointment1, appointment2],
        'ai_interactions': [ai_interaction1, ai_interaction2]
    }