# Quotaible - B2B SaaS Platform for Service Companies

## Overview

Quotaible is a comprehensive B2B SaaS platform designed for service-based companies (plumbers, electricians, HVAC technicians) to manage client inquiries, automate quote generation, track appointments, and analyze performance. It features a unified backend API serving both web and mobile frontends, robust authentication, role-based access control, and AI-powered customer interaction capabilities, supporting multiple subscription tiers and detailed analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

Quotaible utilizes a unified backend API built with Flask/Python, SQLAlchemy ORM, and PostgreSQL. It incorporates JWT-based authentication with optional TOTP 2FA, password hashing, and role-based access control. The system manages core data models for Company, Employee, Inquiry, Quote, Appointment, and AIInteraction.

The frontend consists of a React web application and a React Native mobile application, both developed with TypeScript and styled using Chakra UI v2. The UI adopts a professional light theme with blue (#3B82F6) accents, card-based layouts, subtle shadows, and smooth transitions. Key UI/UX decisions include consistent component usage, a white/gray background scheme, and responsive layouts.

Features include a functional dashboard with charts (employee performance, revenue trends, conversion funnel), comprehensive inquiry management (status filtering, search, detail modals, employee assignment), and a public customer-facing inquiry form. Authentication uses a three-tier role system (Admin, Manager, Employee) with granular permissions. API endpoints cover user authentication, inquiry management, analytics, admin controls, and AI chat integration. Data security is prioritized with encryption, input sanitization, and secure handling of sensitive information.

## External Dependencies

### Backend Dependencies
- **Flask Ecosystem**: Flask, Flask-JWT-Extended, Flask-CORS, Flask-Migrate, Flask-SQLAlchemy
- **Security**: Werkzeug, pyotp, qrcode
- **Database**: PostgreSQL

### Frontend Dependencies
- **Web**: React, React Router DOM, Axios, Lucide React, Recharts
- **Mobile**: React Native, Expo CLI, React Navigation, Expo SecureStore, AsyncStorage
- **Development**: TypeScript, Vite, ESLint

### Infrastructure Requirements
- **Database**: PostgreSQL instance
- **Environment**: Node.js, Python 3.8+
- **Security**: Environment variables for secrets

### Optional Services
- **AI Integration**: External AI service (e.g., OpenAI, Anthropic Claude, Google Gemini)
- **Email/SMS**: Third-party communication services
- **Payment Processing**: Subscription and billing integration