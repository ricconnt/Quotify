# Two-Factor Authentication (2FA) Configuration Guide

## ⚠️ CURRENT STATUS: DISABLED BY DEFAULT

Two-Factor Authentication (2FA) is **fully implemented** in the backend but **DISABLED by default** to ensure zero friction during initial setup and testing.

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Current Implementation](#current-implementation)
3. [How to Enable 2FA](#how-to-enable-2fa)
4. [How to Disable 2FA](#how-to-disable-2fa)
5. [User Enrollment Flow](#user-enrollment-flow)
6. [Testing 2FA](#testing-2fa)
7. [Backup Codes](#backup-codes)
8. [Troubleshooting](#troubleshooting)

---

## 🔐 Overview

Quotaible includes enterprise-grade Two-Factor Authentication using:
- **TOTP (Time-based One-Time Password)** - Compatible with Google Authenticator, Authy, 1Password, etc.
- **Backup Codes** - 5 secure one-time recovery codes per user
- **QR Code Generation** - Easy setup via QR code scanning

### Security Features:
✅ SHA-256 hashed backup codes with unique salts  
✅ 30-second TOTP validity windows  
✅ Secure backup code verification and auto-expiry  
✅ Optional 2FA per user (not enforced globally)

---

## 📂 Current Implementation

### Backend Code Location:
- **Main Implementation**: `app.py` (lines 45-293)
- **Database Models**: `models.py` - `Employee` model
- **Dependencies**: `pyotp`, `qrcode`, `hashlib` (already installed)

### API Endpoints (Already Implemented):
```
POST /api/auth/setup-2fa        # Generate QR code and secret
POST /api/auth/verify-2fa       # Verify TOTP code and generate backup codes
POST /api/auth/login            # Login with optional 2FA verification
```

### Database Fields (Already Created):
```python
# In Employee model (models.py)
two_fa_secret = db.Column(db.String(32))  # TOTP secret key
backup_codes = db.Column(db.Text)         # Hashed backup codes (comma-separated)
```

---

## 🚀 How to Enable 2FA

### Method 1: Environment Variable (Recommended)

**Step 1:** Add to `.env` file:
```bash
# .env
ENABLE_2FA=true                    # Enable 2FA feature globally
REQUIRE_2FA_FOR_ADMINS=false       # Optional: Enforce for admin users only
```

**Step 2:** Update `config.py`:
```python
# config.py
import os

class Config:
    # ... existing config ...
    
    # 2FA Configuration
    ENABLE_2FA = os.environ.get('ENABLE_2FA', 'false').lower() == 'true'
    REQUIRE_2FA_FOR_ADMINS = os.environ.get('REQUIRE_2FA_FOR_ADMINS', 'false').lower() == 'true'
```

**Step 3:** Update `app.py` to check feature flag:
```python
# In app.py, modify setup-2fa endpoint (around line 220)
@app.route('/api/auth/setup-2fa', methods=['POST'])
@jwt_required()
def setup_2fa():
    # ADD THIS CHECK AT THE START:
    if not app.config.get('ENABLE_2FA', False):
        return jsonify({'error': '2FA is not enabled on this system'}), 403
    
    # ... rest of existing code ...
```

**Step 4:** Restart backend server:
```bash
python main.py
```

---

### Method 2: Feature Flag in Company Settings

Enable 2FA per company in the database:

```python
# In app.py or during company creation
company.features_enabled = {
    **company.features_enabled,
    '2fa_enabled': True,
    '2fa_enforced': False  # True to make it mandatory
}
db.session.commit()
```

Update the setup endpoint to check company features:
```python
@app.route('/api/auth/setup-2fa', methods=['POST'])
@jwt_required()
def setup_2fa():
    employee = Employee.query.get(current_user_id)
    company = employee.company
    
    # Check if 2FA is enabled for this company
    if not company.features_enabled.get('2fa_enabled', False):
        return jsonify({'error': '2FA not available for your account'}), 403
    
    # ... rest of implementation ...
```

---

## 🛑 How to Disable 2FA

### Disable Globally (Default State):

**Option 1: Environment Variable**
```bash
# In .env file
ENABLE_2FA=false  # or remove this line entirely
```

**Option 2: Remove Feature Flag**
```python
# In config.py
class Config:
    ENABLE_2FA = False  # Explicitly disable
```

### Disable for Specific User:

```python
# In Flask shell or admin endpoint
from models import db, Employee

employee = Employee.query.filter_by(email='user@example.com').first()
employee.two_fa_secret = None
employee.backup_codes = None
db.session.commit()
```

### Disable for Company:

```python
company.features_enabled['2fa_enabled'] = False
db.session.commit()
```

---

## 👤 User Enrollment Flow

### Frontend Implementation (Already Built)

**Step 1: User Initiates 2FA Setup**
```javascript
// In Settings page
const setup2FA = async () => {
  const response = await fetch('/api/auth/setup-2fa', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    }
  });
  
  const data = await response.json();
  // Display QR code: data.qr_code (base64 image)
  // Show manual entry secret: data.secret
};
```

**Step 2: User Scans QR Code**
- User opens authenticator app (Google Authenticator, Authy, etc.)
- Scans QR code displayed on screen
- App generates 6-digit code

**Step 3: User Verifies TOTP Code**
```javascript
const verify2FA = async (totpCode) => {
  const response = await fetch('/api/auth/verify-2fa', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ totp_code: totpCode })
  });
  
  const data = await response.json();
  // Display backup codes: data.backup_codes (IMPORTANT: Show once only!)
  // User must save these codes securely
};
```

**Step 4: User Logs In with 2FA**
```javascript
const loginWith2FA = async (email, password, totpCode) => {
  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email,
      password,
      totp_code: totpCode  // 6-digit code from authenticator
    })
  });
  
  if (response.status === 401) {
    const data = await response.json();
    if (data.requires_2fa) {
      // Prompt user for TOTP code
      showTOTPInput();
    }
  }
};
```

---

## 🧪 Testing 2FA

### Test with Virtual Authenticator

```bash
# Install Python TOTP library
pip install pyotp

# Generate test TOTP codes
python3 << EOF
import pyotp
secret = 'YOUR_2FA_SECRET_FROM_SETUP'
totp = pyotp.TOTP(secret)
print(f"Current TOTP code: {totp.now()}")
EOF
```

### Manual Testing Flow:

1. **Setup 2FA:**
   ```bash
   curl -X POST http://localhost:8000/api/auth/setup-2fa \
     -H "Authorization: Bearer YOUR_JWT_TOKEN"
   ```
   - Save the `secret` from response
   - Generate TOTP using secret

2. **Verify 2FA:**
   ```bash
   curl -X POST http://localhost:8000/api/auth/verify-2fa \
     -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"totp_code": "123456"}'
   ```
   - Save backup codes from response

3. **Login with 2FA:**
   ```bash
   curl -X POST http://localhost:8000/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{
       "email": "admin@quotaible.com",
       "password": "admin123",
       "totp_code": "123456"
     }'
   ```

---

## 🔑 Backup Codes

### Format:
```
XXXX-XXXX-XXXX-XXXX
```

### Generation (Already Implemented in app.py):
- 5 codes generated per user
- Each code is 16 characters (4 groups of 4)
- Codes are SHA-256 hashed with unique salts
- Stored format: `salt:hash,salt:hash,...`

### Usage:
- User can enter backup code instead of TOTP during login
- Backup codes are **single-use** (automatically marked as used)
- Remaining codes stay valid

### Regenerate Backup Codes:

```python
# Add this endpoint to app.py
@app.route('/api/auth/regenerate-backup-codes', methods=['POST'])
@jwt_required()
def regenerate_backup_codes():
    """Regenerate backup codes (requires TOTP verification)"""
    current_user_id = int(get_jwt_identity())
    employee = Employee.query.get(current_user_id)
    
    if not employee.two_fa_secret:
        return jsonify({'error': '2FA not enabled'}), 400
    
    # Verify current TOTP before regenerating
    data = request.get_json()
    totp_code = data.get('totp_code')
    
    totp = pyotp.TOTP(employee.two_fa_secret)
    if not totp.verify(totp_code):
        return jsonify({'error': 'Invalid TOTP code'}), 401
    
    # Generate new backup codes
    backup_codes = generate_backup_codes()
    hashed_codes = hash_backup_codes(backup_codes)
    employee.backup_codes = ','.join(hashed_codes)
    db.session.commit()
    
    return jsonify({
        'message': 'Backup codes regenerated successfully',
        'backup_codes': backup_codes
    })
```

---

## 🐛 Troubleshooting

### Issue: QR Code Not Displaying

**Solution:**
- Verify `qrcode` package is installed: `pip install qrcode[pil]`
- Check `setup-2fa` endpoint returns `qr_code` field
- Ensure frontend displays base64 image: `<img src={data.qr_code} />`

### Issue: TOTP Code Always Invalid

**Possible Causes:**
1. **Time Sync Issue** - Server and authenticator app must have synchronized time
   ```bash
   # Check server time
   date
   # Sync time (Ubuntu)
   sudo ntpdate -s time.nist.gov
   ```

2. **Wrong Secret** - Verify secret matches between backend and authenticator
   ```python
   # Debug in Python
   import pyotp
   secret = 'JBSWY3DPEHPK3PXP'
   totp = pyotp.TOTP(secret)
   print(totp.now())  # Should match authenticator app
   ```

3. **Code Expired** - TOTP codes expire every 30 seconds
   - Wait for new code generation
   - Verify time window in pyotp settings

### Issue: Backup Codes Not Working

**Solution:**
- Check backup codes are stored in database:
  ```python
  employee = Employee.query.get(user_id)
  print(employee.backup_codes)  # Should show hashed codes
  ```
- Verify format: `salt:hash,salt:hash,...`
- Ensure code hasn't been used (check for empty strings in CSV)

### Issue: 2FA Locked Out

**Recovery Options:**

**Option 1: Admin Reset (Recommended)**
```python
# In Flask shell or admin endpoint
from models import db, Employee

employee = Employee.query.filter_by(email='locked@user.com').first()
employee.two_fa_secret = None
employee.backup_codes = None
db.session.commit()
print(f"2FA reset for {employee.email}")
```

**Option 2: Database Direct Reset**
```sql
-- Direct SQL update
UPDATE employees 
SET two_fa_secret = NULL, backup_codes = NULL 
WHERE email = 'locked@user.com';
```

---

## 📊 Monitoring & Analytics

### Track 2FA Adoption:
```python
# Query 2FA enabled users
from models import Employee

total_users = Employee.query.count()
users_with_2fa = Employee.query.filter(Employee.two_fa_secret.isnot(None)).count()

adoption_rate = (users_with_2fa / total_users) * 100
print(f"2FA Adoption Rate: {adoption_rate:.1f}%")
```

### Log 2FA Events:
```python
# Add logging to 2FA endpoints
import logging

@app.route('/api/auth/verify-2fa', methods=['POST'])
@jwt_required()
def verify_2fa():
    # ... existing code ...
    
    if totp.verify(totp_code):
        logging.info(f"2FA enabled successfully for user {employee.id}")
        # ... rest of code ...
```

---

## 🔒 Security Best Practices

### DO:
✅ Store secrets encrypted at rest (consider using Fernet encryption)  
✅ Rate limit 2FA verification attempts (max 5 per minute)  
✅ Log all 2FA setup and login attempts  
✅ Enforce HTTPS for all 2FA endpoints  
✅ Display backup codes only once during setup  
✅ Provide account recovery workflow

### DON'T:
❌ Send TOTP secrets via email or SMS  
❌ Store backup codes in plain text  
❌ Allow unlimited verification attempts  
❌ Reuse backup codes  
❌ Skip time synchronization checks  
❌ Hard-code TOTP secrets in frontend code

---

## 📚 Additional Resources

- [RFC 6238 - TOTP Specification](https://tools.ietf.org/html/rfc6238)
- [pyotp Documentation](https://pyauth.github.io/pyotp/)
- [Google Authenticator](https://support.google.com/accounts/answer/1066447)
- [Authy App](https://authy.com/)

---

**Last Updated:** October 14, 2025  
**Implementation Status:** ✅ Complete (Disabled by Default)  
**Configuration Required:** Environment Variables or Feature Flags
