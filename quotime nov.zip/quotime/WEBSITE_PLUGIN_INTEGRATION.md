# Website Plugin Integration Guide

## Overview

The Quotaible Website Plugin allows your customers to embed an inquiry form directly on their business website, enabling their clients to submit service requests seamlessly.

---

## 🔌 How It Works

### Data Flow Architecture

```
Customer Website → Plugin Form → Quotaible API → Database → Company Dashboard
```

1. **Customer embeds widget** on their website using provided code snippet
2. **End-user fills out form** with service request details
3. **Form data is securely sent** to Quotaible API endpoint
4. **API validates and saves** inquiry to PostgreSQL database
5. **Company receives notification** and inquiry appears in dashboard

---

## 📋 Integration Steps

### Step 1: Get Your Company Identifier

Each Quotaible customer has a unique company identifier (slug or ID) used to route inquiries.

**Find your identifier:**
- Login to Quotaible Dashboard
- Navigate to Settings → Integrations
- Copy your Company ID or Slug (e.g., `elite-plumbing`)

### Step 2: Choose Integration Method

#### Option A: JavaScript Widget (Recommended)

**Copy-Paste Embed Code:**

```html
<!-- Quotaible Inquiry Form Widget -->
<div id="quotaible-widget"></div>

<script src="https://cdn.quotaible.com/widget.min.js"></script>
<script>
  Quotaible.init({
    companyId: 'YOUR_COMPANY_ID_HERE',    // Required: Your unique company identifier
    containerId: 'quotaible-widget',      // Required: HTML element ID
    primaryColor: '#3B82F6',              // Optional: Match your brand color
    title: 'Request a Quote',             // Optional: Custom form title
    services: [                           // Optional: Pre-defined service types
      'Plumbing',
      'HVAC',
      'Electrical Repair',
      'Emergency Service'
    ],
    showImageUpload: true,                // Optional: Allow customers to upload photos
    autoFocus: false,                     // Optional: Auto-focus first field
    redirectUrl: '/thank-you',            // Optional: Redirect after submission
    onSuccess: function(data) {           // Optional: Callback on successful submission
      console.log('Inquiry submitted!', data);
      // Custom success handling (e.g., Google Analytics event)
    },
    onError: function(error) {            // Optional: Callback on error
      console.error('Submission failed', error);
    }
  });
</script>
```

#### Option B: React Component

```jsx
import { useEffect } from 'react';

export function QuotaibleWidget() {
  useEffect(() => {
    // Load widget script
    const script = document.createElement('script');
    script.src = 'https://cdn.quotaible.com/widget.min.js';
    script.async = true;
    document.body.appendChild(script);

    script.onload = () => {
      window.Quotaible.init({
        companyId: 'YOUR_COMPANY_ID_HERE',
        containerId: 'quotaible-react-widget',
        primaryColor: '#3B82F6',
        services: ['Plumbing', 'HVAC', 'Electrical']
      });
    };

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return <div id="quotaible-react-widget" />;
}
```

#### Option C: WordPress Shortcode

```php
// Add to functions.php
function quotaible_widget_shortcode($atts) {
    $atts = shortcode_atts([
        'company_id' => 'YOUR_COMPANY_ID',
        'color' => '#3B82F6'
    ], $atts);

    return '
        <div id="quotaible-widget"></div>
        <script src="https://cdn.quotaible.com/widget.min.js"></script>
        <script>
            Quotaible.init({
                companyId: "' . esc_attr($atts['company_id']) . '",
                containerId: "quotaible-widget",
                primaryColor: "' . esc_attr($atts['color']) . '"
            });
        </script>
    ';
}
add_shortcode('quotaible_form', 'quotaible_widget_shortcode');
```

**Usage in WordPress:**
```
[quotaible_form company_id="elite-plumbing" color="#3B82F6"]
```

#### Option D: Direct API Integration (Custom Forms)

For developers who want to build custom forms:

```javascript
// Custom form submission
async function submitInquiry(formData) {
  try {
    const response = await fetch('https://api.quotaible.com/api/inquiries/public/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        company_identifier: 'YOUR_COMPANY_ID',
        customer_name: formData.name,
        customer_email: formData.email,
        customer_phone: formData.phone,
        job_type: formData.serviceType,
        description: formData.description,
        urgency: formData.urgency || 'normal',
        source: 'website_custom_form'
      })
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('Inquiry submitted!', data);
      // Show success message
      alert(`Inquiry submitted! Reference number: ${data.reference_number}`);
    } else {
      console.error('Submission failed:', data.error);
    }
  } catch (error) {
    console.error('Network error:', error);
  }
}
```

---

## 🔧 Backend Implementation (Flask API)

### Public Inquiry Endpoint

**Endpoint:** `POST /api/inquiries/public/submit`

**Implementation in `app.py`:**

```python
from flask import request, jsonify
from models import db, Inquiry, Company
from datetime import datetime
import re

@app.route('/api/inquiries/public/submit', methods=['POST'])
def submit_public_inquiry():
    """
    PUBLIC ENDPOINT - Accept inquiry submissions from website plugins
    No authentication required
    """
    try:
        data = request.get_json()
        
        # 1. SECURITY VALIDATION
        # Rate limiting check (implement Redis-based rate limiter)
        ip_address = request.remote_addr
        if is_rate_limited(ip_address):
            return jsonify({'error': 'Too many requests. Please try again later.'}), 429
        
        # 2. COMPANY LOOKUP
        company_identifier = data.get('company_identifier')
        company = Company.query.filter_by(slug=company_identifier).first()
        
        if not company:
            return jsonify({'error': 'Invalid company identifier'}), 404
        
        # Check if company accepts public inquiries
        if not company.features_enabled.get('website_plugin'):
            return jsonify({'error': 'Public inquiries not enabled for this company'}), 403
        
        # 3. INPUT VALIDATION
        required_fields = ['customer_name', 'customer_email', 'job_type', 'description']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Email validation
        email = data['customer_email']
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_regex, email):
            return jsonify({'error': 'Invalid email address'}), 400
        
        # 4. SANITIZE INPUTS (prevent XSS)
        from markupsafe import escape
        description = escape(data['description'])
        
        # 5. CREATE INQUIRY
        inquiry = Inquiry(
            company_id=company.id,
            customer_name=data['customer_name'],
            customer_email=email,
            customer_phone=data.get('customer_phone'),
            customer_address=data.get('customer_address'),
            job_type=data['job_type'],
            description=str(description),
            urgency=data.get('urgency', 'normal'),
            preferred_date=datetime.strptime(data['preferred_date'], '%Y-%m-%d').date() 
                if data.get('preferred_date') else None,
            source='website_plugin',
            status='new'
        )
        
        db.session.add(inquiry)
        db.session.commit()
        
        # 6. SEND NOTIFICATIONS
        # Email to customer (confirmation)
        send_confirmation_email(
            to=inquiry.customer_email,
            customer_name=inquiry.customer_name,
            inquiry_id=inquiry.id
        )
        
        # Notify company manager
        notify_new_inquiry(company, inquiry)
        
        # 7. RESPONSE
        reference_number = f"INQ-{inquiry.id:06d}"
        
        return jsonify({
            'message': 'Inquiry submitted successfully',
            'inquiry_id': inquiry.id,
            'reference_number': reference_number,
            'estimated_response_time': '24 hours'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'An error occurred. Please try again.'}), 500
```

### Security Helpers

```python
# Rate limiting with Redis
import redis
from datetime import timedelta

redis_client = redis.Redis(host='localhost', port=6379, db=0)

def is_rate_limited(ip_address):
    """
    Rate limit: 5 submissions per hour per IP
    """
    key = f"rate_limit:inquiry:{ip_address}"
    count = redis_client.get(key)
    
    if count and int(count) >= 5:
        return True
    
    # Increment counter
    redis_client.incr(key)
    redis_client.expire(key, timedelta(hours=1))
    return False


# Email sanitization
def sanitize_input(text):
    """
    Remove potentially malicious content
    """
    # Remove script tags
    text = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL | re.IGNORECASE)
    # Remove onclick/onerror handlers
    text = re.sub(r'on\w+\s*=', '', text, flags=re.IGNORECASE)
    return text.strip()
```

---

## 🎨 Widget Customization

### Branding

The widget automatically fetches company branding from the API:

```javascript
// Widget fetches branding on initialization
fetch(`/api/customers/public/company/${companyId}`)
  .then(res => res.json())
  .then(branding => {
    widget.style.setProperty('--primary-color', branding.primary_color);
    widget.style.setProperty('--secondary-color', branding.secondary_color);
    logoElement.src = branding.logo_url;
  });
```

### Custom Styling

Override default styles with CSS:

```css
/* Override widget styles */
#quotaible-widget {
  font-family: 'Helvetica Neue', Arial, sans-serif;
  max-width: 600px;
  margin: 0 auto;
}

#quotaible-widget .submit-button {
  background-color: #your-brand-color;
  border-radius: 8px;
  padding: 12px 24px;
}

#quotaible-widget .form-input {
  border: 2px solid #e5e7eb;
  border-radius: 6px;
}
```

---

## 🔒 Security Considerations

### CORS Configuration

```python
# In app.py
from flask_cors import CORS

# Allow widget from customer domains
CORS(app, resources={
    r"/api/inquiries/public/*": {
        "origins": [
            "https://eliteplumbing.com",
            "https://www.eliteplumbing.com",
            # Add customer domains dynamically from database
        ],
        "methods": ["POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})
```

### Input Validation Checklist

- ✅ Validate email format (regex)
- ✅ Sanitize HTML/script tags from description
- ✅ Check for SQL injection patterns
- ✅ Limit description length (max 5000 characters)
- ✅ Validate phone number format
- ✅ Check file upload MIME types (if images enabled)
- ✅ Implement reCAPTCHA for bot protection

### Rate Limiting

- **Per IP**: 5 submissions per hour
- **Per Email**: 3 submissions per day (prevent spam)
- **Global**: 1000 submissions per hour per company

---

## 📊 Analytics & Tracking

### Track Form Submissions

```javascript
Quotaible.init({
  companyId: 'elite-plumbing',
  onSuccess: function(data) {
    // Google Analytics event
    gtag('event', 'form_submission', {
      'event_category': 'inquiry',
      'event_label': 'quotaible_widget',
      'value': data.inquiry_id
    });

    // Facebook Pixel
    fbq('track', 'Lead', {
      content_name: 'Service Inquiry',
      inquiry_id: data.inquiry_id
    });
  }
});
```

---

## 🧪 Testing

### Test the Widget Locally

```html
<!DOCTYPE html>
<html>
<head>
  <title>Quotaible Widget Test</title>
</head>
<body>
  <h1>Test Inquiry Form</h1>
  
  <div id="quotaible-test-widget"></div>

  <script src="http://localhost:8000/static/widget.min.js"></script>
  <script>
    Quotaible.init({
      companyId: 'test-company',
      containerId: 'quotaible-test-widget',
      apiEndpoint: 'http://localhost:8000/api', // Point to local API
      primaryColor: '#3B82F6'
    });
  </script>
</body>
</html>
```

### API Testing with cURL

```bash
# Test public inquiry submission
curl -X POST http://localhost:8000/api/inquiries/public/submit \
  -H "Content-Type: application/json" \
  -d '{
    "company_identifier": "elite-plumbing",
    "customer_name": "Test Customer",
    "customer_email": "test@example.com",
    "customer_phone": "+1-555-1234",
    "job_type": "plumbing",
    "description": "Leaky faucet in bathroom",
    "urgency": "normal"
  }'
```

---

## 📝 Customer Setup Instructions

**To provide to your customers:**

1. **Copy the code snippet** from your Quotaible dashboard
2. **Paste it on your website** where you want the form to appear
3. **Customize colors** to match your brand (optional)
4. **Test the form** by submitting a sample inquiry
5. **Check your Quotaible dashboard** to see the inquiry appear

**Support:**
- Email: support@quotaible.com
- Documentation: https://docs.quotaible.com
- Video Tutorial: https://quotaible.com/tutorials/widget-setup

---

## 🚀 Advanced Features

### Multi-Step Form

```javascript
Quotaible.init({
  companyId: 'elite-plumbing',
  formType: 'multi-step',    // Enable step-by-step form
  steps: [
    {
      title: 'Service Details',
      fields: ['job_type', 'urgency', 'description']
    },
    {
      title: 'Contact Information',
      fields: ['customer_name', 'customer_email', 'customer_phone']
    },
    {
      title: 'Schedule',
      fields: ['preferred_date', 'preferred_time']
    }
  ]
});
```

### Conditional Fields

```javascript
Quotaible.init({
  companyId: 'elite-plumbing',
  conditionalFields: {
    job_type: {
      'emergency': {
        show: ['urgency_reason'],
        required: ['customer_phone']
      },
      'installation': {
        show: ['preferred_date', 'budget_range'],
        required: ['customer_address']
      }
    }
  }
});
```

---

## 📦 Distribution

### CDN Hosting

**Production:**
```
https://cdn.quotaible.com/widget.min.js
```

**Version-specific:**
```
https://cdn.quotaible.com/v1.2.3/widget.min.js
```

### NPM Package (Future)

```bash
npm install @quotaible/widget
```

```javascript
import { QuotaibleWidget } from '@quotaible/widget';

QuotaibleWidget.render('#container', {
  companyId: 'elite-plumbing'
});
```

---

## 🐛 Troubleshooting

**Widget not displaying:**
- Check browser console for errors
- Verify company ID is correct
- Ensure script URL is accessible
- Check for JavaScript conflicts

**Form submission fails:**
- Verify API endpoint is reachable
- Check CORS configuration
- Review rate limiting settings
- Validate required fields are filled

**Styling issues:**
- Clear browser cache
- Check for CSS conflicts
- Use browser DevTools to inspect styles
- Override with `!important` if needed

---

**Last Updated:** October 14, 2025  
**API Version:** 1.0  
**Widget Version:** 1.0.0
