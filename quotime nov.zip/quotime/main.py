"""
Quotaible Flask Application Entry Point
"""
import os
# We need Pathlib for robust path manipulation
from pathlib import Path
from dotenv import load_dotenv

# --- DOTENV FIX START (Using absolute path for robustness) ---

# 1. Define the base directory as the directory containing main.py
BASE_DIR = Path(__file__).resolve().parent

# 2. Define the path to the .env file
DOTENV_PATH = BASE_DIR / ".env"

# 3. Load the .env file using the explicit path
load_dotenv(DOTENV_PATH)

# --- CRITICAL DEBUG STEP ---
print(f"--- DEBUG: .env path used: {DOTENV_PATH}")
print(f"--- DEBUG: TOKEN value loaded? {bool(os.getenv('TOKEN'))}")
# ---------------------------

# Now import the application instance.
from app import app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)
