"""
Routes package initialization
Centralizes all API route blueprints
"""
