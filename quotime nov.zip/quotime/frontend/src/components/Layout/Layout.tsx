import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Flex, Box } from '@chakra-ui/react';
import { Sidebar } from './Sidebar';
import { Dashboard } from '../Dashboard/Dashboard';
import { InquiriesPage } from '../Inquiries/InquiriesPage';
import { QuotesPage } from '../Quotes/QuotesPage';
import { AppointmentsPage } from '../Appointments/AppointmentsPage';
import { AnalyticsPage } from '../Analytics/AnalyticsPage';
import { EmployeesPage } from '../Employees/EmployeesPage';
import { CompaniesPage } from '../Companies/CompaniesPage';
import { AdminPage } from '../Admin/AdminPage';
import { SettingsPage } from '../Settings/SettingsPage';

export const Layout: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Extract current tab from URL path
  const getCurrentTab = () => {
    const path = location.pathname;
    if (path === '/' || path === '/dashboard') return 'dashboard';
    return path.slice(1); // Remove leading slash
  };

  const handleTabChange = (tab: string) => {
    if (tab === 'dashboard') {
      navigate('/');
    } else {
      navigate(`/${tab}`);
    }
  };

  const renderContent = () => {
    const currentTab = getCurrentTab();
    switch (currentTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'inquiries':
        return <InquiriesPage />;
      case 'quotes':
        return <QuotesPage />;
      case 'appointments':
        return <AppointmentsPage />;
      case 'analytics':
        return <AnalyticsPage />;
      case 'employees':
        return <EmployeesPage />;
      case 'companies':
        return <CompaniesPage />;
      case 'admin':
        return <AdminPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Flex minH="100vh" bg="gray.50">
      <Sidebar activeTab={getCurrentTab()} onTabChange={handleTabChange} />
      
      <Box flex="1" ml="280px" p={8}>
        {renderContent()}
      </Box>
    </Flex>
  );
};