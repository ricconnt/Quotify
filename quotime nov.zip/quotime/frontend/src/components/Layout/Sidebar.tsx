import React from 'react';
import { 
  Box, 
  VStack, 
  HStack, 
  Text, 
  Avatar, 
  Button, 
  Divider,
  Icon
} from '@chakra-ui/react';
import { 
  LayoutDashboard, 
  MessageSquare, 
  FileText, 
  Calendar, 
  Users, 
  BarChart3, 
  Settings, 
  LogOut,
  Building2,
  UserCog
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
  roles: ('admin' | 'manager' | 'employee')[];
}

const navItems: NavItem[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    roles: ['admin', 'manager', 'employee']
  },
  {
    id: 'inquiries',
    label: 'Inquiries',
    icon: MessageSquare,
    roles: ['admin', 'manager', 'employee']
  },
  {
    id: 'quotes',
    label: 'Quotes',
    icon: FileText,
    roles: ['admin', 'manager', 'employee']
  },
  {
    id: 'appointments',
    label: 'Appointments',
    icon: Calendar,
    roles: ['admin', 'manager', 'employee']
  },
  {
    id: 'analytics',
    label: 'Analytics',
    icon: BarChart3,
    roles: ['admin', 'manager']
  },
  {
    id: 'employees',
    label: 'Employees',
    icon: Users,
    roles: ['admin', 'manager']
  },
  {
    id: 'companies',
    label: 'Companies',
    icon: Building2,
    roles: ['admin']
  },
  {
    id: 'admin',
    label: 'Admin Panel',
    icon: UserCog,
    roles: ['admin']
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Settings,
    roles: ['admin', 'manager', 'employee']
  }
];

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange }) => {
  const { user, company, logout } = useAuth();

  if (!user) return null;

  const filteredNavItems = navItems.filter(item => 
    item.roles.includes(user.role)
  );

  return (
    <Box
      position="fixed"
      left={0}
      top={0}
      h="100vh"
      w="280px"
      bg="white"
      borderRight="1px"
      borderColor="gray.200"
      boxShadow="sm"
      display="flex"
      flexDirection="column"
    >
      {/* Header */}
      <Box p={6} borderBottom="1px" borderColor="gray.100">
        <HStack spacing={3}>
          <Box
            w="40px"
            h="40px"
            bgGradient="linear(to-br, brand.500, brand.600)"
            borderRadius="lg"
            display="flex"
            alignItems="center"
            justifyContent="center"
            boxShadow="sm"
          >
            <Text color="white" fontWeight="bold" fontSize="lg">Q</Text>
          </Box>
          <Box>
            <Text fontSize="xl" fontWeight="bold" color="gray.800">Quotaible</Text>
            <Text fontSize="sm" color="gray.500">{company?.name}</Text>
          </Box>
        </HStack>
      </Box>

      {/* User Info */}
      <Box p={4} borderBottom="1px" borderColor="gray.100">
        <HStack spacing={3}>
          <Avatar
            size="md"
            name={user.name}
            bgGradient="linear(to-br, brand.400, brand.500)"
            color="white"
          />
          <Box>
            <Text fontWeight="semibold" color="gray.800">{user.name}</Text>
            <Text fontSize="sm" color="gray.500" textTransform="capitalize">{user.role}</Text>
          </Box>
        </HStack>
      </Box>

      {/* Navigation */}
      <VStack flex={1} overflowY="auto" spacing={1} p={4} align="stretch">
        {filteredNavItems.map((item) => {
          const isActive = activeTab === item.id;
          
          return (
            <Button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              variant={isActive ? 'solid' : 'ghost'}
              colorScheme={isActive ? 'brand' : 'gray'}
              justifyContent="flex-start"
              leftIcon={<Icon as={item.icon} boxSize={5} />}
              size="md"
              fontWeight="medium"
              bg={isActive ? 'brand.500' : 'transparent'}
              color={isActive ? 'white' : 'gray.600'}
              _hover={{
                bg: isActive ? 'brand.600' : 'gray.100',
                color: isActive ? 'white' : 'gray.800'
              }}
            >
              {item.label}
            </Button>
          );
        })}
      </VStack>

      <Divider />

      {/* Logout */}
      <Box p={4}>
        <Button
          onClick={logout}
          variant="ghost"
          colorScheme="red"
          justifyContent="flex-start"
          leftIcon={<Icon as={LogOut} boxSize={5} />}
          width="full"
          fontWeight="medium"
        >
          Logout
        </Button>
      </Box>
    </Box>
  );
};
