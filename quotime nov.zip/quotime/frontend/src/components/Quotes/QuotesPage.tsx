/**
 * QuotesPage Component
 * 
 * Professional quote management interface for creating and tracking customer quotes.
 * Displays quote cards with status tracking and financial summaries.
 * 
 * TODO: DB INTEGRATION
 * - Replace static quote data with API call to GET /api/quotes
 * - Implement quote creation via POST /api/quotes with form data
 * - Add quote update functionality PUT /api/quotes/:id
 * - Connect quote approval workflow to backend status updates
 * - Integrate PDF generation API for quote downloads
 */

import React from 'react';
import {
  Box,
  Button,
  Card,
  CardBody,
  Flex,
  Grid,
  Heading,
  Text,
  VStack,
  HStack,
  Icon,
  IconButton,
  Badge,
  SimpleGrid,
  Divider
} from '@chakra-ui/react';
import { 
  FileText, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Plus,
  Download,
  Send,
  Edit,
  Eye,
  TrendingUp,
  Calendar
} from 'lucide-react';

export const QuotesPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API call
  // const { data: quotes } = await fetch('/api/quotes').then(r => r.json());
  const quotes = [
    { 
      id: 'Q-2024-001', 
      customer: 'Acme Corp', 
      service: 'Commercial Plumbing',
      amount: 12500, 
      status: 'pending',
      date: '2024-12-15',
      validUntil: '2025-01-15'
    },
    { 
      id: 'Q-2024-002', 
      customer: 'Tech Innovations Ltd', 
      service: 'Electrical Installation',
      amount: 8750, 
      status: 'approved',
      date: '2024-12-14',
      validUntil: '2025-01-14'
    },
    { 
      id: 'Q-2024-003', 
      customer: 'Downtown Restaurant', 
      service: 'HVAC Maintenance',
      amount: 5200, 
      status: 'sent',
      date: '2024-12-13',
      validUntil: '2025-01-13'
    },
    { 
      id: 'Q-2024-004', 
      customer: 'Retail Plaza', 
      service: 'Emergency Repair',
      amount: 15600, 
      status: 'approved',
      date: '2024-12-12',
      validUntil: '2025-01-12'
    },
  ];

  const getStatusBadge = (status: string) => {
    const config = {
      pending: { colorScheme: 'yellow', icon: Clock },
      sent: { colorScheme: 'blue', icon: Send },
      approved: { colorScheme: 'green', icon: CheckCircle2 },
      rejected: { colorScheme: 'red', icon: XCircle },
    };

    const { colorScheme, icon: StatusIcon } = config[status as keyof typeof config] || config.pending;

    return (
      <Badge
        colorScheme={colorScheme}
        borderRadius="full"
        px={3}
        py={1}
        fontSize="xs"
        display="inline-flex"
        alignItems="center"
        gap={1}
      >
        <Icon as={StatusIcon} w={3} h={3} />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  // TODO: DB INTEGRATION - Calculate from actual data
  const totalQuoted = quotes.reduce((sum, q) => sum + q.amount, 0);
  const approvedValue = quotes.filter(q => q.status === 'approved').reduce((sum, q) => sum + q.amount, 0);

  return (
    <VStack spacing={6} align="stretch">
      {/* Header with Actions */}
      <Flex justify="space-between" align="center">
        <Box>
          <Heading size="xl" color="gray.900">Quotes</Heading>
          <Text color="gray.600" mt={1}>Create and manage customer estimates</Text>
        </Box>
        <Button
          leftIcon={<Icon as={Plus} w={5} h={5} />}
          colorScheme="blue"
          bgGradient="linear(to-r, blue.500, blue.600)"
          _hover={{
            bgGradient: 'linear(to-r, blue.600, blue.700)',
            transform: 'translateY(-2px)',
            shadow: 'xl'
          }}
          size="lg"
          borderRadius="xl"
          shadow="lg"
          transition="all 0.3s"
        >
          Create Quote
        </Button>
      </Flex>

      {/* Summary Cards */}
      <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
        <Card
          bg="white"
          shadow="xl"
          borderRadius="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl', transition: 'all 0.3s' }}
          transition="all 0.3s"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Total Quoted
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  ${totalQuoted.toLocaleString()}
                </Text>
                <Text fontSize="sm" color="gray.600" mt={1}>{quotes.length} active quotes</Text>
              </Box>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, blue.500, blue.600)"
                borderRadius="xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={FileText} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          shadow="xl"
          borderRadius="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl', transition: 'all 0.3s' }}
          transition="all 0.3s"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Approved Value
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  ${approvedValue.toLocaleString()}
                </Text>
                <Text fontSize="sm" color="gray.600" mt={1}>
                  {quotes.filter(q => q.status === 'approved').length} approved
                </Text>
              </Box>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, green.500, green.600)"
                borderRadius="xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={CheckCircle2} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          shadow="xl"
          borderRadius="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl', transition: 'all 0.3s' }}
          transition="all 0.3s"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Win Rate
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  {Math.round((approvedValue / totalQuoted) * 100)}%
                </Text>
                <Text fontSize="sm" color="gray.600" mt={1}>Conversion success</Text>
              </Box>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, purple.500, purple.600)"
                borderRadius="xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={TrendingUp} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* Quotes List */}
      <Card bg="white" shadow="xl" borderRadius="xl" border="1px" borderColor="gray.100">
        <Box p={6} borderBottom="1px" borderColor="gray.200">
          <Heading size="md" color="gray.900">Recent Quotes</Heading>
        </Box>
        <VStack divider={<Divider />} spacing={0} align="stretch">
          {quotes.map((quote) => (
            <Box
              key={quote.id}
              p={6}
              _hover={{
                bgGradient: 'linear(to-r, blue.50, transparent)',
                transition: 'all 0.2s'
              }}
              transition="all 0.2s"
            >
              <Flex justify="space-between" align="center">
                <Flex flex="1" direction="column">
                  <HStack spacing={4} mb={3}>
                    <Flex
                      w={14}
                      h={14}
                      bgGradient="linear(to-br, blue.500, blue.600)"
                      borderRadius="xl"
                      align="center"
                      justify="center"
                      _groupHover={{ transform: 'scale(1.1)' }}
                      transition="transform 0.3s"
                    >
                      <Icon as={FileText} w={7} h={7} color="white" />
                    </Flex>
                    <Box>
                      <Text fontWeight="bold" color="gray.900" fontSize="lg">{quote.id}</Text>
                      <Text fontSize="sm" color="gray.600">{quote.customer}</Text>
                    </Box>
                  </HStack>
                  
                  <SimpleGrid columns={{ base: 1, md: 4 }} spacing={4} ml={18}>
                    <Box>
                      <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                        Service
                      </Text>
                      <Text fontSize="sm" fontWeight="semibold" color="gray.900" mt={1}>
                        {quote.service}
                      </Text>
                    </Box>
                    <Box>
                      <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                        Amount
                      </Text>
                      <Text fontSize="sm" fontWeight="bold" color="green.600" mt={1}>
                        ${quote.amount.toLocaleString()}
                      </Text>
                    </Box>
                    <Box>
                      <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                        Valid Until
                      </Text>
                      <Text fontSize="sm" fontWeight="semibold" color="gray.900" mt={1}>
                        {new Date(quote.validUntil).toLocaleDateString()}
                      </Text>
                    </Box>
                    <Box>
                      <Text fontSize="xs" color="gray.500" textTransform="uppercase" letterSpacing="wide" mb={1}>
                        Status
                      </Text>
                      {getStatusBadge(quote.status)}
                    </Box>
                  </SimpleGrid>
                </Flex>
                
                <HStack spacing={2} ml={4}>
                  <IconButton
                    aria-label="View quote"
                    icon={<Icon as={Eye} w={5} h={5} />}
                    variant="ghost"
                    _hover={{ bg: 'blue.100', color: 'blue.600' }}
                    color="gray.400"
                    borderRadius="lg"
                  />
                  <IconButton
                    aria-label="Edit quote"
                    icon={<Icon as={Edit} w={5} h={5} />}
                    variant="ghost"
                    _hover={{ bg: 'purple.100', color: 'purple.600' }}
                    color="gray.400"
                    borderRadius="lg"
                  />
                  <IconButton
                    aria-label="Download quote"
                    icon={<Icon as={Download} w={5} h={5} />}
                    variant="ghost"
                    _hover={{ bg: 'green.100', color: 'green.600' }}
                    color="gray.400"
                    borderRadius="lg"
                  />
                </HStack>
              </Flex>
            </Box>
          ))}
        </VStack>
      </Card>
    </VStack>
  );
};
