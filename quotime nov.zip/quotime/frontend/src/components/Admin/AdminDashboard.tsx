import React, { useState, useEffect } from 'react';
import {
  Building2,
  Users,
  TrendingUp,
  DollarSign,
  Activity,
  AlertTriangle,
  CheckCircle,
  Calendar,
  BarChart3,
  Settings,
  Filter,
  Download,
  Search
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface CompanyOverview {
  id: number;
  name: string;
  industry: string;
  subscription_tier: string;
  employees_count: number;
  total_inquiries: number;
  completed_jobs: number;
  conversion_rate: number;
  monthly_revenue: number;
  last_activity: string;
  is_active: boolean;
  growth_trend: number;
}

interface AdminMetrics {
  total_companies: number;
  active_companies: number;
  total_revenue: number;
  total_inquiries: number;
  avg_conversion_rate: number;
  growth_rate: number;
}

const CompanyCard: React.FC<{ company: CompanyOverview }> = ({ company }) => {
  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'premium': return 'bg-gradient-to-r from-purple-500 to-indigo-600';
      case 'professional': return 'bg-gradient-to-r from-blue-500 to-blue-600';
      case 'basic': return 'bg-gradient-to-r from-gray-400 to-gray-500';
      default: return 'bg-gradient-to-r from-gray-400 to-gray-500';
    }
  };

  const getGrowthColor = (growth: number) => {
    return growth >= 0 ? 'text-emerald-600' : 'text-red-600';
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-900">{company.name}</h3>
            <p className="text-sm text-gray-600 capitalize">{company.industry}</p>
          </div>
        </div>
        <div className="flex flex-col items-end space-y-2">
          <span className={`px-3 py-1 rounded-full text-xs font-semibold text-white ${getTierColor(company.subscription_tier)}`}>
            {company.subscription_tier.toUpperCase()}
          </span>
          <div className={`inline-flex items-center text-sm font-medium ${getGrowthColor(company.growth_trend)}`}>
            <TrendingUp className="w-4 h-4 mr-1" />
            {company.growth_trend >= 0 ? '+' : ''}{company.growth_trend}%
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-blue-50 rounded-xl p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Users className="w-4 h-4 text-blue-500" />
            <span className="text-sm font-medium text-gray-700">Employees</span>
          </div>
          <p className="text-xl font-bold text-gray-900">{company.employees_count}</p>
        </div>
        
        <div className="bg-emerald-50 rounded-xl p-3">
          <div className="flex items-center space-x-2 mb-1">
            <Activity className="w-4 h-4 text-emerald-500" />
            <span className="text-sm font-medium text-gray-700">Inquiries</span>
          </div>
          <p className="text-xl font-bold text-gray-900">{company.total_inquiries}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="text-center">
          <p className="text-sm text-gray-600">Conversion Rate</p>
          <p className="text-lg font-bold text-gray-900">{company.conversion_rate}%</p>
        </div>
        <div className="text-center">
          <p className="text-sm text-gray-600">Monthly Revenue</p>
          <p className="text-lg font-bold text-emerald-600">${company.monthly_revenue.toLocaleString()}</p>
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${company.is_active ? 'bg-emerald-400' : 'bg-red-400'}`}></div>
          <span className="text-sm text-gray-600">
            {company.is_active ? 'Active' : 'Inactive'}
          </span>
        </div>
        <div className="text-sm text-gray-500">
          Last activity: {new Date(company.last_activity).toLocaleDateString()}
        </div>
      </div>

      <div className="mt-4 flex space-x-2">
        <button className="flex-1 px-3 py-2 bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium">
          View Details
        </button>
        <button className="px-3 py-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors">
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

const MetricCard: React.FC<{ title: string; value: string | number; icon: React.ComponentType<any>; color: string; change?: string }> = ({ title, value, icon: Icon, color, change }) => (
  <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <p className="text-sm font-semibold text-gray-500 uppercase tracking-wide">{title}</p>
        <p className="text-3xl font-bold text-gray-900 mt-3 mb-2">{value}</p>
        {change && (
          <p className="text-sm text-emerald-600 font-medium">
            <TrendingUp className="w-4 h-4 inline mr-1" />
            {change}
          </p>
        )}
      </div>
      <div className={`p-4 rounded-2xl ${color} shadow-lg`}>
        <Icon className="w-7 h-7 text-white" />
      </div>
    </div>
  </div>
);

export const AdminDashboard: React.FC = () => {
  const [companies, setCompanies] = useState<CompanyOverview[]>([]);
  const [metrics, setMetrics] = useState<AdminMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTier, setFilterTier] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  // Sample data - in real app this would come from API
  const sampleCompanies: CompanyOverview[] = [
    {
      id: 1,
      name: 'Elite Plumbing Services',
      industry: 'plumbing',
      subscription_tier: 'premium',
      employees_count: 15,
      total_inquiries: 234,
      completed_jobs: 187,
      conversion_rate: 79.9,
      monthly_revenue: 18500,
      last_activity: '2025-09-20',
      is_active: true,
      growth_trend: 12.5
    },
    {
      id: 2,
      name: 'Spark Electric Solutions',
      industry: 'electrical',
      subscription_tier: 'professional',
      employees_count: 8,
      total_inquiries: 156,
      completed_jobs: 124,
      conversion_rate: 79.5,
      monthly_revenue: 12300,
      last_activity: '2025-09-20',
      is_active: true,
      growth_trend: 8.2
    },
    {
      id: 3,
      name: 'Swift HVAC Solutions',
      industry: 'hvac',
      subscription_tier: 'basic',
      employees_count: 5,
      total_inquiries: 89,
      completed_jobs: 67,
      conversion_rate: 75.3,
      monthly_revenue: 5600,
      last_activity: '2025-09-18',
      is_active: true,
      growth_trend: -2.1
    },
    {
      id: 4,
      name: 'ProClean Services',
      industry: 'cleaning',
      subscription_tier: 'professional',
      employees_count: 12,
      total_inquiries: 201,
      completed_jobs: 145,
      conversion_rate: 72.1,
      monthly_revenue: 9800,
      last_activity: '2025-09-15',
      is_active: false,
      growth_trend: -5.3
    }
  ];

  const sampleMetrics: AdminMetrics = {
    total_companies: 4,
    active_companies: 3,
    total_revenue: 46200,
    total_inquiries: 680,
    avg_conversion_rate: 76.7,
    growth_rate: 8.3
  };

  const revenueData = [
    { month: 'Jan', revenue: 38000 },
    { month: 'Feb', revenue: 42000 },
    { month: 'Mar', revenue: 39000 },
    { month: 'Apr', revenue: 45000 },
    { month: 'May', revenue: 43000 },
    { month: 'Jun', revenue: 46200 }
  ];

  const tierDistribution = [
    { name: 'Premium', value: 1, color: '#8B5CF6' },
    { name: 'Professional', value: 2, color: '#3B82F6' },
    { name: 'Basic', value: 1, color: '#6B7280' }
  ];

  useEffect(() => {
    fetchAdminData();
  }, []);
  
  const fetchAdminData = async () => {
    try {
      setLoading(true);
      
      // Get JWT token from localStorage
      const token = localStorage.getItem('token');
      if (!token) {
        console.error('No authentication token found');
        return;
      }
      
      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };
      
      // Fetch admin metrics and companies data in parallel
      const [metricsResponse, companiesResponse] = await Promise.all([
        fetch('/api/admin/metrics', { headers }),
        fetch('/api/admin/companies', { headers })
      ]);
      
      if (!metricsResponse.ok || !companiesResponse.ok) {
        throw new Error('Failed to fetch admin data');
      }
      
      const metricsData = await metricsResponse.json();
      const companiesData = await companiesResponse.json();
      
      setMetrics(metricsData);
      setCompanies(companiesData);
    } catch (err: any) {
      console.error('Admin dashboard error:', err);
      // Fallback to sample data for demo
      setCompanies(sampleCompanies);
      setMetrics(sampleMetrics);
    } finally {
      setLoading(false);
    }
  };

  const filteredCompanies = companies.filter(company => {
    const matchesSearch = company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         company.industry.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTier = filterTier === 'all' || company.subscription_tier === filterTier;
    const matchesStatus = filterStatus === 'all' || 
                         (filterStatus === 'active' && company.is_active) ||
                         (filterStatus === 'inactive' && !company.is_active);
    return matchesSearch && matchesTier && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-4 border-blue-200 border-t-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600 text-lg font-medium">Loading admin dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 p-6 space-y-8">
      {/* Header */}
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div className="mb-4 lg:mb-0">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Company-by-company performance overview</p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="inline-flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors">
              <Download className="w-5 h-5 mr-2" />
              Export Data
            </button>
            <div className="text-right">
              <p className="text-sm text-gray-500">Last updated</p>
              <p className="font-medium text-gray-900">
                {new Date().toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Metrics */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Total Companies"
            value={metrics.total_companies}
            icon={Building2}
            color="bg-gradient-to-r from-blue-500 to-blue-600"
            change="+2 this month"
          />
          <MetricCard
            title="Active Companies"
            value={metrics.active_companies}
            icon={CheckCircle}
            color="bg-gradient-to-r from-emerald-500 to-green-600"
            change={`${Math.round((metrics.active_companies / metrics.total_companies) * 100)}% active`}
          />
          <MetricCard
            title="Total Revenue"
            value={`$${metrics.total_revenue.toLocaleString()}`}
            icon={DollarSign}
            color="bg-gradient-to-r from-purple-500 to-indigo-600"
            change={`+${metrics.growth_rate}% growth`}
          />
          <MetricCard
            title="Avg Conversion"
            value={`${metrics.avg_conversion_rate}%`}
            icon={TrendingUp}
            color="bg-gradient-to-r from-amber-500 to-orange-600"
            change="+2.3% improvement"
          />
        </div>
      )}

      {/* Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Monthly Revenue</h2>
            <div className="text-sm text-gray-500">Last 6 months</div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: 'none',
                  borderRadius: '12px',
                  color: 'white'
                }}
                formatter={(value) => [`$${value.toLocaleString()}`, 'Revenue']}
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stroke="#3b82f6" 
                fill="url(#colorRevenue)" 
                strokeWidth={3}
              />
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.1}/>
                </linearGradient>
              </defs>
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Subscription Tier Distribution */}
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Subscription Tiers</h2>
            <div className="text-sm text-gray-500">Current distribution</div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tierDistribution}
                cx="50%"
                cy="50%"
                outerRadius={80}
                innerRadius={40}
                paddingAngle={2}
                dataKey="value"
              >
                {tierDistribution.map((entry, index) => (
                  <Cell key={`tier-cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: 'none',
                  borderRadius: '12px',
                  color: 'white'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-4 mt-4">
            {tierDistribution.map((item) => (
              <div key={item.name} className="text-center">
                <div className="flex items-center justify-center space-x-2 mb-1">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-sm font-medium text-gray-700">{item.name}</span>
                </div>
                <div className="text-lg font-bold text-gray-900">{item.value}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search companies..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={filterTier}
                onChange={(e) => setFilterTier(e.target.value)}
                className="px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Tiers</option>
                <option value="premium">Premium</option>
                <option value="professional">Professional</option>
                <option value="basic">Basic</option>
              </select>
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </div>

      {/* Company Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredCompanies.map((company) => (
          <CompanyCard key={company.id} company={company} />
        ))}
      </div>

      {filteredCompanies.length === 0 && (
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-12 text-center">
          <AlertTriangle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No companies found</h3>
          <p className="text-gray-500">Try adjusting your search or filter criteria.</p>
        </div>
      )}
    </div>
  );
};