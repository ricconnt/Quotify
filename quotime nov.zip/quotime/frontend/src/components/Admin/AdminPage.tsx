/**
 * AdminPage Component
 * 
 * Professional admin control panel for system-wide management.
 * Displays system health, user activity, and administrative controls.
 * 
 * TODO: DB INTEGRATION
 * - Replace static system data with API call to GET /api/admin/dashboard
 * - Implement user management via GET /api/admin/users
 * - Add system configuration updates PUT /api/admin/settings
 * - Connect to audit log API GET /api/admin/audit-logs
 * - Integrate backup and maintenance controls
 */

import React from 'react';
import {
  Box,
  VStack,
  HStack,
  Flex,
  Heading,
  Text,
  Card,
  CardBody,
  SimpleGrid,
  Icon,
  Progress,
  Divider,
  Button
} from '@chakra-ui/react';
import { 
  Shield, 
  Users, 
  Settings, 
  Database,
  Activity,
  AlertTriangle,
  CheckCircle,
  Clock,
  Server,
  HardDrive,
  Cpu,
  FileText
} from 'lucide-react';

export const AdminPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API calls
  // const { data: systemHealth } = await fetch('/api/admin/dashboard').then(r => r.json());
  const systemMetrics = {
    totalUsers: 156,
    activeUsers: 42,
    totalInquiries: 2847,
    systemUptime: '99.8%',
    storageUsed: 68,
    cpuUsage: 45,
    memoryUsage: 62,
  };

  const recentActivity = [
    { id: 1, action: 'User created', user: 'admin@quotime.com', time: '5 min ago', type: 'success' },
    { id: 2, action: 'Settings updated', user: 'manager@quotime.com', time: '12 min ago', type: 'info' },
    { id: 3, action: 'Database backup', user: 'System', time: '1 hour ago', type: 'success' },
    { id: 4, action: 'Failed login attempt', user: 'unknown@domain.com', time: '2 hours ago', type: 'warning' },
  ];

  return (
    <VStack spacing={6} align="stretch">
      {/* Header */}
      <Flex align="center" gap={3}>
        <Flex
          w="14"
          h="14"
          bgGradient="linear(to-br, red.500, pink.600)"
          borderRadius="xl"
          align="center"
          justify="center"
        >
          <Icon as={Shield} w={7} h={7} color="white" />
        </Flex>
        <Box>
          <Heading size="xl" color="gray.900">Admin Control Panel</Heading>
          <Text color="gray.600" mt={1}>System management and monitoring</Text>
        </Box>
      </Flex>

      {/* System Health Cards */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
        <Card
          bg="white"
          shadow="xl"
          borderRadius="2xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl' }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex align="center" justify="space-between">
              <Box>
                <Text fontSize="sm" fontWeight="semibold" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                  Total Users
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  {systemMetrics.totalUsers}
                </Text>
                <Text fontSize="sm" color="green.600" mt={1}>
                  ↑ 12% from last month
                </Text>
              </Box>
              <Flex
                p={4}
                borderRadius="2xl"
                bgGradient="linear(to-br, blue.500, indigo.600)"
                shadow="lg"
              >
                <Icon as={Users} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          shadow="xl"
          borderRadius="2xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl' }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex align="center" justify="space-between">
              <Box>
                <Text fontSize="sm" fontWeight="semibold" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                  Active Now
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  {systemMetrics.activeUsers}
                </Text>
                <Text fontSize="sm" color="gray.600" mt={1}>
                  Online users
                </Text>
              </Box>
              <Flex
                p={4}
                borderRadius="2xl"
                bgGradient="linear(to-br, green.500, teal.600)"
                shadow="lg"
              >
                <Icon as={Activity} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          shadow="xl"
          borderRadius="2xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl' }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex align="center" justify="space-between">
              <Box>
                <Text fontSize="sm" fontWeight="semibold" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                  Total Inquiries
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  {systemMetrics.totalInquiries.toLocaleString()}
                </Text>
                <Text fontSize="sm" color="blue.600" mt={1}>
                  All time
                </Text>
              </Box>
              <Flex
                p={4}
                borderRadius="2xl"
                bgGradient="linear(to-br, purple.500, violet.600)"
                shadow="lg"
              >
                <Icon as={FileText} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          shadow="xl"
          borderRadius="2xl"
          border="1px"
          borderColor="gray.100"
          _hover={{ shadow: '2xl' }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex align="center" justify="space-between">
              <Box>
                <Text fontSize="sm" fontWeight="semibold" color="gray.500" textTransform="uppercase" letterSpacing="wide">
                  System Uptime
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  {systemMetrics.systemUptime}
                </Text>
                <Text fontSize="sm" color="green.600" mt={1}>
                  Excellent
                </Text>
              </Box>
              <Flex
                p={4}
                borderRadius="2xl"
                bgGradient="linear(to-br, green.500, teal.600)"
                shadow="lg"
              >
                <Icon as={CheckCircle} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* System Resources */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={6}>
          <Heading size="md" color="gray.900" mb={6}>System Resources</Heading>
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
            <Box>
              <Flex align="center" justify="space-between" mb={2}>
                <HStack spacing={2}>
                  <Icon as={HardDrive} w={5} h={5} color="blue.500" />
                  <Text fontWeight="semibold" color="gray.700">Storage</Text>
                </HStack>
                <Text fontSize="sm" fontWeight="bold" color="gray.900">
                  {systemMetrics.storageUsed}%
                </Text>
              </Flex>
              <Progress
                value={systemMetrics.storageUsed}
                size="md"
                colorScheme="blue"
                borderRadius="full"
                bg="gray.200"
              />
            </Box>

            <Box>
              <Flex align="center" justify="space-between" mb={2}>
                <HStack spacing={2}>
                  <Icon as={Cpu} w={5} h={5} color="green.500" />
                  <Text fontWeight="semibold" color="gray.700">CPU Usage</Text>
                </HStack>
                <Text fontSize="sm" fontWeight="bold" color="gray.900">
                  {systemMetrics.cpuUsage}%
                </Text>
              </Flex>
              <Progress
                value={systemMetrics.cpuUsage}
                size="md"
                colorScheme="green"
                borderRadius="full"
                bg="gray.200"
              />
            </Box>

            <Box>
              <Flex align="center" justify="space-between" mb={2}>
                <HStack spacing={2}>
                  <Icon as={Server} w={5} h={5} color="purple.500" />
                  <Text fontWeight="semibold" color="gray.700">Memory</Text>
                </HStack>
                <Text fontSize="sm" fontWeight="bold" color="gray.900">
                  {systemMetrics.memoryUsage}%
                </Text>
              </Flex>
              <Progress
                value={systemMetrics.memoryUsage}
                size="md"
                colorScheme="purple"
                borderRadius="full"
                bg="gray.200"
              />
            </Box>
          </SimpleGrid>
        </CardBody>
      </Card>

      {/* Recent Activity */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={0}>
          <Box p={6} borderBottom="1px" borderColor="gray.200">
            <Heading size="md" color="gray.900">Recent Activity</Heading>
            <Text fontSize="sm" color="gray.500" mt={1}>System audit log</Text>
          </Box>
          <VStack spacing={0} divider={<Divider />} align="stretch">
            {recentActivity.map((activity) => (
              <Box
                key={activity.id}
                p={6}
                _hover={{ bg: 'gray.50' }}
                transition="background 0.2s"
              >
                <Flex align="center" justify="space-between">
                  <HStack spacing={4}>
                    <Flex
                      w={10}
                      h={10}
                      borderRadius="lg"
                      align="center"
                      justify="center"
                      bg={
                        activity.type === 'success' ? 'green.100' :
                        activity.type === 'warning' ? 'yellow.100' :
                        'blue.100'
                      }
                    >
                      <Icon
                        as={
                          activity.type === 'success' ? CheckCircle :
                          activity.type === 'warning' ? AlertTriangle :
                          Settings
                        }
                        w={5}
                        h={5}
                        color={
                          activity.type === 'success' ? 'green.600' :
                          activity.type === 'warning' ? 'yellow.600' :
                          'blue.600'
                        }
                      />
                    </Flex>
                    <Box>
                      <Text fontWeight="semibold" color="gray.900">{activity.action}</Text>
                      <Text fontSize="sm" color="gray.600">{activity.user}</Text>
                    </Box>
                  </HStack>
                  <HStack spacing={2} fontSize="sm" color="gray.500">
                    <Icon as={Clock} w={4} h={4} />
                    <Text>{activity.time}</Text>
                  </HStack>
                </Flex>
              </Box>
            ))}
          </VStack>
        </CardBody>
      </Card>

      {/* Quick Actions */}
      <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
        <Button
          as={Card}
          h="auto"
          p={6}
          bg="white"
          border="2px"
          borderColor="gray.200"
          borderRadius="2xl"
          _hover={{
            borderColor: 'blue.300',
            shadow: 'xl',
            transform: 'translateY(-2px)'
          }}
          transition="all 0.3s"
          cursor="pointer"
          textAlign="left"
          display="block"
        >
          <Flex
            w={12}
            h={12}
            bgGradient="linear(to-r, blue.500, indigo.600)"
            borderRadius="xl"
            align="center"
            justify="center"
            mb={4}
            _groupHover={{ transform: 'scale(1.1)' }}
            transition="transform 0.3s"
          >
            <Icon as={Users} w={6} h={6} color="white" />
          </Flex>
          <Heading size="sm" color="gray.900" mb={2}>Manage Users</Heading>
          <Text fontSize="sm" color="gray.600">Add, edit, or remove user accounts</Text>
        </Button>

        <Button
          as={Card}
          h="auto"
          p={6}
          bg="white"
          border="2px"
          borderColor="gray.200"
          borderRadius="2xl"
          _hover={{
            borderColor: 'purple.300',
            shadow: 'xl',
            transform: 'translateY(-2px)'
          }}
          transition="all 0.3s"
          cursor="pointer"
          textAlign="left"
          display="block"
        >
          <Flex
            w={12}
            h={12}
            bgGradient="linear(to-r, purple.500, violet.600)"
            borderRadius="xl"
            align="center"
            justify="center"
            mb={4}
            _groupHover={{ transform: 'scale(1.1)' }}
            transition="transform 0.3s"
          >
            <Icon as={Settings} w={6} h={6} color="white" />
          </Flex>
          <Heading size="sm" color="gray.900" mb={2}>System Settings</Heading>
          <Text fontSize="sm" color="gray.600">Configure application preferences</Text>
        </Button>

        <Button
          as={Card}
          h="auto"
          p={6}
          bg="white"
          border="2px"
          borderColor="gray.200"
          borderRadius="2xl"
          _hover={{
            borderColor: 'green.300',
            shadow: 'xl',
            transform: 'translateY(-2px)'
          }}
          transition="all 0.3s"
          cursor="pointer"
          textAlign="left"
          display="block"
        >
          <Flex
            w={12}
            h={12}
            bgGradient="linear(to-r, green.500, teal.600)"
            borderRadius="xl"
            align="center"
            justify="center"
            mb={4}
            _groupHover={{ transform: 'scale(1.1)' }}
            transition="transform 0.3s"
          >
            <Icon as={Database} w={6} h={6} color="white" />
          </Flex>
          <Heading size="sm" color="gray.900" mb={2}>Database Backup</Heading>
          <Text fontSize="sm" color="gray.600">Backup and restore data</Text>
        </Button>
      </SimpleGrid>
    </VStack>
  );
};
