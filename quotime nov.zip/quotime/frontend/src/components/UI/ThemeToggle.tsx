import React from 'react';
import { Sun, Moon, Monitor } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';

export const ThemeToggle: React.FC = () => {
  const { theme, resolvedTheme, setTheme } = useTheme();

  const getIcon = (iconTheme: string) => {
    switch (iconTheme) {
      case 'light':
        return Sun;
      case 'dark':  
        return Moon;
      case 'system':
        return Monitor;
      default:
        return Sun;
    }
  };

  const themes = [
    { value: 'light', label: 'Light', icon: Sun },
    { value: 'dark', label: 'Dark', icon: Moon },
    { value: 'system', label: 'System', icon: Monitor }
  ] as const;

  return (
    <div className="theme-toggle-container">
      {/* Quick Toggle Button */}
      <button
        onClick={() => setTheme(resolvedTheme === 'light' ? 'dark' : 'light')}
        className="theme-quick-toggle"
        aria-label={`Switch to ${resolvedTheme === 'light' ? 'dark' : 'light'} mode`}
      >
        {resolvedTheme === 'light' ? (
          <Moon className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        ) : (
          <Sun className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        )}
      </button>

      {/* Dropdown Theme Selector */}
      <div className="theme-dropdown-container">
        <select
          value={theme}
          onChange={(e) => setTheme(e.target.value as 'light' | 'dark' | 'system')}
          className="theme-dropdown"
          aria-label="Select theme"
        >
          {themes.map((themeOption) => (
            <option key={themeOption.value} value={themeOption.value}>
              {themeOption.label}
            </option>
          ))}
        </select>
      </div>

      {/* Theme Cards (for settings page) */}
      <div className="theme-cards-container hidden">
        {themes.map((themeOption) => {
          const IconComponent = themeOption.icon;
          const isActive = theme === themeOption.value;
          
          return (
            <button
              key={themeOption.value}
              onClick={() => setTheme(themeOption.value)}
              className={`theme-card ${isActive ? 'active' : ''}`}
              aria-label={`Switch to ${themeOption.label.toLowerCase()} theme`}
            >
              <div className="theme-card-content">
                <IconComponent className="w-6 h-6" />
                <span className="theme-card-label">{themeOption.label}</span>
                {isActive && (
                  <div className="theme-card-indicator">
                    <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ThemeToggle;