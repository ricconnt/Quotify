/**
 * AppointmentsPage Component
 * 
 * Professional placeholder page for appointment scheduling functionality.
 * Displays a skeleton UI with calendar view and upcoming appointments list.
 * 
 * TODO: DB INTEGRATION
 * - Replace static appointment data with API call to GET /api/appointments
 * - Implement appointment creation via POST /api/appointments
 * - Add real-time calendar integration for scheduling
 * - Connect to backend appointment management system
 */

import React from 'react';
import {
  Box,
  Button,
  Card,
  CardBody,
  Flex,
  Grid,
  Heading,
  Text,
  VStack,
  HStack,
  Icon,
  IconButton,
  Badge,
  SimpleGrid,
  Divider
} from '@chakra-ui/react';
import { Calendar, Clock, User, MapPin, Plus, ChevronRight, ChevronLeft } from 'lucide-react';

export const AppointmentsPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API call
  // const { data: appointments } = await fetch('/api/appointments').then(r => r.json());
  const upcomingAppointments = [
    { id: 1, customer: 'Sarah Johnson', type: 'Site Visit', date: 'Dec 18, 2024', time: '10:00 AM', location: '123 Main St', status: 'confirmed' },
    { id: 2, customer: 'Mike Wilson', type: 'Consultation', date: 'Dec 19, 2024', time: '2:00 PM', location: 'Virtual Meeting', status: 'pending' },
    { id: 3, customer: 'Emma Davis', type: 'Follow-up', date: 'Dec 20, 2024', time: '11:30 AM', location: '456 Oak Ave', status: 'confirmed' },
  ];

  return (
    <VStack spacing={6} align="stretch">
      {/* Header with Action Button */}
      <Flex justify="space-between" align="center">
        <Box>
          <Heading size="xl" color="gray.900">Appointments</Heading>
          <Text color="gray.600" mt={1}>Manage and schedule customer meetings</Text>
        </Box>
        <Button
          leftIcon={<Icon as={Plus} w={5} h={5} />}
          colorScheme="blue"
          bgGradient="linear(to-r, blue.500, blue.600)"
          _hover={{
            bgGradient: 'linear(to-r, blue.600, blue.700)',
            transform: 'translateY(-2px)',
            shadow: 'xl'
          }}
          size="lg"
          borderRadius="xl"
          shadow="lg"
          transition="all 0.3s"
        >
          Schedule Appointment
        </Button>
      </Flex>

      {/* Calendar View */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={8}>
          <Flex justify="space-between" align="center" mb={8}>
            <Heading size="lg" color="gray.900">December 2024</Heading>
            <HStack spacing={3}>
              <IconButton
                aria-label="Previous month"
                icon={<Icon as={ChevronLeft} w={5} h={5} />}
                variant="ghost"
                _hover={{ bg: 'gray.100', shadow: 'md' }}
                borderRadius="xl"
                color="gray.600"
              />
              <IconButton
                aria-label="Next month"
                icon={<Icon as={ChevronRight} w={5} h={5} />}
                variant="ghost"
                _hover={{ bg: 'gray.100', shadow: 'md' }}
                borderRadius="xl"
                color="gray.600"
              />
            </HStack>
          </Flex>
          
          {/* Calendar Grid */}
          <Grid templateColumns="repeat(7, 1fr)" gap={3}>
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <Box
                key={day}
                textAlign="center"
                fontSize="sm"
                fontWeight="bold"
                color="gray.500"
                textTransform="uppercase"
                letterSpacing="wide"
                py={3}
              >
                {day}
              </Box>
            ))}
            {[...Array(35)].map((_, i) => (
              <Box
                key={i}
                aspectRatio={1}
                display="flex"
                alignItems="center"
                justifyContent="center"
                borderRadius="xl"
                cursor="pointer"
                transition="all 0.2s"
                bg={
                  i === 17 || i === 18 || i === 19
                    ? 'blue.500'
                    : 'gray.50'
                }
                color={
                  i === 17 || i === 18 || i === 19
                    ? 'white'
                    : 'gray.700'
                }
                fontWeight={
                  i === 17 || i === 18 || i === 19
                    ? 'bold'
                    : 'medium'
                }
                border="1px"
                borderColor={
                  i === 17 || i === 18 || i === 19
                    ? 'blue.500'
                    : 'gray.100'
                }
                _hover={{
                  bg: i === 17 || i === 18 || i === 19 ? 'blue.600' : 'gray.100',
                  shadow: 'md',
                  transform: 'scale(1.05)'
                }}
              >
                {i > 4 && i < 35 ? i - 4 : ''}
              </Box>
            ))}
          </Grid>
        </CardBody>
      </Card>

      {/* Upcoming Appointments */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <Box p={8} borderBottom="1px" borderColor="gray.100">
          <Heading size="lg" color="gray.900">Upcoming Appointments</Heading>
          <Text fontSize="sm" color="gray.500" mt={1}>Next 7 days</Text>
        </Box>
        <VStack divider={<Divider />} spacing={0} align="stretch">
          {upcomingAppointments.map((appointment) => (
            <Box
              key={appointment.id}
              p={6}
              _hover={{
                bgGradient: 'linear(to-r, blue.50, transparent)',
                transition: 'all 0.2s'
              }}
              transition="all 0.2s"
            >
              <Flex justify="space-between" align="flex-start">
                <Flex flex="1" direction="column">
                  <HStack spacing={3} mb={3}>
                    <Flex
                      w={12}
                      h={12}
                      bgGradient="linear(to-br, blue.500, blue.600)"
                      borderRadius="xl"
                      align="center"
                      justify="center"
                      _groupHover={{ transform: 'scale(1.1)' }}
                      transition="transform 0.3s"
                    >
                      <Icon as={Calendar} w={6} h={6} color="white" />
                    </Flex>
                    <Box>
                      <Text fontWeight="bold" color="gray.900">{appointment.customer}</Text>
                      <Text fontSize="sm" color="gray.600">{appointment.type}</Text>
                    </Box>
                  </HStack>
                  <SimpleGrid columns={{ base: 1, md: 3 }} spacing={3} ml={15}>
                    <HStack fontSize="sm" color="gray.600">
                      <Icon as={Clock} w={4} h={4} color="blue.500" />
                      <Text>{appointment.date} at {appointment.time}</Text>
                    </HStack>
                    <HStack fontSize="sm" color="gray.600">
                      <Icon as={MapPin} w={4} h={4} color="green.500" />
                      <Text>{appointment.location}</Text>
                    </HStack>
                    <Box>
                      <Badge
                        colorScheme={appointment.status === 'confirmed' ? 'green' : 'yellow'}
                        borderRadius="full"
                        px={3}
                        py={1}
                        fontSize="xs"
                      >
                        {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                      </Badge>
                    </Box>
                  </SimpleGrid>
                </Flex>
                <IconButton
                  aria-label="View details"
                  icon={<Icon as={ChevronRight} w={5} h={5} />}
                  variant="ghost"
                  ml={4}
                  _hover={{ bg: 'blue.100' }}
                  color="gray.400"
                  borderRadius="lg"
                />
              </Flex>
            </Box>
          ))}
        </VStack>
      </Card>

      {/* Quick Stats */}
      <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
        <Card
          bgGradient="linear(to-br, blue.50, blue.100)"
          borderRadius="xl"
          border="2px"
          borderColor="blue.100"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="blue.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  This Week
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>12</Text>
                <Text fontSize="sm" color="gray.600" mt={1}>Appointments scheduled</Text>
              </Box>
              <Flex
                w={14}
                h={14}
                bg="blue.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={Calendar} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
        
        <Card
          bgGradient="linear(to-br, green.50, green.100)"
          borderRadius="xl"
          border="2px"
          borderColor="green.100"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="green.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Confirmed
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>8</Text>
                <Text fontSize="sm" color="gray.600" mt={1}>Ready to go</Text>
              </Box>
              <Flex
                w={14}
                h={14}
                bg="green.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={Clock} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
        
        <Card
          bgGradient="linear(to-br, purple.50, purple.100)"
          borderRadius="xl"
          border="2px"
          borderColor="purple.100"
        >
          <CardBody>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="purple.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Completion
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>94%</Text>
                <Text fontSize="sm" color="gray.600" mt={1}>Show-up rate</Text>
              </Box>
              <Flex
                w={14}
                h={14}
                bg="purple.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={User} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>
    </VStack>
  );
};
