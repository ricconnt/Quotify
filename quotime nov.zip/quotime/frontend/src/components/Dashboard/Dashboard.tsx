/**
 * Dashboard Component
 * 
 * Main dashboard page displaying key business metrics, analytics, and recent activity.
 * Shows role-based statistics and provides quick access to core features.
 * 
 * Features:
 * - Real-time business metrics (inquiries, conversion rate, response time)
 * - Employee performance tracking
 * - Recent inquiry feed
 * - Quick action buttons for common tasks
 * 
 * ================================================================================
 * TODO: DATABASE INTEGRATION - PostgreSQL Setup & Migration Guide
 * ================================================================================
 * 
 * CURRENT STATE: Using mock data from mockInquiries.ts and mockAnalytics.ts
 * TARGET STATE: Real-time data from PostgreSQL database via Flask REST API
 * 
 * STEP 1: DATABASE SCHEMA SETUP (PostgreSQL)
 * -------------------------------------------
 * Ensure these tables exist with proper relationships:
 * 
 * - companies (id, name, email, subscription_tier, features_enabled, created_at)
 * - employees (id, name, email, role, company_id, is_active, created_at)
 * - inquiries (id, customer_name, customer_email, job_type, status, urgency, 
 *              assigned_employee_id, company_id, created_at, updated_at)
 * 
 * STEP 2: BACKEND API ENDPOINTS TO IMPLEMENT
 * -------------------------------------------
 * Replace mock services in frontend/src/services/api.ts:
 * 
 * Analytics Data:
 * - GET /api/analytics/manager → Returns AnalyticsData type
 *   - Calculate: total_inquiries, conversion_rate, avg_response_time
 *   - Aggregate: top_performing_employees, inquiries_by_source, weekly_trends
 *   - Filter by company_id from authenticated user
 * 
 * Recent Inquiries:
 * - GET /api/inquiries?limit=5&sort=created_at:desc
 *   - Returns most recent 5 inquiries for dashboard display
 *   - Include: id, customer_name, status, job_type, urgency, created_at
 * 
 * STEP 3: POSTGRESQL QUERY EXAMPLES
 * ----------------------------------
 * Calculate conversion rate:
 *   SELECT 
 *     ROUND((COUNT(*) FILTER (WHERE status = 'completed')::numeric / 
 *            COUNT(*)::numeric) * 100, 2) as conversion_rate
 *   FROM inquiries WHERE company_id = $1;
 * 
 * Top performing employees:
 *   SELECT e.name, COUNT(i.id) as completed_inquiries, AVG(i.response_time) as avg_response_time
 *   FROM employees e
 *   LEFT JOIN inquiries i ON e.id = i.assigned_employee_id AND i.status = 'completed'
 *   WHERE e.company_id = $1
 *   GROUP BY e.id, e.name
 *   ORDER BY completed_inquiries DESC LIMIT 5;
 * 
 * STEP 4: FRONTEND INTEGRATION
 * -----------------------------
 * 1. Remove mockInquiries.ts and mockAnalytics.ts files
 * 2. In api.ts, uncomment real API calls and remove mock service calls
 * 3. Update AuthContext to store user's company_id for filtering
 * 4. Add error handling for failed API requests
 * 
 * STEP 5: REAL-TIME UPDATES (Optional Enhancement)
 * -------------------------------------------------
 * - Implement WebSocket connection for live inquiry notifications
 * - Use Flask-SocketIO on backend for real-time events
 * - Subscribe to: 'new_inquiry', 'status_updated', 'assignment_changed'
 * - Auto-refresh dashboard metrics when events received
 * 
 * STEP 6: PERFORMANCE OPTIMIZATION
 * ---------------------------------
 * - Add Redis caching for analytics data (5-15 min TTL)
 * - Use database indexes on: status, created_at, assigned_employee_id, company_id
 * - Implement pagination for inquiry lists
 * - Consider materialized views for complex analytics queries
 */

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Flex,
  Heading,
  Text,
  SimpleGrid,
  Card,
  CardHeader,
  CardBody,
  Button,
  Spinner,
  Center,
  Badge,
  VStack,
  HStack,
  Icon,
  Skeleton,
  SkeletonCircle,
  SkeletonText
} from '@chakra-ui/react';
import { 
  TrendingUp, 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { useAuth } from '../../contexts/AuthContext';
import { analyticsAPI, inquiryAPI } from '../../services/api';
import type { AnalyticsData, Inquiry } from '../../types';

/**
 * StatCard Component Props
 * @interface StatCardProps
 * @property {string} title - The metric title/label
 * @property {string | number} value - The current metric value
 * @property {React.ComponentType} icon - Lucide icon component to display
 * @property {string} colorScheme - Chakra color scheme for the card
 * @property {string} [change] - Optional percentage change indicator (e.g., "+12%")
 */
interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ComponentType<any>;
  colorScheme: string;
  change?: string;
}

/**
 * StatCard Component
 * 
 * Displays a single metric card with icon, value, and optional trend indicator.
 * Features hover animations and responsive design.
 * 
 * @param {StatCardProps} props - Component props
 * @returns {JSX.Element} Styled metric card
 */
const StatCard: React.FC<StatCardProps> = ({ title, value, icon: IconComponent, colorScheme, change }) => {
  const isPositive = change && change.startsWith('+');
  const isNegative = change && change.startsWith('-');
  
  return (
    <Card
      bg="white"
      shadow="lg"
      borderRadius="xl"
      border="1px"
      borderColor="gray.100"
      _hover={{
        shadow: 'xl',
        transform: 'translateY(-4px)',
        transition: 'all 0.3s'
      }}
      transition="all 0.3s"
    >
      <CardBody>
        <Flex justify="space-between" align="flex-start">
          <Box flex="1">
            <Text
              fontSize="sm"
              fontWeight="semibold"
              color="gray.500"
              textTransform="uppercase"
              letterSpacing="wide"
            >
              {title}
            </Text>
            <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={3} mb={2}>
              {value}
            </Text>
            {change && (
              <HStack spacing={1}>
                <Icon
                  as={isPositive ? ArrowUpRight : isNegative ? ArrowDownRight : TrendingUp}
                  w={4}
                  h={4}
                  color={isPositive ? 'green.600' : isNegative ? 'red.600' : 'gray.600'}
                />
                <Text
                  fontSize="sm"
                  fontWeight="medium"
                  color={isPositive ? 'green.600' : isNegative ? 'red.600' : 'gray.600'}
                >
                  {change}
                </Text>
              </HStack>
            )}
          </Box>
          <Flex
            w={16}
            h={16}
            bg={`${colorScheme}.500`}
            borderRadius="xl"
            align="center"
            justify="center"
            shadow="md"
          >
            <Icon as={IconComponent} w={7} h={7} color="white" />
          </Flex>
        </Flex>
      </CardBody>
    </Card>
  );
};

export const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [recentInquiries, setRecentInquiries] = useState<Inquiry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // TODO: DB INTEGRATION - Employee performance data now comes from analytics.top_performing_employees
  // This is calculated in the backend from completed inquiries grouped by employee
  // Ensure the backend includes this data in GET /api/analytics/manager response
  const employeePerformance = analytics?.top_performing_employees?.map((emp) => ({
    name: emp.name.split(' ').map((n: string) => n.charAt(0)).join('') + '.',
    completed: emp.completed_inquiries,
    rating: 4.5 + Math.random() * 0.4
  })) || [
    { name: 'Mike W.', completed: 18, rating: 4.8 },
    { name: 'Sarah E.', completed: 15, rating: 4.9 },
    { name: 'Tom E.', completed: 12, rating: 4.7 },
    { name: 'John M.', completed: 8, rating: 4.6 }
  ];

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        
        if (user?.role === 'manager' || user?.role === 'admin') {
          const analyticsData = await analyticsAPI.getManagerAnalytics();
          setAnalytics(analyticsData);
        }
        
        const inquiries = await inquiryAPI.getAll();
        setRecentInquiries(inquiries.slice(0, 5));
      } catch (error) {
        console.error('Failed to load dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadDashboardData();
  }, [user]);

  if (isLoading) {
    return (
      <VStack spacing={6} align="stretch">
        {/* Header Skeleton */}
        <Flex justify="space-between" align="center">
          <Box>
            <Skeleton height="32px" width="250px" borderRadius="md" />
            <SkeletonText mt={2} noOfLines={1} spacing="4" skeletonHeight="4" width="200px" />
          </Box>
          <Skeleton height="20px" width="180px" borderRadius="md" />
        </Flex>

        {/* Stats Grid Skeleton */}
        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
          {[1, 2, 3, 4].map((i) => (
            <Card
              key={i}
              bg="white"
              shadow="lg"
              borderRadius="xl"
              border="1px"
              borderColor="gray.100"
            >
              <CardBody>
                <Flex justify="space-between" align="flex-start">
                  <Box flex="1">
                    <Skeleton height="14px" width="120px" borderRadius="md" />
                    <Skeleton height="36px" width="80px" mt={3} borderRadius="md" />
                    <Skeleton height="14px" width="90px" mt={2} borderRadius="md" />
                  </Box>
                  <SkeletonCircle size="64px" />
                </Flex>
              </CardBody>
            </Card>
          ))}
        </SimpleGrid>

        {/* Recent Inquiries Skeleton */}
        <Card bg="white" shadow="md" borderRadius="xl" border="1px" borderColor="gray.200">
          <CardHeader borderBottom="1px" borderColor="gray.200">
            <Skeleton height="24px" width="160px" borderRadius="md" />
          </CardHeader>
          <CardBody p={0}>
            <VStack divider={<Box borderBottom="1px" borderColor="gray.200" />} spacing={0}>
              {[1, 2, 3, 4, 5].map((i) => (
                <Box key={i} p={6} w="full">
                  <Flex justify="space-between" align="flex-start">
                    <Box flex="1">
                      <Skeleton height="18px" width="150px" borderRadius="md" />
                      <Skeleton height="14px" width="220px" mt={2} borderRadius="md" />
                      <Skeleton height="14px" width="300px" mt={2} borderRadius="md" />
                    </Box>
                    <VStack align="flex-end" ml={4} spacing={2}>
                      <Skeleton height="24px" width="80px" borderRadius="full" />
                      <Skeleton height="14px" width="60px" borderRadius="md" />
                    </VStack>
                  </Flex>
                </Box>
              ))}
            </VStack>
          </CardBody>
        </Card>

        {/* Quick Actions Skeleton */}
        <Card bg="white" shadow="lg" borderRadius="xl" border="1px" borderColor="gray.100">
          <CardBody>
            <Skeleton height="24px" width="140px" mb={6} borderRadius="md" />
            <SimpleGrid columns={{ base: 1, md: 3 }} spacing={4}>
              {[1, 2, 3].map((i) => (
                <Box
                  key={i}
                  p={6}
                  border="2px"
                  borderColor="gray.100"
                  borderRadius="md"
                >
                  <SkeletonCircle size="48px" mb={4} />
                  <Skeleton height="20px" width="140px" mb={2} borderRadius="md" />
                  <SkeletonText noOfLines={2} spacing="2" skeletonHeight="3" />
                </Box>
              ))}
            </SimpleGrid>
          </CardBody>
        </Card>
      </VStack>
    );
  }

  return (
    <VStack spacing={6} align="stretch">
      {/* Header */}
      <Flex justify="space-between" align="center">
        <Box>
          <Heading size="lg" color="gray.900">
            Welcome back, {user?.name?.split(' ')[0]}!
          </Heading>
          <Text color="gray.600" mt={1}>
            Here's what's happening with your business today.
          </Text>
        </Box>
        <Box textAlign="right">
          <Text fontSize="sm" color="gray.500">
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </Text>
        </Box>
      </Flex>

      {/* Stats Grid - Show different stats based on role */}
      {(user?.role === 'manager' || user?.role === 'admin') && analytics && (
        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
          <StatCard
            title="Total Inquiries"
            value={analytics.total_inquiries}
            icon={MessageSquare}
            colorScheme="blue"
            change="+12% vs last month"
          />
          <StatCard
            title="Conversion Rate"
            value={`${analytics.conversion_rate}%`}
            icon={TrendingUp}
            colorScheme="green"
            change="+2.4% vs last month"
          />
          <StatCard
            title="Avg Response Time"
            value={`${Math.round(analytics.avg_response_time / 60)}h`}
            icon={Clock}
            colorScheme="orange"
            change="-15 min vs last month"
          />
          <StatCard
            title="Completed Jobs"
            value={analytics.completed_inquiries}
            icon={CheckCircle}
            colorScheme="purple"
            change="+8% vs last month"
          />
        </SimpleGrid>
      )}

      {/* Employee-specific stats */}
      {user?.role === 'employee' && (
        <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
          <StatCard
            title="My Inquiries"
            value={recentInquiries.filter(i => i.assigned_employee_id === user.id).length}
            icon={MessageSquare}
            colorScheme="blue"
          />
          <StatCard
            title="Pending Actions"
            value={recentInquiries.filter(i => 
              i.assigned_employee_id === user.id && i.status === 'in_progress'
            ).length}
            icon={AlertCircle}
            colorScheme="orange"
          />
          <StatCard
            title="Completed Today"
            value={recentInquiries.filter(i => 
              i.assigned_employee_id === user.id && 
              i.status === 'completed' &&
              new Date(i.updated_at).toDateString() === new Date().toDateString()
            ).length}
            icon={CheckCircle}
            colorScheme="green"
          />
        </SimpleGrid>
      )}

      {/* Recent Inquiries */}
      <Card bg="white" shadow="md" borderRadius="xl" border="1px" borderColor="gray.200">
        <CardHeader borderBottom="1px" borderColor="gray.200">
          <Heading size="md" color="gray.900">Recent Inquiries</Heading>
        </CardHeader>
        <CardBody p={0}>
          {recentInquiries.length > 0 ? (
            <VStack divider={<Box borderBottom="1px" borderColor="gray.200" />} spacing={0}>
              {recentInquiries.map((inquiry) => (
                <Box
                  key={inquiry.id}
                  p={6}
                  w="full"
                  _hover={{ bg: 'gray.50' }}
                  transition="background 0.2s"
                >
                  <Flex justify="space-between" align="flex-start">
                    <Box flex="1">
                      <Text fontWeight="medium" color="gray.900">
                        {inquiry.customer_name}
                      </Text>
                      <Text fontSize="sm" color="gray.600" mt={1}>
                        {inquiry.job_type} - {inquiry.location}
                      </Text>
                      <Text fontSize="sm" color="gray.500" mt={1}>
                        {inquiry.description.substring(0, 100)}...
                      </Text>
                    </Box>
                    <VStack align="flex-end" ml={4} spacing={1}>
                      <Badge
                        colorScheme={
                          inquiry.status === 'new' ? 'blue' :
                          inquiry.status === 'in_progress' ? 'orange' :
                          inquiry.status === 'completed' ? 'green' :
                          'gray'
                        }
                        borderRadius="full"
                        px={2}
                        py={1}
                      >
                        {inquiry.status.replace('_', ' ')}
                      </Badge>
                      <Text fontSize="sm" color="gray.500">
                        {new Date(inquiry.created_at).toLocaleDateString()}
                      </Text>
                    </VStack>
                  </Flex>
                </Box>
              ))}
            </VStack>
          ) : (
            <Center p={8}>
              <Text color="gray.500">No inquiries found</Text>
            </Center>
          )}
        </CardBody>
      </Card>

      {/* Quick Actions */}
      <Card bg="white" shadow="lg" borderRadius="xl" border="1px" borderColor="gray.100">
        <CardBody>
          <Heading size="md" color="gray.900" mb={6}>Quick Actions</Heading>
          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={4}>
            <Button
              onClick={() => navigate('/inquiries')}
              h="auto"
              p={6}
              border="2px"
              borderColor="gray.100"
              bg="white"
              _hover={{
                borderColor: 'blue.300',
                bg: 'blue.50',
                shadow: 'lg',
                transform: 'translateY(-2px)'
              }}
              transition="all 0.3s"
              textAlign="left"
              display="flex"
              flexDirection="column"
              alignItems="flex-start"
            >
              <Flex
                w={12}
                h={12}
                bg="blue.500"
                borderRadius="xl"
                align="center"
                justify="center"
                mb={4}
              >
                <Icon as={MessageSquare} w={6} h={6} color="white" />
              </Flex>
              <Text fontWeight="bold" color="gray.900" mb={2}>View All Inquiries</Text>
              <Text fontSize="sm" color="gray.600" whiteSpace="normal" noOfLines={2}>Manage customer requests and track progress</Text>
            </Button>
            
            <Button
              onClick={() => navigate('/quotes')}
              h="auto"
              p={6}
              border="2px"
              borderColor="gray.100"
              bg="white"
              _hover={{
                borderColor: 'green.300',
                bg: 'green.50',
                shadow: 'lg',
                transform: 'translateY(-2px)'
              }}
              transition="all 0.3s"
              textAlign="left"
              display="flex"
              flexDirection="column"
              alignItems="flex-start"
            >
              <Flex
                w={12}
                h={12}
                bg="green.500"
                borderRadius="xl"
                align="center"
                justify="center"
                mb={4}
              >
                <Icon as={DollarSign} w={6} h={6} color="white" />
              </Flex>
              <Text fontWeight="bold" color="gray.900" mb={2}>Create Quote</Text>
              <Text fontSize="sm" color="gray.600" whiteSpace="normal" noOfLines={2}>Generate professional estimates quickly</Text>
            </Button>
            
            <Button
              onClick={() => navigate('/appointments')}
              h="auto"
              p={6}
              border="2px"
              borderColor="gray.100"
              bg="white"
              _hover={{
                borderColor: 'purple.300',
                bg: 'purple.50',
                shadow: 'lg',
                transform: 'translateY(-2px)'
              }}
              transition="all 0.3s"
              textAlign="left"
              display="flex"
              flexDirection="column"
              alignItems="flex-start"
            >
              <Flex
                w={12}
                h={12}
                bg="purple.500"
                borderRadius="xl"
                align="center"
                justify="center"
                mb={4}
              >
                <Icon as={Clock} w={6} h={6} color="white" />
              </Flex>
              <Text fontWeight="bold" color="gray.900" mb={2}>Schedule Appointment</Text>
              <Text fontSize="sm" color="gray.600" whiteSpace="normal" noOfLines={2}>Book customer meetings and site visits</Text>
            </Button>
          </SimpleGrid>
        </CardBody>
      </Card>

      {/* Employee Performance - Only for Managers/Admins */}
      {(user?.role === 'manager' || user?.role === 'admin') && (
        <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
          <CardBody p={8}>
            <Flex justify="space-between" align="center" mb={8}>
              <Box>
                <Heading size="lg" color="gray.900">Team Performance</Heading>
                <Text fontSize="sm" color="gray.500" mt={1}>Jobs completed this month</Text>
              </Box>
              <Badge colorScheme="blue" px={4} py={2} borderRadius="lg" fontSize="sm">
                This Month
              </Badge>
            </Flex>
            <ResponsiveContainer width="100%" height={320}>
              <BarChart data={employeePerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="#64748b" 
                  fontSize={13}
                  fontWeight={500}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={13}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    border: 'none',
                    borderRadius: '16px',
                    color: 'white',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
                    padding: '12px 16px'
                  }}
                  cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
                />
                <Bar 
                  dataKey="completed" 
                  fill="url(#gradientBar)" 
                  radius={[12, 12, 0, 0]}
                  maxBarSize={60}
                />
                <defs>
                  <linearGradient id="gradientBar" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3b82f6" stopOpacity={1}/>
                    <stop offset="100%" stopColor="#1d4ed8" stopOpacity={1}/>
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
            <SimpleGrid columns={4} spacing={4} mt={8}>
              {employeePerformance.map((emp: any) => (
                <Box
                  key={emp.name}
                  textAlign="center"
                  p={4}
                  bg="blue.50"
                  borderRadius="xl"
                  border="1px"
                  borderColor="blue.100"
                >
                  <Text fontWeight="bold" color="gray.900">{emp.name}</Text>
                  <Text fontSize="sm" color="blue.600" mt={1} fontWeight="semibold">
                    ⭐ {emp.rating}/5.0
                  </Text>
                </Box>
              ))}
            </SimpleGrid>
          </CardBody>
        </Card>
      )}
    </VStack>
  );
};
