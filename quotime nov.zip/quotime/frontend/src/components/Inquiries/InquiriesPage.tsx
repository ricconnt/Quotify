/**
 * InquiriesPage Component
 * 
 * Comprehensive inquiry management interface for tracking customer requests.
 * Features search, filtering, status updates, and detailed inquiry views.
 * 
 * Features:
 * - Real-time inquiry list with search and filtering
 * - Status badge indicators (new, in_progress, quoted, scheduled, completed, cancelled)
 * - Urgency level tracking
 * - Detailed inquiry modal view
 * - Status update functionality
 * 
 * ================================================================================
 * TODO: DATABASE INTEGRATION - Inquiry Management Backend Setup
 * ================================================================================
 * 
 * CURRENT STATE: Using mock data from mockInquiries.ts with localStorage persistence
 * TARGET STATE: Full CRUD operations via PostgreSQL database and Flask REST API
 * 
 * STEP 1: DATABASE TABLE SCHEMA (PostgreSQL)
 * -------------------------------------------
 * CREATE TABLE inquiries (
 *   id SERIAL PRIMARY KEY,
 *   company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
 *   customer_name VARCHAR(255) NOT NULL,
 *   customer_email VARCHAR(255) NOT NULL,
 *   customer_phone VARCHAR(50),
 *   job_type VARCHAR(100) NOT NULL,
 *   description TEXT NOT NULL,
 *   urgency VARCHAR(20) CHECK (urgency IN ('low', 'medium', 'high', 'emergency')),
 *   status VARCHAR(20) CHECK (status IN ('new', 'in_progress', 'quoted', 'scheduled', 'completed', 'cancelled')),
 *   location VARCHAR(500),
 *   source VARCHAR(50),
 *   assigned_employee_id INTEGER REFERENCES employees(id) ON DELETE SET NULL,
 *   priority_score INTEGER DEFAULT 50,
 *   tags TEXT[], -- PostgreSQL array type for tags
 *   images_urls TEXT[], -- Array of image URLs
 *   response_time INTEGER, -- Minutes to first response
 *   first_response_at TIMESTAMP,
 *   preferred_contact_method VARCHAR(20),
 *   preferred_time_slot TIMESTAMP,
 *   budget_range VARCHAR(50),
 *   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 *   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 * );
 * 
 * CREATE INDEX idx_inquiries_company_id ON inquiries(company_id);
 * CREATE INDEX idx_inquiries_status ON inquiries(status);
 * CREATE INDEX idx_inquiries_created_at ON inquiries(created_at DESC);
 * CREATE INDEX idx_inquiries_assigned_employee ON inquiries(assigned_employee_id);
 * 
 * STEP 2: BACKEND API ENDPOINTS TO IMPLEMENT
 * -------------------------------------------
 * GET /api/inquiries
 *   - Query params: ?status=new&search=plumbing&page=1&limit=20
 *   - Returns: { inquiries: Inquiry[], total: number, page: number }
 *   - Filter by company_id from authenticated user
 *   - Support full-text search on customer_name, customer_email, description
 * 
 * GET /api/inquiries/:id
 *   - Returns single inquiry with full details
 *   - Include assigned employee info if available
 * 
 * POST /api/inquiries
 *   - Create new inquiry from customer form submission
 *   - Auto-calculate priority_score based on urgency and job_type
 *   - Set status to 'new' by default
 * 
 * PUT /api/inquiries/:id
 *   - Update inquiry details
 *   - Track updated_at timestamp
 *   - Log changes in audit trail (optional)
 * 
 * PUT /api/inquiries/:id/status
 *   - Body: { status: string }
 *   - Update only status field
 *   - Trigger notifications to assigned employee
 * 
 * POST /api/inquiries/:id/assign
 *   - Body: { employee_id: number }
 *   - Assign inquiry to specific employee
 *   - Send email/SMS notification to employee
 * 
 * DELETE /api/inquiries/:id (Admin only)
 *   - Soft delete or permanent delete based on business rules
 * 
 * STEP 3: SEARCH & FILTER IMPLEMENTATION
 * ---------------------------------------
 * PostgreSQL Full-Text Search Example:
 *   SELECT * FROM inquiries 
 *   WHERE company_id = $1 
 *   AND (
 *     customer_name ILIKE $2 OR 
 *     customer_email ILIKE $2 OR 
 *     description ILIKE $2
 *   )
 *   AND ($3::varchar IS NULL OR status = $3)
 *   ORDER BY created_at DESC
 *   LIMIT $4 OFFSET $5;
 * 
 * STEP 4: FRONTEND INTEGRATION
 * -----------------------------
 * 1. Remove mockInquiries.ts and update api.ts
 * 2. Uncomment real API calls in inquiryAPI object
 * 3. Implement pagination UI for inquiry list
 * 4. Add debounced search to prevent excessive API calls
 * 5. Handle loading states and error messages
 * 
 * STEP 5: CUSTOMER COMPANY DETAILS & IMAGES
 * ------------------------------------------
 * See separate TODO section below for image upload implementation
 */

import React, { useState, useEffect } from 'react';
import {
  Box,
  Flex,
  Heading,
  Text,
  Input,
  Select,
  Button,
  Badge,
  Card,
  CardBody,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Spinner,
  SimpleGrid,
  VStack,
  HStack,
  Icon,
  Center,
  InputGroup,
  InputLeftElement
} from '@chakra-ui/react';
import { 
  Search, 
  Filter, 
  Plus, 
  Eye, 
  Edit2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Phone, 
  Mail, 
  MapPin,
  Calendar,
  User,
  MessageSquare
} from 'lucide-react';
import { inquiryAPI } from '../../services/api';
import { useAuth } from '../../contexts/AuthContext';
import type { Inquiry } from '../../types';

/**
 * StatusBadge Component
 * 
 * Displays a colored badge with icon for inquiry status.
 * 
 * @param {Object} props - Component props
 * @param {string} props.status - Inquiry status (new, in_progress, quoted, etc.)
 * @returns {JSX.Element} Styled status badge
 */
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const statusConfig = {
    'new': { colorScheme: 'blue', icon: MessageSquare },
    'in_progress': { colorScheme: 'orange', icon: Clock }, 
    'quoted': { colorScheme: 'purple', icon: CheckCircle2 },
    'scheduled': { colorScheme: 'cyan', icon: Calendar },
    'completed': { colorScheme: 'green', icon: CheckCircle2 },
    'cancelled': { colorScheme: 'red', icon: AlertCircle }
  };
  
  const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.new;
  const IconComponent = config.icon;
  
  return (
    <Badge
      colorScheme={config.colorScheme}
      borderRadius="full"
      px={3}
      py={1}
      fontSize="sm"
      fontWeight="medium"
      display="inline-flex"
      alignItems="center"
      gap={1}
    >
      <Icon as={IconComponent} w={4} h={4} />
      {status.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
    </Badge>
  );
};

/**
 * UrgencyBadge Component
 * 
 * Displays urgency level indicator for inquiries.
 * 
 * @param {Object} props - Component props  
 * @param {string} props.urgency - Urgency level (low, normal, high)
 * @returns {JSX.Element} Styled urgency badge
 */
const UrgencyBadge: React.FC<{ urgency: string }> = ({ urgency }) => {
  const urgencyConfig = {
    'low': { colorScheme: 'gray' },
    'normal': { colorScheme: 'blue' }, 
    'high': { colorScheme: 'red' }
  };
  
  const config = urgencyConfig[urgency as keyof typeof urgencyConfig] || urgencyConfig.normal;
  
  return (
    <Badge
      colorScheme={config.colorScheme}
      borderRadius="md"
      px={2}
      py={1}
      fontSize="xs"
      fontWeight="bold"
      display="inline-flex"
      alignItems="center"
      gap={1}
    >
      {urgency === 'high' && <Icon as={AlertCircle} w={3} h={3} />}
      {urgency.toUpperCase()}
    </Badge>
  );
};

export const InquiriesPage: React.FC = () => {
  const { user } = useAuth();
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedInquiry, setSelectedInquiry] = useState<Inquiry | null>(null);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [statusUpdateInquiry, setStatusUpdateInquiry] = useState<Inquiry | null>(null);
  const [newStatus, setNewStatus] = useState('');
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [assignInquiry, setAssignInquiry] = useState<Inquiry | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  
  // Permission check: Only managers and admins can assign employees
  const canAssignEmployees = user?.role === 'admin' || user?.role === 'manager';
  
  // TODO: DB INTEGRATION - Replace with actual employee data from GET /api/employees
  const HARDCODED_EMPLOYEES = [
    { id: 1, name: 'Mike Wilson', role: 'Senior Technician' },
    { id: 2, name: 'Sarah Johnson', role: 'Technician' },
    { id: 3, name: 'Tom Brown', role: 'Technician' },
    { id: 4, name: 'Lisa Anderson', role: 'Senior Technician' },
  ];
  
  useEffect(() => {
    loadInquiries();
  }, []);
  
  const loadInquiries = async () => {
    try {
      setLoading(true);
      const data = await inquiryAPI.getAll();
      setInquiries(data);
    } catch (error) {
      console.error('Failed to load inquiries:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleStatusUpdate = async (inquiry: Inquiry) => {
    setStatusUpdateInquiry(inquiry);
    setNewStatus(inquiry.status);
    setShowStatusModal(true);
  };
  
  const updateInquiryStatus = async () => {
    if (!statusUpdateInquiry || !newStatus) return;
    
    try {
      // Update locally first (optimistic update)
      setInquiries(prev => 
        prev.map(inquiry => 
          inquiry.id === statusUpdateInquiry.id 
            ? { ...inquiry, status: newStatus as Inquiry['status'] }
            : inquiry
        )
      );
      
      // Call the backend API to update status
      await inquiryAPI.update(statusUpdateInquiry.id, { status: newStatus as Inquiry['status'] });
      
      setShowStatusModal(false);
      setStatusUpdateInquiry(null);
      setNewStatus('');
    } catch (error) {
      console.error('Failed to update inquiry status:', error);
      // Revert optimistic update on error
      loadInquiries();
    }
  };
  
  const handleAssignEmployee = (inquiry: Inquiry) => {
    setAssignInquiry(inquiry);
    setSelectedEmployee(inquiry.assigned_employee_id?.toString() || '');
    setShowAssignModal(true);
  };
  
  const assignEmployee = async () => {
    if (!assignInquiry || !selectedEmployee) return;
    
    try {
      const employeeId = parseInt(selectedEmployee);
      
      // Update locally first (optimistic update)
      setInquiries(prev => 
        prev.map(inquiry => 
          inquiry.id === assignInquiry.id 
            ? { ...inquiry, assigned_employee_id: employeeId }
            : inquiry
        )
      );
      
      // TODO: DB INTEGRATION - Call backend API to assign employee
      // await inquiryAPI.assign(assignInquiry.id, employeeId);
      
      setShowAssignModal(false);
      setAssignInquiry(null);
      setSelectedEmployee('');
    } catch (error) {
      console.error('Failed to assign employee:', error);
      // Revert optimistic update on error
      loadInquiries();
    }
  };
  
  const filteredInquiries = inquiries.filter(inquiry => {
    const matchesSearch = inquiry.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         inquiry.customer_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         inquiry.job_type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || inquiry.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  
  if (loading) {
    return (
      <Box minH="100vh" bg="gray.50" p={6}>
        <Center h="64">
          <VStack spacing={4}>
            <Spinner size="xl" color="blue.500" thickness="4px" />
            <Text color="gray.600" fontSize="lg" fontWeight="medium">
              Loading inquiries...
            </Text>
          </VStack>
        </Center>
      </Box>
    );
  }
  
  return (
    <Box minH="100vh" bg="gray.50" p={6}>
      {/* Header */}
      <Card
        bg="white"
        shadow="xl"
        borderRadius="2xl"
        border="1px"
        borderColor="gray.100"
        mb={8}
      >
        <CardBody p={6}>
          <Flex
            direction={{ base: 'column', lg: 'row' }}
            align={{ lg: 'center' }}
            justify="space-between"
          >
            <Box mb={{ base: 4, lg: 0 }}>
              <Heading size="xl" color="gray.900" mb={2}>
                Customer Inquiries
              </Heading>
              <Text color="gray.600">
                Manage and track all customer service requests
              </Text>
            </Box>
            <Flex align="center" gap={4}>
              <Button
                leftIcon={<Icon as={Plus} w={5} h={5} />}
                colorScheme="blue"
                bgGradient="linear(to-r, blue.500, blue.600)"
                _hover={{
                  bgGradient: 'linear(to-r, blue.600, blue.700)',
                  shadow: 'xl'
                }}
                size="lg"
                borderRadius="xl"
                shadow="lg"
                transition="all 0.2s"
              >
                New Inquiry
              </Button>
            </Flex>
          </Flex>
        </CardBody>
      </Card>
      
      {/* Filters and Search */}
      <Card
        bg="white"
        shadow="xl"
        borderRadius="2xl"
        border="1px"
        borderColor="gray.100"
        mb={6}
      >
        <CardBody p={6}>
          <Flex
            direction={{ base: 'column', lg: 'row' }}
            align={{ lg: 'center' }}
            justify="space-between"
            gap={4}
          >
            <Box flex="1" maxW={{ lg: 'md' }}>
              <InputGroup>
                <InputLeftElement pointerEvents="none" h="full">
                  <Icon as={Search} color="gray.400" w={5} h={5} />
                </InputLeftElement>
                <Input
                  placeholder="Search by customer name, email, or job type..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  borderRadius="xl"
                  border="1px"
                  borderColor="gray.200"
                  _focus={{
                    ring: 2,
                    ringColor: 'blue.500',
                    borderColor: 'transparent'
                  }}
                  py={3}
                />
              </InputGroup>
            </Box>
            <Flex align="center" gap={4}>
              <HStack spacing={2}>
                <Icon as={Filter} color="gray.400" w={5} h={5} />
                <Select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  borderRadius="xl"
                  border="1px"
                  borderColor="gray.200"
                  _focus={{
                    ring: 2,
                    ringColor: 'blue.500',
                    borderColor: 'transparent'
                  }}
                  w="auto"
                >
                  <option value="all">All Status</option>
                  <option value="new">New</option>
                  <option value="in_progress">In Progress</option>
                  <option value="quoted">Quoted</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </Select>
              </HStack>
            </Flex>
          </Flex>
        </CardBody>
      </Card>
      
      {/* Inquiries Grid */}
      <VStack spacing={6} align="stretch">
        {filteredInquiries.length === 0 ? (
          <Card
            bg="white"
            shadow="xl"
            borderRadius="2xl"
            border="1px"
            borderColor="gray.100"
          >
            <CardBody p={12}>
              <Center>
                <VStack spacing={4}>
                  <Icon as={MessageSquare} w={16} h={16} color="gray.300" />
                  <Heading size="md" color="gray.900">
                    No inquiries found
                  </Heading>
                  <Text color="gray.500" textAlign="center" mb={2}>
                    There are no inquiries matching your search criteria.
                  </Text>
                  <Button
                    leftIcon={<Icon as={Plus} w={5} h={5} />}
                    colorScheme="blue"
                    bgGradient="linear(to-r, blue.500, blue.600)"
                    _hover={{
                      bgGradient: 'linear(to-r, blue.600, blue.700)'
                    }}
                    size="md"
                    borderRadius="xl"
                  >
                    Create First Inquiry
                  </Button>
                </VStack>
              </Center>
            </CardBody>
          </Card>
        ) : (
          filteredInquiries.map((inquiry) => (
            <Card
              key={inquiry.id}
              bg="white"
              shadow="xl"
              borderRadius="2xl"
              border="1px"
              borderColor="gray.100"
              _hover={{
                shadow: '2xl',
                transform: 'translateY(-4px)',
                transition: 'all 0.3s'
              }}
              transition="all 0.3s"
            >
              <CardBody p={6}>
                <Flex
                  direction={{ base: 'column', lg: 'row' }}
                  align={{ lg: 'center' }}
                  justify="space-between"
                >
                  <Box flex="1" pr={{ lg: 6 }}>
                    <Flex align="center" justify="space-between" mb={4} flexWrap="wrap" gap={2}>
                      <HStack spacing={4} flexWrap="wrap">
                        <HStack spacing={2}>
                          <Icon as={User} w={5} h={5} color="gray.400" />
                          <Heading size="md" color="gray.900">
                            {inquiry.customer_name}
                          </Heading>
                        </HStack>
                        <StatusBadge status={inquiry.status} />
                        <UrgencyBadge urgency={inquiry.urgency} />
                      </HStack>
                    </Flex>
                    
                    <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4} mb={4}>
                      <HStack spacing={2} color="gray.600">
                        <Icon as={Mail} w={4} h={4} />
                        <Text fontSize="sm">{inquiry.customer_email}</Text>
                      </HStack>
                      <HStack spacing={2} color="gray.600">
                        <Icon as={Phone} w={4} h={4} />
                        <Text fontSize="sm">{inquiry.customer_phone}</Text>
                      </HStack>
                      <HStack spacing={2} color="gray.600">
                        <Icon as={MapPin} w={4} h={4} />
                        <Text fontSize="sm">{inquiry.location}</Text>
                      </HStack>
                    </SimpleGrid>
                    
                    <Box mb={4}>
                      <HStack spacing={2} mb={2}>
                        <Icon as={MessageSquare} w={4} h={4} color="blue.500" />
                        <Text fontSize="sm" fontWeight="semibold" color="gray.700">
                          {inquiry.job_type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </Text>
                      </HStack>
                      <Text color="gray.700" lineHeight="relaxed">
                        {inquiry.description}
                      </Text>
                    </Box>
                    
                    <HStack spacing={4} fontSize="sm" color="gray.500" flexWrap="wrap">
                      <HStack spacing={1}>
                        <Icon as={Calendar} w={4} h={4} />
                        <Text>Created: {new Date(inquiry.created_at).toLocaleDateString()}</Text>
                      </HStack>
                      {inquiry.preferred_time_slot && (
                        <HStack spacing={1}>
                          <Icon as={Clock} w={4} h={4} />
                          <Text>Preferred: {inquiry.preferred_time_slot}</Text>
                        </HStack>
                      )}
                    </HStack>
                  </Box>
                  
                  <VStack spacing={3} mt={{ base: 4, lg: 0 }} w={{ base: 'full', lg: 'auto' }}>
                    <Button
                      onClick={() => setSelectedInquiry(inquiry)}
                      leftIcon={<Icon as={Eye} w={4} h={4} />}
                      colorScheme="blue"
                      variant="outline"
                      bg="blue.50"
                      color="blue.700"
                      borderRadius="xl"
                      _hover={{
                        bg: 'blue.100'
                      }}
                      w="full"
                    >
                      View Details
                    </Button>
                    <Button
                      onClick={() => handleStatusUpdate(inquiry)}
                      leftIcon={<Icon as={Edit2} w={4} h={4} />}
                      colorScheme="green"
                      variant="outline"
                      bg="green.50"
                      color="green.700"
                      borderRadius="xl"
                      _hover={{
                        bg: 'green.100'
                      }}
                      w="full"
                    >
                      Update Status
                    </Button>
                    {canAssignEmployees && (
                      <Button
                        onClick={() => handleAssignEmployee(inquiry)}
                        leftIcon={<Icon as={User} w={4} h={4} />}
                        colorScheme="purple"
                        variant="outline"
                        bg="purple.50"
                        color="purple.700"
                        borderRadius="xl"
                        _hover={{
                          bg: 'purple.100'
                        }}
                        w="full"
                      >
                        {inquiry.assigned_employee_id ? 'Reassign' : 'Assign'} Employee
                      </Button>
                    )}
                  </VStack>
                </Flex>
              </CardBody>
            </Card>
          ))
        )}
      </VStack>
      
      {/* Stats Summary */}
      <Card
        bg="white"
        shadow="xl"
        borderRadius="2xl"
        border="1px"
        borderColor="gray.100"
        mt={8}
      >
        <CardBody p={6}>
          <Heading size="md" color="gray.900" mb={4}>
            Summary
          </Heading>
          <SimpleGrid columns={{ base: 2, lg: 6 }} spacing={4}>
            {['new', 'in_progress', 'quoted', 'scheduled', 'completed', 'cancelled'].map(status => {
              const count = inquiries.filter(i => i.status === status).length;
              return (
                <Box
                  key={status}
                  textAlign="center"
                  p={4}
                  bg="gray.50"
                  borderRadius="xl"
                >
                  <Text fontSize="2xl" fontWeight="bold" color="gray.900">
                    {count}
                  </Text>
                  <Text fontSize="sm" color="gray.600" textTransform="capitalize">
                    {status.replace('_', ' ')}
                  </Text>
                </Box>
              );
            })}
          </SimpleGrid>
        </CardBody>
      </Card>
      
      {/* Status Update Modal */}
      <Modal isOpen={showStatusModal} onClose={() => setShowStatusModal(false)}>
        <ModalOverlay bg="blackAlpha.600" />
        <ModalContent borderRadius="2xl" maxW="md" mx={4}>
          <ModalHeader>
            <Heading size="md" color="gray.900">
              Update Status for {statusUpdateInquiry?.customer_name}
            </Heading>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl>
              <FormLabel fontSize="sm" fontWeight="medium" color="gray.700">
                New Status
              </FormLabel>
              <Select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                borderRadius="xl"
                border="1px"
                borderColor="gray.300"
                _focus={{
                  ring: 2,
                  ringColor: 'blue.500',
                  borderColor: 'transparent'
                }}
              >
                <option value="new">New</option>
                <option value="in_progress">In Progress</option>
                <option value="quoted">Quoted</option>
                <option value="scheduled">Scheduled</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </Select>
            </FormControl>
          </ModalBody>
          <ModalFooter gap={4}>
            <Button
              onClick={() => setShowStatusModal(false)}
              variant="outline"
              borderColor="gray.300"
              color="gray.700"
              borderRadius="xl"
              _hover={{ bg: 'gray.50' }}
              flex="1"
            >
              Cancel
            </Button>
            <Button
              onClick={updateInquiryStatus}
              colorScheme="blue"
              bgGradient="linear(to-r, blue.500, blue.600)"
              _hover={{
                bgGradient: 'linear(to-r, blue.600, blue.700)'
              }}
              borderRadius="xl"
              flex="1"
            >
              Update Status
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      
      {/* Employee Assignment Modal */}
      <Modal isOpen={showAssignModal} onClose={() => {
        setShowAssignModal(false);
        setAssignInquiry(null);
        setSelectedEmployee('');
      }}>
        <ModalOverlay bg="blackAlpha.600" />
        <ModalContent borderRadius="2xl" maxW="md" mx={4}>
          <ModalHeader>
            <Heading size="md" color="gray.900">
              Assign Employee to {assignInquiry?.customer_name}
            </Heading>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <FormControl>
              <FormLabel fontSize="sm" fontWeight="medium" color="gray.700">
                Select Employee
              </FormLabel>
              <Select
                value={selectedEmployee}
                onChange={(e) => setSelectedEmployee(e.target.value)}
                borderRadius="xl"
                border="1px"
                borderColor="gray.300"
                _focus={{
                  ring: 2,
                  ringColor: 'purple.500',
                  borderColor: 'transparent'
                }}
              >
                <option value="">-- Select Employee --</option>
                {HARDCODED_EMPLOYEES.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.role})
                  </option>
                ))}
              </Select>
            </FormControl>
          </ModalBody>
          <ModalFooter gap={4}>
            <Button
              onClick={() => {
                setShowAssignModal(false);
                setAssignInquiry(null);
                setSelectedEmployee('');
              }}
              variant="outline"
              borderColor="gray.300"
              color="gray.700"
              borderRadius="xl"
              _hover={{ bg: 'gray.50' }}
              flex="1"
            >
              Cancel
            </Button>
            <Button
              onClick={assignEmployee}
              isDisabled={!selectedEmployee}
              colorScheme="purple"
              bgGradient="linear(to-r, purple.500, purple.600)"
              _hover={{
                bgGradient: 'linear(to-r, purple.600, purple.700)'
              }}
              borderRadius="xl"
              flex="1"
            >
              Assign Employee
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      
      {/* Details Modal */}
      <Modal 
        isOpen={!!selectedInquiry} 
        onClose={() => setSelectedInquiry(null)}
        size="2xl"
      >
        <ModalOverlay bg="blackAlpha.600" />
        <ModalContent borderRadius="2xl" mx={4} maxH="90vh">
          <ModalHeader>
            <Heading size="lg" color="gray.900">
              Inquiry Details
            </Heading>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody overflowY="auto">
            {selectedInquiry && (
              <VStack spacing={6} align="stretch">
                {/* Customer Information */}
                <Box bg="gray.50" borderRadius="xl" p={4}>
                  <Heading size="sm" color="gray.900" mb={3}>
                    Customer Information
                  </Heading>
                  <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Name
                      </Text>
                      <Text color="gray.900">{selectedInquiry.customer_name}</Text>
                    </Box>
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Email
                      </Text>
                      <Text color="gray.900">{selectedInquiry.customer_email}</Text>
                    </Box>
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Phone
                      </Text>
                      <Text color="gray.900">{selectedInquiry.customer_phone}</Text>
                    </Box>
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Address
                      </Text>
                      <Text color="gray.900">{selectedInquiry.location}</Text>
                    </Box>
                  </SimpleGrid>
                </Box>
                
                {/* Job Details */}
                <Box bg="blue.50" borderRadius="xl" p={4}>
                  <Heading size="sm" color="gray.900" mb={3}>
                    Job Details
                  </Heading>
                  <VStack spacing={3} align="stretch">
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Job Type
                      </Text>
                      <Text color="gray.900" textTransform="capitalize">
                        {selectedInquiry.job_type.replace('_', ' ')}
                      </Text>
                    </Box>
                    <Box>
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Description
                      </Text>
                      <Text color="gray.900" lineHeight="relaxed">
                        {selectedInquiry.description}
                      </Text>
                    </Box>
                    {selectedInquiry.preferred_time_slot && (
                      <Box>
                        <Text fontSize="sm" fontWeight="medium" color="gray.500">
                          Preferred Time
                        </Text>
                        <Text color="gray.900">{selectedInquiry.preferred_time_slot}</Text>
                      </Box>
                    )}
                  </VStack>
                </Box>
                
                {/* Status Information */}
                <Box bg="green.50" borderRadius="xl" p={4}>
                  <Heading size="sm" color="gray.900" mb={3}>
                    Status Information
                  </Heading>
                  <VStack spacing={3} align="stretch">
                    <Flex justify="space-between" align="center">
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Current Status
                      </Text>
                      <StatusBadge status={selectedInquiry.status} />
                    </Flex>
                    <Flex justify="space-between" align="center">
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Urgency
                      </Text>
                      <UrgencyBadge urgency={selectedInquiry.urgency} />
                    </Flex>
                    <Flex justify="space-between">
                      <Text fontSize="sm" fontWeight="medium" color="gray.500">
                        Created
                      </Text>
                      <Text color="gray.900">
                        {new Date(selectedInquiry.created_at).toLocaleString()}
                      </Text>
                    </Flex>
                    {selectedInquiry.updated_at && (
                      <Flex justify="space-between">
                        <Text fontSize="sm" fontWeight="medium" color="gray.500">
                          Last Updated
                        </Text>
                        <Text color="gray.900">
                          {new Date(selectedInquiry.updated_at).toLocaleString()}
                        </Text>
                      </Flex>
                    )}
                  </VStack>
                </Box>
              </VStack>
            )}
          </ModalBody>
          <ModalFooter>
            <Button
              onClick={() => setSelectedInquiry(null)}
              colorScheme="blue"
              borderRadius="xl"
              w="full"
            >
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Box>
  );
};
