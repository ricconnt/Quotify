/**
 * CompaniesPage Component
 * 
 * Professional company management interface displaying client companies.
 * Features company cards with contact info and service history.
 * 
 * TODO: DB INTEGRATION
 * - Replace static company data with API call to GET /api/companies
 * - Implement company creation via POST /api/companies
 * - Add company update functionality PUT /api/companies/:id
 * - Connect to company details endpoint for full information
 * - Integrate company service history from GET /api/companies/:id/services
 */

import React from 'react';
import { 
  Building, 
  MapPin, 
  Phone, 
  Mail, 
  Users, 
  DollarSign,
  TrendingUp,
  Plus,
  Search,
  Filter,
  ChevronRight
} from 'lucide-react';

export const CompaniesPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API call
  // const { data: companies } = await fetch('/api/companies').then(r => r.json());
  const companies = [
    {
      id: 1,
      name: 'Acme Corporation',
      industry: 'Technology',
      location: 'San Francisco, CA',
      phone: '+1 (415) 555-0123',
      email: 'contact@acme.com',
      employees: 250,
      revenue: 125000,
      status: 'active'
    },
    {
      id: 2,
      name: 'Global Industries',
      industry: 'Manufacturing',
      location: 'Chicago, IL',
      phone: '+1 (312) 555-0456',
      email: 'info@globalind.com',
      employees: 450,
      revenue: 245000,
      status: 'active'
    },
    {
      id: 3,
      name: 'Tech Innovations Inc',
      industry: 'Software',
      location: 'Austin, TX',
      phone: '+1 (512) 555-0789',
      email: 'hello@techinnovations.com',
      employees: 85,
      revenue: 78000,
      status: 'active'
    },
    {
      id: 4,
      name: 'Metro Retail Group',
      industry: 'Retail',
      location: 'New York, NY',
      phone: '+1 (212) 555-0321',
      email: 'contact@metroretail.com',
      employees: 1200,
      revenue: 520000,
      status: 'active'
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header with Actions */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Companies</h1>
          <p className="text-gray-600 mt-1">Manage your client organizations</p>
        </div>
        <button className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-0.5">
          <Plus className="w-5 h-5 mr-2" />
          Add Company
        </button>
      </div>

      {/* Search and Filter Bar */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search companies..."
            className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors"
          />
        </div>
        <button className="inline-flex items-center px-4 py-3 bg-white border-2 border-gray-200 text-gray-700 font-semibold rounded-xl hover:border-gray-300 hover:shadow-lg transition-all">
          <Filter className="w-5 h-5 mr-2" />
          Filter
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-6 border-2 border-blue-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-blue-600 uppercase tracking-wide">Total Companies</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">{companies.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
              <Building className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-6 border-2 border-green-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-green-600 uppercase tracking-wide">Active Clients</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {companies.filter(c => c.status === 'active').length}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-2xl p-6 border-2 border-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-purple-600 uppercase tracking-wide">Total Employees</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                {companies.reduce((sum, c) => sum + c.employees, 0).toLocaleString()}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-2xl p-6 border-2 border-orange-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-orange-600 uppercase tracking-wide">Total Revenue</p>
              <p className="text-3xl font-bold text-gray-900 mt-2">
                ${(companies.reduce((sum, c) => sum + c.revenue, 0) / 1000).toFixed(0)}K
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Companies Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {companies.map((company) => (
          <div key={company.id} className="bg-white rounded-2xl shadow-xl border border-gray-100 p-6 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 group">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <Building className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{company.name}</h3>
                  <p className="text-sm text-gray-500">{company.industry}</p>
                </div>
              </div>
              <button className="p-2 hover:bg-blue-100 rounded-lg transition-colors">
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="w-4 h-4 mr-3 text-blue-500" />
                {company.location}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Phone className="w-4 h-4 mr-3 text-green-500" />
                {company.phone}
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Mail className="w-4 h-4 mr-3 text-purple-500" />
                {company.email}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-gray-200 grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-xl">
                <p className="text-2xl font-bold text-blue-600">{company.employees}</p>
                <p className="text-xs text-gray-600 mt-1">Employees</p>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-xl">
                <p className="text-2xl font-bold text-green-600">${(company.revenue / 1000).toFixed(0)}K</p>
                <p className="text-xs text-gray-600 mt-1">Revenue</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
