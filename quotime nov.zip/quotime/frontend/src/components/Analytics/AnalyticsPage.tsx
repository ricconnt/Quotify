/**
 * AnalyticsPage Component
 * 
 * Professional analytics dashboard displaying business metrics and insights.
 * Features revenue tracking, conversion rates, and performance analytics.
 * 
 * ================================================================================
 * TODO: DATABASE INTEGRATION - Analytics & Reporting Backend Setup
 * ================================================================================
 * 
 * CURRENT STATE: Using hardcoded chart data and mock analytics
 * TARGET STATE: Real-time analytics calculated from PostgreSQL database
 * 
 * STEP 1: ANALYTICS DATA STRUCTURE (PostgreSQL Views)
 * ----------------------------------------------------
 * Create materialized views for performance:
 * 
 * CREATE MATERIALIZED VIEW analytics_summary AS
 * SELECT 
 *   company_id,
 *   DATE(created_at) as date,
 *   COUNT(*) as total_inquiries,
 *   COUNT(*) FILTER (WHERE status = 'new') as new_inquiries,
 *   COUNT(*) FILTER (WHERE status = 'completed') as completed_inquiries,
 *   AVG(response_time) FILTER (WHERE response_time IS NOT NULL) as avg_response_time
 * FROM inquiries
 * GROUP BY company_id, DATE(created_at);
 * 
 * -- Refresh view periodically (e.g., every hour via cron job):
 * REFRESH MATERIALIZED VIEW analytics_summary;
 * 
 * STEP 2: BACKEND API ENDPOINTS TO IMPLEMENT
 * -------------------------------------------
 * GET /api/analytics/dashboard
 *   - Query params: ?start_date=YYYY-MM-DD&end_date=YYYY-MM-DD
 *   - Returns: Complete analytics object with all charts data
 *   - Includes: revenue trends, conversion funnel, service breakdown
 * 
 * GET /api/analytics/revenue
 *   - Query params: ?period=6months or ?start_date=X&end_date=Y
 *   - Returns monthly revenue data for area chart
 *   - Calculate from quotes table: SUM(total_amount) WHERE status = 'accepted'
 * 
 * GET /api/analytics/conversions
 *   - Returns conversion funnel data:
 *     - Total inquiries → Quoted → Closed/Accepted
 *   - Calculate percentages for each stage
 * 
 * GET /api/analytics/services
 *   - Returns revenue breakdown by service type (Plumbing, HVAC, Electrical)
 *   - GROUP BY job_type with SUM of accepted quotes
 * 
 * GET /api/analytics/export
 *   - Export analytics data as CSV or PDF
 *   - Include date range, metrics, and charts
 * 
 * STEP 3: POSTGRESQL QUERIES FOR CHARTS
 * --------------------------------------
 * Revenue Trends (6-month area chart):
 *   SELECT 
 *     TO_CHAR(DATE_TRUNC('month', q.created_at), 'Mon') as month,
 *     SUM(q.total_amount::numeric) as revenue,
 *     COUNT(*) as quotes
 *   FROM quotes q
 *   WHERE q.company_id = $1 
 *   AND q.status = 'accepted'
 *   AND q.created_at >= CURRENT_DATE - INTERVAL '6 months'
 *   GROUP BY DATE_TRUNC('month', q.created_at)
 *   ORDER BY DATE_TRUNC('month', q.created_at);
 * 
 * Conversion Funnel (pie chart):
 *   SELECT 
 *     'Inquiries' as name, COUNT(*) as value
 *   FROM inquiries WHERE company_id = $1
 *   UNION ALL
 *   SELECT 'Quoted', COUNT(*) FROM inquiries WHERE company_id = $1 AND status IN ('quoted', 'scheduled', 'completed')
 *   UNION ALL
 *   SELECT 'Closed', COUNT(*) FROM inquiries WHERE company_id = $1 AND status = 'completed';
 * 
 * Service Revenue Breakdown (bar chart):
 *   SELECT 
 *     i.job_type as service,
 *     SUM(q.total_amount::numeric) as revenue
 *   FROM inquiries i
 *   JOIN quotes q ON q.inquiry_id = i.id
 *   WHERE i.company_id = $1 AND q.status = 'accepted'
 *   GROUP BY i.job_type
 *   ORDER BY revenue DESC;
 * 
 * STEP 4: FRONTEND INTEGRATION
 * -----------------------------
 * 1. Replace hardcoded chart data arrays with API calls
 * 2. Implement date range picker for filtering (react-datepicker)
 * 3. Add loading skeletons for charts while data loads
 * 4. Export functionality using libraries like jsPDF or csv-export
 * 5. Cache analytics data to reduce database load
 * 
 * STEP 5: PERFORMANCE OPTIMIZATION
 * ---------------------------------
 * - Use materialized views for complex aggregations
 * - Implement Redis caching (TTL: 15 minutes)
 * - Add database indexes on created_at, company_id, status
 * - Consider pre-calculating daily/weekly analytics via background job
 */

import React from 'react';
import {
  Box,
  Flex,
  Heading,
  Text,
  Button,
  SimpleGrid,
  Card,
  CardBody,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Icon,
  HStack,
  VStack
} from '@chakra-ui/react';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Target, 
  Calendar,
  Download,
  Filter
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

export const AnalyticsPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API calls
  // const { data: analytics } = await fetch('/api/analytics/dashboard').then(r => r.json());
  const revenueData = [
    { month: 'Jan', revenue: 45000, quotes: 32 },
    { month: 'Feb', revenue: 52000, quotes: 38 },
    { month: 'Mar', revenue: 48000, quotes: 35 },
    { month: 'Apr', revenue: 61000, quotes: 42 },
    { month: 'May', revenue: 55000, quotes: 39 },
    { month: 'Jun', revenue: 67000, quotes: 48 },
  ];

  const conversionData = [
    { name: 'Inquiries', value: 248, color: '#3b82f6' },
    { name: 'Quoted', value: 156, color: '#8b5cf6' },
    { name: 'Closed', value: 89, color: '#10b981' },
  ];

  const serviceData = [
    { service: 'Plumbing', revenue: 45000 },
    { service: 'Electrical', revenue: 38000 },
    { service: 'HVAC', revenue: 32000 },
    { service: 'Maintenance', revenue: 28000 },
  ];

  return (
    <VStack spacing={6} align="stretch">
      {/* Header with Actions */}
      <Flex justify="space-between" align="center">
        <Box>
          <Heading size="lg" color="gray.900">Analytics Dashboard</Heading>
          <Text color="gray.600" mt={1}>Track performance and business insights</Text>
        </Box>
        <HStack spacing={3}>
          <Button
            leftIcon={<Icon as={Filter} w={5} h={5} />}
            bg="white"
            border="2px"
            borderColor="gray.200"
            color="gray.700"
            fontWeight="semibold"
            borderRadius="xl"
            _hover={{
              borderColor: 'gray.300',
              shadow: 'lg'
            }}
            transition="all 0.3s"
          >
            Filter
          </Button>
          <Button
            leftIcon={<Icon as={Download} w={5} h={5} />}
            bgGradient="linear(to-r, blue.600, indigo.600)"
            color="white"
            fontWeight="semibold"
            borderRadius="xl"
            shadow="lg"
            _hover={{
              bgGradient: 'linear(to-r, blue.700, indigo.700)',
              shadow: 'xl'
            }}
            transition="all 0.3s"
          >
            Export
          </Button>
        </HStack>
      </Flex>

      {/* Key Metrics Cards */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
        <Card
          bg="white"
          borderRadius="2xl"
          shadow="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{
            shadow: '2xl',
            transform: 'translateY(-4px)'
          }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="flex-start">
              <Stat flex="1">
                <StatLabel
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Total Revenue
                </StatLabel>
                <StatNumber fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  $328K
                </StatNumber>
                <StatHelpText mt={2} mb={0}>
                  <StatArrow type="increase" />
                  18.2%
                </StatHelpText>
              </Stat>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, green.500, green.600)"
                borderRadius="2xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={DollarSign} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          borderRadius="2xl"
          shadow="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{
            shadow: '2xl',
            transform: 'translateY(-4px)'
          }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="flex-start">
              <Stat flex="1">
                <StatLabel
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Conversion Rate
                </StatLabel>
                <StatNumber fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  35.9%
                </StatNumber>
                <StatHelpText mt={2} mb={0}>
                  <StatArrow type="increase" />
                  4.3%
                </StatHelpText>
              </Stat>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, blue.500, blue.600)"
                borderRadius="2xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={Target} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          borderRadius="2xl"
          shadow="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{
            shadow: '2xl',
            transform: 'translateY(-4px)'
          }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="flex-start">
              <Stat flex="1">
                <StatLabel
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Active Customers
                </StatLabel>
                <StatNumber fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  1,248
                </StatNumber>
                <StatHelpText mt={2} mb={0}>
                  <StatArrow type="increase" />
                  12.5%
                </StatHelpText>
              </Stat>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, purple.500, purple.600)"
                borderRadius="2xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={Users} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bg="white"
          borderRadius="2xl"
          shadow="xl"
          border="1px"
          borderColor="gray.100"
          _hover={{
            shadow: '2xl',
            transform: 'translateY(-4px)'
          }}
          transition="all 0.3s"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="flex-start">
              <Stat flex="1">
                <StatLabel
                  fontSize="sm"
                  fontWeight="semibold"
                  color="gray.500"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Avg. Deal Size
                </StatLabel>
                <StatNumber fontSize="3xl" fontWeight="bold" color="gray.900" mt={3}>
                  $3,685
                </StatNumber>
                <StatHelpText mt={2} mb={0}>
                  <StatArrow type="decrease" />
                  2.1%
                </StatHelpText>
              </Stat>
              <Flex
                w={16}
                h={16}
                bgGradient="linear(to-br, orange.500, orange.600)"
                borderRadius="2xl"
                align="center"
                justify="center"
                shadow="lg"
              >
                <Icon as={TrendingUp} w={7} h={7} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* Revenue Trends Chart */}
      <Card
        bg="white"
        borderRadius="3xl"
        shadow="2xl"
        border="1px"
        borderColor="gray.100"
      >
        <CardBody p={8}>
          <Flex align="center" justify="space-between" mb={8}>
            <Box>
              <Heading size="md" color="gray.900">Revenue Trends</Heading>
              <Text fontSize="sm" color="gray.500" mt={1}>Last 6 months performance</Text>
            </Box>
            <HStack
              spacing={2}
              px={4}
              py={2}
              bg="blue.50"
              color="blue.700"
              borderRadius="xl"
              fontSize="sm"
              fontWeight="semibold"
            >
              <Icon as={Calendar} w={4} h={4} />
              <Text>Jan - Jun 2024</Text>
            </HStack>
          </Flex>
          <Box>
            <ResponsiveContainer width="100%" height={320}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.4}/>
                    <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.05}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                <XAxis 
                  dataKey="month" 
                  stroke="#64748b" 
                  fontSize={13}
                  fontWeight={500}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={13}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#1e293b',
                    border: 'none',
                    borderRadius: '16px',
                    color: 'white',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
                    padding: '12px 16px'
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  fill="url(#colorRevenue)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </Box>
        </CardBody>
      </Card>

      <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
        {/* Conversion Funnel */}
        <Card
          bg="white"
          borderRadius="3xl"
          shadow="2xl"
          border="1px"
          borderColor="gray.100"
        >
          <CardBody p={8}>
            <Heading size="md" color="gray.900" mb={8}>Conversion Funnel</Heading>
            <Box>
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie
                    data={conversionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={70}
                    outerRadius={95}
                    paddingAngle={6}
                    dataKey="value"
                  >
                    {conversionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: 'none',
                      borderRadius: '16px',
                      color: 'white',
                      boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
                      padding: '12px 16px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Box>
            <SimpleGrid columns={3} spacing={4} mt={6}>
              {conversionData.map((item) => (
                <VStack
                  key={item.name}
                  p={3}
                  bg="gray.50"
                  borderRadius="2xl"
                  spacing={2}
                >
                  <Box
                    w={4}
                    h={4}
                    borderRadius="full"
                    shadow="md"
                    bg={item.color}
                  />
                  <Text fontSize="lg" fontWeight="bold" color="gray.900">
                    {item.value}
                  </Text>
                  <Text fontSize="xs" color="gray.500" fontWeight="medium">
                    {item.name}
                  </Text>
                </VStack>
              ))}
            </SimpleGrid>
          </CardBody>
        </Card>

        {/* Service Revenue Breakdown */}
        <Card
          bg="white"
          borderRadius="3xl"
          shadow="2xl"
          border="1px"
          borderColor="gray.100"
        >
          <CardBody p={8}>
            <Heading size="md" color="gray.900" mb={8}>Revenue by Service</Heading>
            <Box>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={serviceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                  <XAxis 
                    dataKey="service" 
                    stroke="#64748b" 
                    fontSize={13}
                    fontWeight={500}
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <YAxis 
                    stroke="#64748b" 
                    fontSize={13}
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      border: 'none',
                      borderRadius: '16px',
                      color: 'white',
                      boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
                      padding: '12px 16px'
                    }}
                    cursor={{ fill: 'rgba(139, 92, 246, 0.1)' }}
                  />
                  <Bar 
                    dataKey="revenue" 
                    fill="url(#gradientPurple)" 
                    radius={[12, 12, 0, 0]}
                    maxBarSize={50}
                  />
                  <defs>
                    <linearGradient id="gradientPurple" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b5cf6" stopOpacity={1}/>
                      <stop offset="100%" stopColor="#6d28d9" stopOpacity={1}/>
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </Box>
          </CardBody>
        </Card>
      </SimpleGrid>
    </VStack>
  );
};
