/**
 * EmployeesPage Component
 * 
 * Professional employee management interface for team administration.
 * Displays employee cards with role, performance, and contact information.
 * 
 * TODO: DB INTEGRATION
 * - Replace static employee data with API call to GET /api/employees
 * - Implement employee creation via POST /api/employees
 * - Add employee update functionality PUT /api/employees/:id
 * - Connect to employee performance metrics API
 * - Integrate role management and permissions system
 */

import React from 'react';
import {
  Box,
  Flex,
  Heading,
  Text,
  SimpleGrid,
  Card,
  CardBody,
  Button,
  Badge,
  Avatar,
  Icon,
  InputGroup,
  InputLeftElement,
  Input,
  VStack,
  HStack,
  IconButton,
  Grid
} from '@chakra-ui/react';
import { 
  User, 
  Mail, 
  Phone, 
  Star,
  Briefcase,
  Plus,
  Search,
  Filter,
  MoreVertical,
  Award
} from 'lucide-react';

export const EmployeesPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API call
  // const { data: employees } = await fetch('/api/employees').then(r => r.json());
  const employees = [
    {
      id: 1,
      name: 'John Smith',
      role: 'Manager',
      email: 'john@eliteplumbing.com',
      phone: '+1 (555) 123-4567',
      avatar: 'JS',
      completedJobs: 45,
      rating: 4.8,
      status: 'active'
    },
    {
      id: 2,
      name: 'Sarah Johnson',
      role: 'Senior Technician',
      email: 'sarah@eliteplumbing.com',
      phone: '+1 (555) 234-5678',
      avatar: 'SJ',
      completedJobs: 68,
      rating: 4.9,
      status: 'active'
    },
    {
      id: 3,
      name: 'Mike Wilson',
      role: 'Technician',
      email: 'mike@eliteplumbing.com',
      phone: '+1 (555) 345-6789',
      avatar: 'MW',
      completedJobs: 52,
      rating: 4.7,
      status: 'active'
    },
    {
      id: 4,
      name: 'Emily Davis',
      role: 'Technician',
      email: 'emily@eliteplumbing.com',
      phone: '+1 (555) 456-7890',
      avatar: 'ED',
      completedJobs: 38,
      rating: 4.6,
      status: 'active'
    },
    {
      id: 5,
      name: 'Tom Brown',
      role: 'Apprentice',
      email: 'tom@eliteplumbing.com',
      phone: '+1 (555) 567-8901',
      avatar: 'TB',
      completedJobs: 15,
      rating: 4.5,
      status: 'active'
    },
    {
      id: 6,
      name: 'Lisa Anderson',
      role: 'Senior Technician',
      email: 'lisa@eliteplumbing.com',
      phone: '+1 (555) 678-9012',
      avatar: 'LA',
      completedJobs: 72,
      rating: 4.9,
      status: 'active'
    },
  ];

  const getRoleBadgeScheme = (role: string) => {
    const schemes = {
      'Manager': 'purple',
      'Senior Technician': 'blue',
      'Technician': 'green',
      'Apprentice': 'orange',
    };
    return schemes[role as keyof typeof schemes] || 'gray';
  };

  const avatarGradients = [
    'linear(to-br, purple.400, pink.500)',
    'linear(to-br, blue.400, indigo.500)',
    'linear(to-br, green.400, teal.500)',
    'linear(to-br, orange.400, red.500)',
    'linear(to-br, cyan.400, blue.500)',
    'linear(to-br, purple.500, violet.600)',
  ];

  return (
    <VStack spacing={6} align="stretch">
      {/* Header with Actions */}
      <Flex justify="space-between" align="center">
        <Box>
          <Heading size="lg" color="gray.900">Team Members</Heading>
          <Text color="gray.600" mt={1}>Manage your workforce and assignments</Text>
        </Box>
        <Button
          leftIcon={<Icon as={Plus} w={5} h={5} />}
          bgGradient="linear(to-r, blue.600, indigo.600)"
          color="white"
          fontWeight="semibold"
          borderRadius="xl"
          px={6}
          py={6}
          shadow="lg"
          _hover={{
            bgGradient: "linear(to-r, blue.700, indigo.700)",
            shadow: "xl",
            transform: "translateY(-2px)"
          }}
          transition="all 0.3s"
        >
          Add Employee
        </Button>
      </Flex>

      {/* Search and Filter */}
      <Flex gap={4}>
        <InputGroup flex="1">
          <InputLeftElement h="full" pl={2}>
            <Icon as={Search} w={5} h={5} color="gray.400" />
          </InputLeftElement>
          <Input
            placeholder="Search employees..."
            pl={12}
            h={12}
            border="2px"
            borderColor="gray.200"
            borderRadius="xl"
            _focus={{
              borderColor: "blue.500",
              outline: "none"
            }}
            transition="all 0.2s"
          />
        </InputGroup>
        <Button
          leftIcon={<Icon as={Filter} w={5} h={5} />}
          bg="white"
          border="2px"
          borderColor="gray.200"
          color="gray.700"
          fontWeight="semibold"
          borderRadius="xl"
          px={4}
          h={12}
          _hover={{
            borderColor: "gray.300",
            shadow: "lg"
          }}
          transition="all 0.2s"
        >
          Filter
        </Button>
      </Flex>

      {/* Team Stats */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
        <Card
          bgGradient="linear(to-br, blue.50, indigo.50)"
          borderRadius="2xl"
          border="2px"
          borderColor="blue.100"
          shadow="none"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="blue.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Total Team
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>
                  {employees.length}
                </Text>
              </Box>
              <Flex
                w={12}
                h={12}
                bg="blue.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={User} w={6} h={6} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bgGradient="linear(to-br, green.50, teal.50)"
          borderRadius="2xl"
          border="2px"
          borderColor="green.100"
          shadow="none"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="green.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Active Now
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>
                  {employees.filter(e => e.status === 'active').length}
                </Text>
              </Box>
              <Flex
                w={12}
                h={12}
                bg="green.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={Briefcase} w={6} h={6} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bgGradient="linear(to-br, purple.50, violet.50)"
          borderRadius="2xl"
          border="2px"
          borderColor="purple.100"
          shadow="none"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="purple.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Avg Rating
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>
                  {(employees.reduce((sum, e) => sum + e.rating, 0) / employees.length).toFixed(1)}
                </Text>
              </Box>
              <Flex
                w={12}
                h={12}
                bg="purple.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={Star} w={6} h={6} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>

        <Card
          bgGradient="linear(to-br, orange.50, red.50)"
          borderRadius="2xl"
          border="2px"
          borderColor="orange.100"
          shadow="none"
        >
          <CardBody p={6}>
            <Flex justify="space-between" align="center">
              <Box>
                <Text
                  fontSize="sm"
                  fontWeight="semibold"
                  color="orange.600"
                  textTransform="uppercase"
                  letterSpacing="wide"
                >
                  Jobs Done
                </Text>
                <Text fontSize="3xl" fontWeight="bold" color="gray.900" mt={2}>
                  {employees.reduce((sum, e) => sum + e.completedJobs, 0)}
                </Text>
              </Box>
              <Flex
                w={12}
                h={12}
                bg="orange.500"
                borderRadius="xl"
                align="center"
                justify="center"
              >
                <Icon as={Award} w={6} h={6} color="white" />
              </Flex>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* Employee Cards Grid */}
      <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
        {employees.map((employee, idx) => (
          <Card
            key={employee.id}
            bg="white"
            borderRadius="2xl"
            shadow="xl"
            border="1px"
            borderColor="gray.100"
            _hover={{
              shadow: "2xl",
              transform: "translateY(-4px)"
            }}
            transition="all 0.3s"
            role="group"
          >
            <CardBody p={6}>
              <Flex justify="space-between" align="flex-start" mb={4}>
                <HStack spacing={4}>
                  <Avatar
                    name={employee.avatar}
                    bgGradient={avatarGradients[idx % avatarGradients.length]}
                    color="white"
                    fontWeight="bold"
                    size="lg"
                    borderRadius="xl"
                    _groupHover={{
                      transform: "scale(1.1)"
                    }}
                    transition="transform 0.3s"
                  />
                  <Box>
                    <Heading size="sm" color="gray.900">{employee.name}</Heading>
                    <Badge
                      colorScheme={getRoleBadgeScheme(employee.role)}
                      borderRadius="full"
                      px={3}
                      py={1}
                      mt={2}
                      fontSize="xs"
                      fontWeight="semibold"
                    >
                      {employee.role}
                    </Badge>
                  </Box>
                </HStack>
                <IconButton
                  aria-label="More options"
                  icon={<Icon as={MoreVertical} w={5} h={5} />}
                  variant="ghost"
                  colorScheme="gray"
                  borderRadius="lg"
                  size="sm"
                />
              </Flex>

              <VStack spacing={2} mb={4} align="stretch">
                <HStack spacing={3}>
                  <Icon as={Mail} w={4} h={4} color="blue.500" />
                  <Text fontSize="sm" color="gray.600">{employee.email}</Text>
                </HStack>
                <HStack spacing={3}>
                  <Icon as={Phone} w={4} h={4} color="green.500" />
                  <Text fontSize="sm" color="gray.600">{employee.phone}</Text>
                </HStack>
              </VStack>

              <Box pt={4} borderTop="1px" borderColor="gray.200">
                <Grid templateColumns="repeat(2, 1fr)" gap={4}>
                  <Box textAlign="center" p={3} bg="blue.50" borderRadius="xl">
                    <Text fontSize="2xl" fontWeight="bold" color="blue.600">
                      {employee.completedJobs}
                    </Text>
                    <Text fontSize="xs" color="gray.600" mt={1}>Jobs Done</Text>
                  </Box>
                  <Box textAlign="center" p={3} bg="yellow.50" borderRadius="xl">
                    <Flex justify="center" align="center">
                      <Text fontSize="2xl" fontWeight="bold" color="yellow.600">
                        <Icon as={Star} w={5} h={5} mr={1} fill="currentColor" display="inline" />
                        {employee.rating}
                      </Text>
                    </Flex>
                    <Text fontSize="xs" color="gray.600" mt={1}>Rating</Text>
                  </Box>
                </Grid>
              </Box>
            </CardBody>
          </Card>
        ))}
      </SimpleGrid>
    </VStack>
  );
};
