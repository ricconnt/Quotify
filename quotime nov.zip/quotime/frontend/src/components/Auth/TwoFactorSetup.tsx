import React, { useState, useEffect } from 'react';
import { QrCode, Shield, CheckCircle2, Copy, Download, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface TwoFactorSetupProps {
  onComplete: () => void;
  onCancel: () => void;
}

export const TwoFactorSetup: React.FC<TwoFactorSetupProps> = ({ onComplete, onCancel }) => {
  const { setup2FA, verify2FA } = useAuth();
  const [qrCode, setQrCode] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [step, setStep] = useState(1); // 1: Setup, 2: Verify, 3: Complete
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [backupCodes, setBackupCodes] = useState<string[]>([]);

  useEffect(() => {
    initializeSetup();
  }, []);

  const initializeSetup = async () => {
    try {
      setLoading(true);
      const response = await setup2FA();
      setQrCode(response.qr_code);
    } catch (error: any) {
      setError('Failed to initialize 2FA setup. Please try again.');
      console.error('2FA setup error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerification = async () => {
    if (!verificationCode.trim()) {
      setError('Please enter the verification code');
      return;
    }

    try {
      setLoading(true);
      setError('');
      const response = await verify2FA(verificationCode);
      
      // Get server-generated backup codes from response
      if (response.backup_codes && Array.isArray(response.backup_codes)) {
        setBackupCodes(response.backup_codes);
      }
      
      setStep(3);
    } catch (error: any) {
      setError('Invalid verification code. Please check your authenticator app and try again.');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const downloadBackupCodes = () => {
    const content = backupCodes.join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'quotime-2fa-backup-codes.txt';
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Two-Factor Authentication</h1>
          <p className="text-gray-600 mt-2">
            {step === 1 && 'Secure your account with 2FA'}
            {step === 2 && 'Verify your authenticator app'}  
            {step === 3 && 'Setup completed successfully!'}
          </p>
        </div>

        {/* Setup Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-6">
              {error}
            </div>
          )}

          {/* Step 1: QR Code Setup */}
          {step === 1 && (
            <div className="text-center">
              <div className="mb-6">
                <h2 className="text-xl font-bold text-gray-900 mb-2">Scan QR Code</h2>
                <p className="text-gray-600 text-sm">
                  Use your authenticator app to scan this QR code
                </p>
              </div>

              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600"></div>
                </div>
              ) : (
                <div className="mb-6">
                  <div className="bg-white p-4 rounded-xl border-2 border-gray-200 inline-block">
                    {qrCode ? (
                      <img src={qrCode} alt="2FA QR Code" className="w-48 h-48" />
                    ) : (
                      <div className="w-48 h-48 bg-gray-100 rounded-lg flex items-center justify-center">
                        <QrCode className="w-16 h-16 text-gray-400" />
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="space-y-4 text-left bg-gray-50 rounded-xl p-4 mb-6">
                <h3 className="font-semibold text-gray-900">Instructions:</h3>
                <ol className="text-sm text-gray-700 space-y-2">
                  <li>1. Install an authenticator app (Google Authenticator, Authy, etc.)</li>
                  <li>2. Open the app and tap "Add account" or "+"</li>
                  <li>3. Scan the QR code above</li>
                  <li>4. Enter the 6-digit code from your app below</li>
                </ol>
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={loading || !qrCode}
                className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 disabled:opacity-50"
              >
                Continue to Verification
              </button>
            </div>
          )}

          {/* Step 2: Verification */}
          {step === 2 && (
            <div>
              <div className="mb-6 text-center">
                <h2 className="text-xl font-bold text-gray-900 mb-2">Verify Setup</h2>
                <p className="text-gray-600 text-sm">
                  Enter the 6-digit code from your authenticator app
                </p>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="123456"
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent text-center text-2xl font-mono tracking-widest"
                  maxLength={6}
                />
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 flex items-center justify-center px-4 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </button>
                <button
                  onClick={handleVerification}
                  disabled={loading || verificationCode.length !== 6}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 disabled:opacity-50"
                >
                  {loading ? 'Verifying...' : 'Verify & Enable'}
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Backup Codes */}
          {step === 3 && (
            <div className="text-center">
              <div className="mb-6">
                <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <h2 className="text-xl font-bold text-gray-900 mb-2">2FA Enabled!</h2>
                <p className="text-gray-600 text-sm">
                  Your account is now protected with two-factor authentication
                </p>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 mb-6">
                <h3 className="font-semibold text-yellow-800 mb-3">Save Your Backup Codes</h3>
                <p className="text-yellow-700 text-sm mb-4">
                  Store these codes safely. Use them to access your account if you lose your authenticator device.
                </p>
                
                <div className="bg-white rounded-lg p-3 text-left">
                  {backupCodes.map((code, index) => (
                    <div key={index} className="flex items-center justify-between py-1 px-2 hover:bg-gray-50 rounded">
                      <code className="font-mono text-sm text-gray-800">{code}</code>
                      <button
                        onClick={() => copyToClipboard(code)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>

                <button
                  onClick={downloadBackupCodes}
                  className="mt-4 flex items-center justify-center w-full px-4 py-2 bg-yellow-100 text-yellow-800 rounded-lg hover:bg-yellow-200 transition-colors text-sm font-medium"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Backup Codes
                </button>
              </div>

              <button
                onClick={onComplete}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold py-3 px-6 rounded-xl hover:from-green-600 hover:to-green-700 transition-all duration-200"
              >
                Complete Setup
              </button>
            </div>
          )}

          {/* Cancel Option */}
          {step < 3 && (
            <div className="mt-6 text-center">
              <button
                onClick={onCancel}
                className="text-gray-500 hover:text-gray-700 text-sm font-medium transition-colors"
              >
                Skip for now
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};