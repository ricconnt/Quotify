import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Box,
  Container,
  VStack,
  Heading,
  Text,
  FormControl,
  FormLabel,
  Input,
  InputGroup,
  InputRightElement,
  Button,
  Alert,
  AlertIcon,
  Card,
  CardBody,
  Icon,
  HStack,
  Spinner,
  Image,
  FormErrorMessage,
} from '@chakra-ui/react';
import { Eye, EyeOff, Shield } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNotification } from '../../hooks/useNotification';

const loginSchema = z.object({
  email: z
    .string()
    .min(1, 'Email is required')
    .email('Please enter a valid email address'),
  password: z
    .string()
    .min(6, 'Password must be at least 6 characters')
    .max(100, 'Password is too long'),
  totp_code: z
    .string()
    .optional()
    .refine((val) => !val || /^\d{6}$/.test(val), {
      message: '2FA code must be 6 digits',
    }),
});

type LoginFormData = z.infer<typeof loginSchema>;

export const LoginPage: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [requires2FA, setRequires2FA] = useState(false);
  const [qrCode, setQrCode] = useState('');

  const { login } = useAuth();
  const { showSuccess, showError, showInfo } = useNotification();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    mode: 'onBlur',
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    setError('');

    try {
      const response = await login(data);
      
      if (response.requires_2fa) {
        setRequires2FA(true);
        if (response.qr_code) {
          setQrCode(response.qr_code);
        }
        setError('');
        showInfo('2FA Required', 'Please enter your two-factor authentication code');
      } else {
        showSuccess('Login Successful!', 'Welcome back to Quotaible');
      }
    } catch (err: any) {
      const errorMessage = err.response?.data?.error || 'Login failed. Please try again.';
      if (err.response?.data?.requires_2fa) {
        setRequires2FA(true);
        setError('Please enter your 2FA code');
        if (err.response?.data?.qr_code) {
          setQrCode(err.response.data.qr_code);
        }
      } else {
        setError(errorMessage);
        showError('Login Failed', errorMessage);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Box minH="100vh" bg="gray.50" display="flex" alignItems="center" justifyContent="center" py={12} px={4}>
      <Container maxW="md">
        <VStack spacing={8}>
          {/* Header */}
          <VStack spacing={4}>
            <Box
              w="60px"
              h="60px"
              bgGradient="linear(to-br, brand.500, brand.600)"
              borderRadius="xl"
              display="flex"
              alignItems="center"
              justifyContent="center"
              boxShadow="lg"
            >
              <Text color="white" fontWeight="bold" fontSize="2xl">Q</Text>
            </Box>
            <Heading size="xl" color="gray.800" textAlign="center">
              Welcome to Quotaible
            </Heading>
            <Text color="gray.600" fontSize="lg" textAlign="center">
              Sign in to your account
            </Text>
          </VStack>

          {/* Login Form Card */}
          <Card width="full" boxShadow="xl">
            <CardBody p={8}>
              {error && (
                <Alert status="error" mb={6} borderRadius="md">
                  <AlertIcon />
                  {error}
                </Alert>
              )}

              <form onSubmit={handleSubmit(onSubmit)}>
                <VStack spacing={6}>
                  <FormControl isRequired isInvalid={!!errors.email}>
                    <FormLabel fontWeight="semibold">Email Address</FormLabel>
                    <Input
                      {...register('email')}
                      id="email"
                      type="email"
                      placeholder="Enter your email"
                      size="lg"
                      bg="gray.50"
                      _focus={{ bg: 'white', borderColor: 'brand.500' }}
                    />
                    <FormErrorMessage>
                      {errors.email?.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isRequired isInvalid={!!errors.password}>
                    <FormLabel fontWeight="semibold">Password</FormLabel>
                    <InputGroup size="lg">
                      <Input
                        {...register('password')}
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        bg="gray.50"
                        _focus={{ bg: 'white', borderColor: 'brand.500' }}
                      />
                      <InputRightElement>
                        <Button
                          variant="ghost"
                          onClick={() => setShowPassword(!showPassword)}
                          size="sm"
                        >
                          <Icon as={showPassword ? EyeOff : Eye} boxSize={5} />
                        </Button>
                      </InputRightElement>
                    </InputGroup>
                    <FormErrorMessage>
                      {errors.password?.message}
                    </FormErrorMessage>
                  </FormControl>

                  {requires2FA && (
                    <FormControl isRequired isInvalid={!!errors.totp_code}>
                      <FormLabel fontWeight="semibold">
                        <HStack>
                          <Icon as={Shield} boxSize={4} />
                          <Text>Two-Factor Authentication Code</Text>
                        </HStack>
                      </FormLabel>
                      <Input
                        {...register('totp_code')}
                        id="totp_code"
                        type="text"
                        placeholder="Enter your 6-digit code"
                        maxLength={6}
                        size="lg"
                      />
                      <FormErrorMessage>
                        {errors.totp_code?.message}
                      </FormErrorMessage>
                      {qrCode && (
                        <Box mt={4} p={4} bg="gray.50" borderRadius="md">
                          <Text fontSize="sm" color="gray.600" mb={2}>
                            Scan this QR code with your authenticator app:
                          </Text>
                          <Image src={qrCode} alt="2FA QR Code" mx="auto" />
                        </Box>
                      )}
                    </FormControl>
                  )}

                  <Button
                    type="submit"
                    colorScheme="brand"
                    size="lg"
                    width="full"
                    isLoading={isLoading || isSubmitting}
                    loadingText="Signing in..."
                    spinner={<Spinner size="sm" />}
                    fontWeight="bold"
                  >
                    Sign In
                  </Button>
                </VStack>
              </form>
            </CardBody>
          </Card>

          {/* Demo Credentials */}
          <Card width="full" bg="blue.50" borderColor="blue.100" variant="outline">
            <CardBody p={6}>
              <VStack align="stretch" spacing={3}>
                <HStack>
                  <Icon as={Shield} boxSize={4} color="brand.500" />
                  <Heading size="sm" color="gray.800">Demo Credentials:</Heading>
                </HStack>
                <VStack align="stretch" spacing={2} fontSize="sm" color="gray.700">
                  <HStack>
                    <Text fontWeight="semibold" color="brand.600" w="80px">Admin:</Text>
                    <Text>admin@quotaible.com / admin123</Text>
                  </HStack>
                  <HStack>
                    <Text fontWeight="semibold" color="brand.600" w="80px">Manager:</Text>
                    <Text>john@eliteplumbing.com / manager123</Text>
                  </HStack>
                  <HStack>
                    <Text fontWeight="semibold" color="brand.600" w="80px">Employee:</Text>
                    <Text>mike@eliteplumbing.com / employee123</Text>
                  </HStack>
                </VStack>
              </VStack>
            </CardBody>
          </Card>
        </VStack>
      </Container>
    </Box>
  );
};
