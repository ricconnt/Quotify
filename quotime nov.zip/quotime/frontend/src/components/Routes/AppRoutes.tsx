import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { ProtectedRoute } from './ProtectedRoute';
import { LoginPage } from '../Auth/LoginPage';
import { TwoFactorSetup } from '../Auth/TwoFactorSetup';
import { AdminDashboard } from '../Admin/AdminDashboard';
import { Layout } from '../Layout/Layout';
import { InquiryForm } from '../Public/InquiryForm';

export const AppRoutes: React.FC = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Router>
      <Routes>
        {/* Public routes */}
        <Route 
          path="/inquiry" 
          element={<InquiryForm />} 
        />
        <Route 
          path="/login" 
          element={
            isAuthenticated ? <Navigate to="/" replace /> : <LoginPage />
          } 
        />
        
        {/* Protected routes - All authenticated users */}
        <Route 
          path="/" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/dashboard" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/inquiries" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/quotes" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/appointments" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/settings" 
          element={
            <ProtectedRoute>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/setup-2fa" 
          element={
            <ProtectedRoute>
              <TwoFactorSetup 
                onComplete={() => window.location.href = '/dashboard'}
                onCancel={() => window.location.href = '/dashboard'}
              />
            </ProtectedRoute>
          } 
        />
        
        {/* Protected routes - Managers and Admins only */}
        <Route 
          path="/analytics" 
          element={
            <ProtectedRoute allowedRoles={['admin', 'manager']}>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/employees" 
          element={
            <ProtectedRoute allowedRoles={['admin', 'manager']}>
              <Layout />
            </ProtectedRoute>
          } 
        />
        
        {/* Protected routes - Admins only */}
        <Route 
          path="/companies" 
          element={
            <ProtectedRoute allowedRoles={['admin']}>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin" 
          element={
            <ProtectedRoute allowedRoles={['admin']}>
              <Layout />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/admin/dashboard" 
          element={
            <ProtectedRoute allowedRoles={['admin']}>
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Catch all - redirect to dashboard */}
        <Route 
          path="*" 
          element={<Navigate to="/" replace />} 
        />
      </Routes>
    </Router>
  );
};
