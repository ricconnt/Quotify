/**
 * SettingsPage Component
 * 
 * Professional settings interface for managing account preferences and configurations.
 * Includes sections for profile, notifications, security, and business settings.
 * 
 * TODO: DB INTEGRATION
 * - Replace static settings with API call to GET /api/settings/user
 * - Implement settings update via PUT /api/settings/user
 * - Connect notification preferences to backend API
 * - Integrate 2FA settings with authentication service
 * - Add company settings management for admin users
 */

import React from 'react';
import {
  Box,
  VStack,
  HStack,
  Card,
  CardBody,
  Heading,
  Text,
  FormControl,
  FormLabel,
  Input,
  Switch,
  Button,
  Icon,
  SimpleGrid,
  Flex,
  Badge
} from '@chakra-ui/react';
import { 
  User, 
  Bell, 
  Shield, 
  Building, 
  Key,
  Save,
  Upload
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  // TODO: DB INTEGRATION - Replace with actual API call
  // const { data: userSettings } = await fetch('/api/settings/user').then(r => r.json());

  return (
    <VStack spacing={6} align="stretch">
      {/* Header */}
      <Box>
        <Heading size="lg" color="gray.900">Settings</Heading>
        <Text color="gray.600" mt={1}>Manage your account preferences and configurations</Text>
      </Box>

      {/* Profile Settings */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={6}>
          <HStack spacing={3} mb={6}>
            <Flex
              w={12}
              h={12}
              bgGradient="linear(to-br, blue.500, indigo.600)"
              borderRadius="xl"
              align="center"
              justify="center"
            >
              <Icon as={User} w={6} h={6} color="white" />
            </Flex>
            <Box>
              <Heading size="md" color="gray.900">Profile Information</Heading>
              <Text fontSize="sm" color="gray.500">Update your personal details</Text>
            </Box>
          </HStack>
          
          <VStack spacing={4} align="stretch">
            <HStack spacing={4}>
              <Flex
                w={20}
                h={20}
                bgGradient="linear(to-br, purple.400, pink.500)"
                borderRadius="full"
                align="center"
                justify="center"
                color="white"
                fontWeight="bold"
                fontSize="2xl"
              >
                JD
              </Flex>
              <Button
                leftIcon={<Upload size={16} />}
                bg="blue.50"
                color="blue.600"
                fontWeight="semibold"
                borderRadius="lg"
                _hover={{
                  bg: 'blue.100'
                }}
              >
                Change Photo
              </Button>
            </HStack>
            
            <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
              <FormControl>
                <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                  Full Name
                </FormLabel>
                <Input
                  type="text"
                  defaultValue="John Doe"
                  px={4}
                  py={3}
                  border="2px"
                  borderColor="gray.200"
                  borderRadius="xl"
                  _focus={{
                    borderColor: 'blue.500',
                    outline: 'none'
                  }}
                />
              </FormControl>
              
              <FormControl>
                <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                  Email Address
                </FormLabel>
                <Input
                  type="email"
                  defaultValue="john@example.com"
                  px={4}
                  py={3}
                  border="2px"
                  borderColor="gray.200"
                  borderRadius="xl"
                  _focus={{
                    borderColor: 'blue.500',
                    outline: 'none'
                  }}
                />
              </FormControl>
              
              <FormControl>
                <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                  Phone Number
                </FormLabel>
                <Input
                  type="tel"
                  defaultValue="+1 (555) 123-4567"
                  px={4}
                  py={3}
                  border="2px"
                  borderColor="gray.200"
                  borderRadius="xl"
                  _focus={{
                    borderColor: 'blue.500',
                    outline: 'none'
                  }}
                />
              </FormControl>
              
              <FormControl>
                <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                  Job Title
                </FormLabel>
                <Input
                  type="text"
                  defaultValue="Manager"
                  px={4}
                  py={3}
                  border="2px"
                  borderColor="gray.200"
                  borderRadius="xl"
                  _focus={{
                    borderColor: 'blue.500',
                    outline: 'none'
                  }}
                />
              </FormControl>
            </SimpleGrid>
          </VStack>
        </CardBody>
      </Card>

      {/* Notification Settings */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={6}>
          <HStack spacing={3} mb={6}>
            <Flex
              w={12}
              h={12}
              bgGradient="linear(to-br, green.500, emerald.600)"
              borderRadius="xl"
              align="center"
              justify="center"
            >
              <Icon as={Bell} w={6} h={6} color="white" />
            </Flex>
            <Box>
              <Heading size="md" color="gray.900">Notifications</Heading>
              <Text fontSize="sm" color="gray.500">Choose what updates you receive</Text>
            </Box>
          </HStack>
          
          <VStack spacing={4} align="stretch">
            {[
              { title: 'Email Notifications', desc: 'Receive email updates for new inquiries' },
              { title: 'SMS Alerts', desc: 'Get text messages for urgent matters' },
              { title: 'Push Notifications', desc: 'Browser notifications for real-time updates' },
              { title: 'Weekly Reports', desc: 'Summary of weekly performance and metrics' },
            ].map((setting, idx) => (
              <Flex
                key={idx}
                justify="space-between"
                align="center"
                p={4}
                bg="gray.50"
                borderRadius="xl"
                _hover={{
                  bg: 'gray.100'
                }}
                transition="background 0.2s"
              >
                <Box>
                  <Text fontWeight="semibold" color="gray.900">{setting.title}</Text>
                  <Text fontSize="sm" color="gray.500">{setting.desc}</Text>
                </Box>
                <Switch
                  size="lg"
                  colorScheme="blue"
                  defaultChecked={idx < 2}
                />
              </Flex>
            ))}
          </VStack>
        </CardBody>
      </Card>

      {/* Security Settings */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={6}>
          <HStack spacing={3} mb={6}>
            <Flex
              w={12}
              h={12}
              bgGradient="linear(to-br, purple.500, violet.600)"
              borderRadius="xl"
              align="center"
              justify="center"
            >
              <Icon as={Shield} w={6} h={6} color="white" />
            </Flex>
            <Box>
              <Heading size="md" color="gray.900">Security</Heading>
              <Text fontSize="sm" color="gray.500">Manage your security preferences</Text>
            </Box>
          </HStack>
          
          <VStack spacing={4} align="stretch">
            <Button
              w="full"
              h="auto"
              p={4}
              border="2px"
              borderColor="gray.200"
              bg="white"
              borderRadius="xl"
              textAlign="left"
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              _hover={{
                borderColor: 'blue.300',
                bg: 'blue.50'
              }}
              transition="all 0.3s"
            >
              <HStack spacing={3}>
                <Flex
                  w={10}
                  h={10}
                  bg="blue.100"
                  borderRadius="lg"
                  align="center"
                  justify="center"
                  _groupHover={{
                    bg: 'blue.200'
                  }}
                >
                  <Icon as={Key} w={5} h={5} color="blue.600" />
                </Flex>
                <Box>
                  <Text fontWeight="semibold" color="gray.900">Change Password</Text>
                  <Text fontSize="sm" color="gray.500">Update your account password</Text>
                </Box>
              </HStack>
              <Text color="gray.400" _groupHover={{ color: 'blue.600' }}>→</Text>
            </Button>
            
            <Button
              w="full"
              h="auto"
              p={4}
              border="2px"
              borderColor="gray.200"
              bg="white"
              borderRadius="xl"
              textAlign="left"
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              _hover={{
                borderColor: 'purple.300',
                bg: 'purple.50'
              }}
              transition="all 0.3s"
            >
              <HStack spacing={3}>
                <Flex
                  w={10}
                  h={10}
                  bg="purple.100"
                  borderRadius="lg"
                  align="center"
                  justify="center"
                  _groupHover={{
                    bg: 'purple.200'
                  }}
                >
                  <Icon as={Shield} w={5} h={5} color="purple.600" />
                </Flex>
                <Box>
                  <Text fontWeight="semibold" color="gray.900">Two-Factor Authentication</Text>
                  <Text fontSize="sm" color="gray.500">Add an extra layer of security</Text>
                </Box>
              </HStack>
              <Badge
                colorScheme="green"
                borderRadius="full"
                px={3}
                py={1}
                fontSize="xs"
                fontWeight="semibold"
              >
                Enabled
              </Badge>
            </Button>
          </VStack>
        </CardBody>
      </Card>

      {/* Company Settings (Admin Only) */}
      <Card bg="white" shadow="xl" borderRadius="2xl" border="1px" borderColor="gray.100">
        <CardBody p={6}>
          <HStack spacing={3} mb={6}>
            <Flex
              w={12}
              h={12}
              bgGradient="linear(to-br, orange.500, red.600)"
              borderRadius="xl"
              align="center"
              justify="center"
            >
              <Icon as={Building} w={6} h={6} color="white" />
            </Flex>
            <Box>
              <Heading size="md" color="gray.900">Company Settings</Heading>
              <Text fontSize="sm" color="gray.500">Manage organization preferences</Text>
            </Box>
          </HStack>
          
          <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
            <FormControl>
              <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                Company Name
              </FormLabel>
              <Input
                type="text"
                defaultValue="Elite Plumbing Services"
                px={4}
                py={3}
                border="2px"
                borderColor="gray.200"
                borderRadius="xl"
                _focus={{
                  borderColor: 'blue.500',
                  outline: 'none'
                }}
              />
            </FormControl>
            
            <FormControl>
              <FormLabel fontSize="sm" fontWeight="semibold" color="gray.700">
                Industry
              </FormLabel>
              <Input
                type="text"
                defaultValue="Plumbing & HVAC"
                px={4}
                py={3}
                border="2px"
                borderColor="gray.200"
                borderRadius="xl"
                _focus={{
                  borderColor: 'blue.500',
                  outline: 'none'
                }}
              />
            </FormControl>
          </SimpleGrid>
        </CardBody>
      </Card>

      {/* Save Button */}
      <Flex justify="flex-end" gap={4}>
        <Button
          px={6}
          py={3}
          border="2px"
          borderColor="gray.200"
          color="gray.700"
          fontWeight="semibold"
          borderRadius="xl"
          bg="white"
          _hover={{
            borderColor: 'gray.300',
            shadow: 'lg'
          }}
          transition="all 0.3s"
        >
          Cancel
        </Button>
        <Button
          px={6}
          py={3}
          bgGradient="linear(to-r, blue.600, indigo.600)"
          color="white"
          fontWeight="semibold"
          borderRadius="xl"
          leftIcon={<Save size={20} />}
          _hover={{
            bgGradient: 'linear(to-r, blue.700, indigo.700)',
            shadow: 'xl',
            transform: 'translateY(-2px)'
          }}
          transition="all 0.3s"
          shadow="lg"
        >
          Save Changes
        </Button>
      </Flex>
    </VStack>
  );
};
