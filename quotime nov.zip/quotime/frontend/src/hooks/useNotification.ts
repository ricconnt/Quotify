import { useToast, type UseToastOptions } from '@chakra-ui/react';

export interface NotificationOptions {
  title: string;
  description?: string;
  status?: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  isClosable?: boolean;
}

export const useNotification = () => {
  const toast = useToast();

  const showNotification = (options: NotificationOptions) => {
    const toastOptions: UseToastOptions = {
      title: options.title,
      description: options.description,
      status: options.status || 'info',
      duration: options.duration || 5000,
      isClosable: options.isClosable ?? true,
      position: 'top-right',
      variant: 'solid',
    };

    toast(toastOptions);
  };

  const showSuccess = (title: string, description?: string) => {
    showNotification({
      title,
      description,
      status: 'success',
    });
  };

  const showError = (title: string, description?: string) => {
    showNotification({
      title,
      description,
      status: 'error',
      duration: 7000,
    });
  };

  const showWarning = (title: string, description?: string) => {
    showNotification({
      title,
      description,
      status: 'warning',
    });
  };

  const showInfo = (title: string, description?: string) => {
    showNotification({
      title,
      description,
      status: 'info',
    });
  };

  return {
    showNotification,
    showSuccess,
    showError,
    showWarning,
    showInfo,
  };
};
