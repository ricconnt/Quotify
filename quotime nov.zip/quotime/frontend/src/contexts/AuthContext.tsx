import React, { createContext, useContext, useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import type { User, Company, LoginCredentials, AuthResponse } from '../types';
import { authAPI } from '../services/api';

export type UserRole = 'admin' | 'manager' | 'employee';
export type Permission = 
  | 'view_dashboard'
  | 'manage_inquiries'
  | 'create_quotes'
  | 'assign_employees'
  | 'view_analytics'
  | 'manage_users'
  | 'manage_settings'
  | 'view_admin_panel'
  | 'manage_companies';

interface RolePermissions {
  [key: string]: Permission[];
}

const ROLE_PERMISSIONS: RolePermissions = {
  admin: [
    'view_dashboard',
    'manage_inquiries',
    'create_quotes',
    'assign_employees',
    'view_analytics',
    'manage_users',
    'manage_settings',
    'view_admin_panel',
    'manage_companies',
  ],
  manager: [
    'view_dashboard',
    'manage_inquiries',
    'create_quotes',
    'assign_employees',
    'view_analytics',
    'manage_settings',
  ],
  employee: [
    'view_dashboard',
    'manage_inquiries',
    'create_quotes',
  ],
};

interface AuthContextType {
  user: User | null;
  company: Company | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (credentials: LoginCredentials) => Promise<AuthResponse>;
  logout: () => void;
  setup2FA: () => Promise<{ qr_code: string }>;
  verify2FA: (totp_code: string) => Promise<{ message: string }>;
  hasPermission: (permission: Permission) => boolean;
  hasAnyPermission: (permissions: Permission[]) => boolean;
  hasAllPermissions: (permissions: Permission[]) => boolean;
  isRole: (role: UserRole) => boolean;
  isAnyRole: (roles: UserRole[]) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('access_token');
    const savedUser = localStorage.getItem('user');
    const savedCompany = localStorage.getItem('company');

    if (token && savedUser && savedCompany) {
      try {
        setUser(JSON.parse(savedUser));
        setCompany(JSON.parse(savedCompany));
      } catch (error) {
        console.error('Failed to parse saved user data:', error);
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        localStorage.removeItem('company');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials: LoginCredentials): Promise<AuthResponse> => {
    try {
      const response = await authAPI.login(credentials);
      
      if (response.access_token && response.user) {
        localStorage.setItem('access_token', response.access_token);
        localStorage.setItem('user', JSON.stringify(response.user));
        
        if (response.company) {
          localStorage.setItem('company', JSON.stringify(response.company));
          setCompany(response.company);
        } else {
          const defaultCompany = {
            id: response.user.company_id,
            name: 'Company',
            email: response.user.email,
            phone: '',
            industry: '',
            subscription_tier: 'basic',
            features_enabled: [],
            is_active: true,
            created_at: new Date().toISOString()
          };
          localStorage.setItem('company', JSON.stringify(defaultCompany));
          setCompany(defaultCompany);
        }
        
        setUser(response.user);
      }
      
      return response;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  };

  const logout = () => {
    authAPI.logout().catch(console.error);
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    localStorage.removeItem('company');
    setUser(null);
    setCompany(null);
  };

  const setup2FA = async (): Promise<{ qr_code: string }> => {
    return await authAPI.setup2FA();
  };

  const verify2FA = async (totp_code: string): Promise<{ message: string }> => {
    return await authAPI.verify2FA(totp_code);
  };

  const hasPermission = (permission: Permission): boolean => {
    if (!user) return false;
    const userRole = user.role as UserRole;
    const permissions = ROLE_PERMISSIONS[userRole] || [];
    return permissions.includes(permission);
  };

  const hasAnyPermission = (permissions: Permission[]): boolean => {
    return permissions.some(permission => hasPermission(permission));
  };

  const hasAllPermissions = (permissions: Permission[]): boolean => {
    return permissions.every(permission => hasPermission(permission));
  };

  const isRole = (role: UserRole): boolean => {
    if (!user) return false;
    return user.role === role;
  };

  const isAnyRole = (roles: UserRole[]): boolean => {
    if (!user) return false;
    return roles.includes(user.role as UserRole);
  };

  const value = {
    user,
    company,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    setup2FA,
    verify2FA,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    isRole,
    isAnyRole,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
