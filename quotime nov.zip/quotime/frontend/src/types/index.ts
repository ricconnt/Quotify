// Core data types for Quotaible application

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'employee';
  company_id: number;
  phone?: string;
  is_active: boolean;
  privileges: string[];
  hourly_rate?: number;
  specializations: string[];
  created_at: string;
  last_login?: string;
}

export interface Company {
  id: number;
  name: string;
  email: string;
  phone: string;
  address?: string;
  website?: string;
  industry: string;
  logo_url?: string;
  primary_color?: string;
  secondary_color?: string;
  features_enabled: string[];
  subscription_tier: string;
  is_active: boolean;
  created_at: string;
}

export interface Inquiry {
  id: number;
  company_id: number;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  job_type: string;
  description: string;
  urgency: 'low' | 'medium' | 'high' | 'emergency';
  preferred_contact_method: 'email' | 'phone' | 'sms';
  preferred_time_slot?: string;
  budget_range?: string;
  location: string;
  source: string;
  status: 'new' | 'in_progress' | 'quoted' | 'scheduled' | 'completed' | 'cancelled';
  assigned_employee_id?: number;
  priority_score: number;
  tags: string[];
  images_urls: string[];
  response_time?: number;
  first_response_at?: string;
  created_at: string;
  updated_at: string;
}

export interface Quote {
  id: number;
  inquiry_id: number;
  created_by_employee_id: number;
  quote_number: string;
  title: string;
  description?: string;
  labor_cost: string;
  materials_cost: string;
  additional_costs: string;
  tax_amount: string;
  total_amount: string;
  estimated_duration?: string;
  valid_until?: string;
  status: 'draft' | 'sent' | 'accepted' | 'declined' | 'expired';
  created_at: string;
  updated_at: string;
  sent_at?: string;
  accepted_at?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
  totp_code?: string;
}

export interface AuthResponse {
  access_token: string;
  user: User;
  company: Company;
  requires_2fa?: boolean;
  qr_code?: string;
}

export interface AnalyticsData {
  total_inquiries: number;
  new_inquiries: number;
  in_progress_inquiries: number;
  completed_inquiries: number;
  conversion_rate: number;
  avg_response_time: number;
  top_performing_employees: Array<{
    name: string;
    completed_inquiries: number;
    avg_response_time: number;
  }>;
  inquiries_by_source: Array<{
    source: string;
    count: number;
  }>;
  weekly_trends: Array<{
    date: string;
    new_inquiries: number;
    completed_inquiries: number;
  }>;
}