/**
 * MOCK AUTHENTICATION SERVICE
 * ============================
 * 
 * This is a TEMPORARY authentication bypass for development/testing purposes.
 * It allows login without database connectivity using hardcoded demo users.
 * 
 * ⚠️ TODO: REAL AUTH INTEGRATION
 * ===============================
 * When ready to connect to real authentication:
 * 
 * 1. REMOVE this entire file (mockAuth.ts)
 * 
 * 2. UPDATE src/services/api.ts:
 *    - Remove the import: import { mockAuthService } from './mockAuth';
 *    - Uncomment the real API calls in authAPI.login()
 *    - Remove the mockAuthService.login() call
 * 
 * 3. UPDATE src/contexts/AuthContext.tsx:
 *    - The login() function should call the real authAPI.login()
 *    - This will make POST requests to /api/auth/login
 * 
 * 4. ENSURE Backend is ready:
 *    - Database has users table populated
 *    - POST /api/auth/login endpoint works
 *    - JWT tokens are properly generated
 * 
 * 5. TEST with real credentials:
 *    - Create actual users in database
 *    - Verify JWT tokens are stored
 *    - Check token refresh mechanism
 */

export interface MockUser {
  id: number;
  email: string;
  name: string;
  role: 'admin' | 'manager' | 'employee';
  company_id: number;
}

// Hardcoded demo users - matches the credentials on login page
const MOCK_USERS: MockUser[] = [
  {
    id: 1,
    email: 'admin@quotaible.com',
    name: 'Admin User',
    role: 'admin',
    company_id: 1,
  },
  {
    id: 2,
    email: 'john@eliteplumbing.com',
    name: 'John Manager',
    role: 'manager',
    company_id: 1,
  },
  {
    id: 3,
    email: 'mike@eliteplumbing.com',
    name: 'Mike Employee',
    role: 'employee',
    company_id: 1,
  },
];

// Hardcoded passwords - ALL demo accounts use these passwords
const MOCK_PASSWORDS: Record<string, string> = {
  'admin@quotaible.com': 'admin123',
  'john@eliteplumbing.com': 'manager123',
  'mike@eliteplumbing.com': 'employee123',
};

class MockAuthService {
  /**
   * Mock login - validates credentials against hardcoded users
   * 
   * TODO: REAL AUTH - Replace with actual API call to POST /api/auth/login
   * The real implementation should:
   * - Send { email, password } to backend
   * - Receive { access_token, user } from backend
   * - Backend verifies password hash in database
   */
  async login(email: string, password: string): Promise<{ access_token: string; user: MockUser }> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300));

    const user = MOCK_USERS.find(u => u.email === email);
    const expectedPassword = MOCK_PASSWORDS[email];

    if (!user || password !== expectedPassword) {
      throw new Error('Invalid credentials');
    }

    // Generate a fake JWT token (just for localStorage, not validated anywhere)
    const fakeToken = `mock_jwt_${user.id}_${Date.now()}`;

    return {
      access_token: fakeToken,
      user,
    };
  }

  /**
   * Mock token refresh
   * 
   * TODO: REAL AUTH - Replace with actual API call to POST /api/auth/refresh
   * The real implementation should:
   * - Send current refresh_token to backend
   * - Receive new access_token
   * - Update stored tokens
   */
  async refreshToken(): Promise<{ access_token: string }> {
    // For mock auth, just generate a new fake token
    const fakeToken = `mock_jwt_refresh_${Date.now()}`;
    return { access_token: fakeToken };
  }

  /**
   * Validate current user from token
   * 
   * TODO: REAL AUTH - Replace with actual API call to GET /api/auth/me
   * The real implementation should:
   * - Send access_token in Authorization header
   * - Backend validates JWT and returns user data
   * - Update local user state
   */
  async getCurrentUser(token: string): Promise<MockUser | null> {
    // Extract user ID from our fake token format: mock_jwt_{id}_{timestamp}
    const match = token.match(/mock_jwt_(\d+)_/);
    if (!match) return null;

    const userId = parseInt(match[1]);
    const user = MOCK_USERS.find(u => u.id === userId);
    
    return user || null;
  }
}

export const mockAuthService = new MockAuthService();
