# Image Upload & Company Details Implementation Guide

## Overview
This guide explains how to implement customer company details management and image upload functionality for the Quotaible platform.

---

## 🏢 CUSTOMER COMPANY DETAILS & BRANDING

### Current State
- Company details are stored in PostgreSQL `companies` table
- Logo URLs are text fields pointing to external storage
- Primary/secondary colors stored as hex values

### Database Schema (Already Implemented)
```sql
CREATE TABLE companies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  address TEXT,
  website VARCHAR(255),
  industry VARCHAR(100),
  logo_url VARCHAR(500),
  primary_color VARCHAR(7),    -- Hex color: #3B82F6
  secondary_color VARCHAR(7),   -- Hex color: #10B981
  features_enabled TEXT[],
  subscription_tier VARCHAR(50),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Backend API Endpoints to Implement

#### GET /api/company/settings
```json
Response:
{
  "id": 1,
  "name": "Elite Plumbing Services",
  "email": "contact@eliteplumbing.com",
  "phone": "+1 (555) 123-4567",
  "address": "123 Main St, San Francisco, CA 94102",
  "website": "https://eliteplumbing.com",
  "industry": "Plumbing",
  "logo_url": "https://storage.quotaible.com/logos/company-1.png",
  "primary_color": "#3B82F6",
  "secondary_color": "#10B981",
  "features_enabled": ["analytics", "ai_chat", "mobile_app"],
  "subscription_tier": "professional"
}
```

#### PUT /api/company/settings
```json
Request Body:
{
  "name": "Elite Plumbing Services",
  "phone": "+1 (555) 123-4567",
  "address": "123 Main St, San Francisco, CA 94102",
  "primary_color": "#3B82F6",
  "secondary_color": "#10B981"
}

Response: Updated company object
```

---

## 📸 IMAGE UPLOAD SYSTEM

### Architecture: Cloud Storage + Database URLs

**Recommended Stack:**
- **Storage**: AWS S3, Google Cloud Storage, or Cloudinary
- **Backend**: Flask with `boto3` (AWS) or `google-cloud-storage`
- **Database**: PostgreSQL stores URLs only, not actual images

### Step 1: Backend File Upload Endpoint

#### POST /api/upload/company-logo
```python
# Flask route example
@app.route('/api/upload/company-logo', methods=['POST'])
@jwt_required()
def upload_company_logo():
    """
    Upload company logo to cloud storage and update database
    """
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    company_id = get_jwt_identity()['company_id']
    
    # Validate file type
    allowed_types = ['image/jpeg', 'image/png', 'image/webp']
    if file.content_type not in allowed_types:
        return jsonify({'error': 'Invalid file type'}), 400
    
    # Validate file size (max 5MB)
    if file.content_length > 5 * 1024 * 1024:
        return jsonify({'error': 'File too large'}), 400
    
    # Upload to S3/Cloud Storage
    filename = f"logos/company-{company_id}-{uuid.uuid4()}.{file.filename.split('.')[-1]}"
    s3_url = upload_to_s3(file, filename)  # Your S3 upload function
    
    # Update database
    company = Company.query.get(company_id)
    company.logo_url = s3_url
    db.session.commit()
    
    return jsonify({
        'logo_url': s3_url,
        'message': 'Logo uploaded successfully'
    }), 200
```

#### POST /api/upload/inquiry-images
```python
@app.route('/api/upload/inquiry-images', methods=['POST'])
def upload_inquiry_images():
    """
    Upload inquiry job site images
    Allows customers to upload photos of their issue
    """
    if 'files' not in request.files:
        return jsonify({'error': 'No files provided'}), 400
    
    files = request.files.getlist('files')
    inquiry_id = request.form.get('inquiry_id')
    
    # Limit to 5 images per inquiry
    if len(files) > 5:
        return jsonify({'error': 'Maximum 5 images allowed'}), 400
    
    uploaded_urls = []
    
    for file in files:
        # Validate and upload each file
        if file.content_type not in ['image/jpeg', 'image/png']:
            continue
        
        filename = f"inquiries/{inquiry_id}/{uuid.uuid4()}.{file.filename.split('.')[-1]}"
        url = upload_to_s3(file, filename)
        uploaded_urls.append(url)
    
    # Update inquiry images_urls array in database
    inquiry = Inquiry.query.get(inquiry_id)
    inquiry.images_urls = inquiry.images_urls + uploaded_urls
    db.session.commit()
    
    return jsonify({
        'images': uploaded_urls,
        'message': f'{len(uploaded_urls)} images uploaded successfully'
    }), 200
```

### Step 2: Frontend Image Upload Component

#### Company Logo Upload (Settings Page)
```typescript
// frontend/src/components/Settings/LogoUpload.tsx
import { useState } from 'react';
import { Button, Input, Image, Box } from '@chakra-ui/react';

export const LogoUpload: React.FC = () => {
  const [uploading, setUploading] = useState(false);
  const [logoUrl, setLogoUrl] = useState('');

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/upload/company-logo', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('access_token')}`
        },
        body: formData
      });

      const data = await response.json();
      setLogoUrl(data.logo_url);
    } catch (error) {
      console.error('Upload failed:', error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <Box>
      <Input type="file" accept="image/*" onChange={handleUpload} />
      {logoUrl && <Image src={logoUrl} alt="Company Logo" maxH="200px" />}
      {uploading && <Spinner />}
    </Box>
  );
};
```

#### Inquiry Images Upload (Public Form)
```typescript
// frontend/src/components/Public/InquiryForm.tsx
const handleImageUpload = async (files: FileList, inquiryId: number) => {
  const formData = new FormData();
  Array.from(files).forEach(file => formData.append('files', file));
  formData.append('inquiry_id', inquiryId.toString());

  const response = await fetch('/api/upload/inquiry-images', {
    method: 'POST',
    body: formData
  });

  return response.json();
};
```

### Step 3: Cloud Storage Configuration

#### AWS S3 Setup (Python Backend)
```python
import boto3
from botocore.exceptions import ClientError

s3_client = boto3.client(
    's3',
    aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],
    aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'],
    region_name=os.environ['AWS_REGION']
)

def upload_to_s3(file, filename):
    """Upload file to S3 and return public URL"""
    bucket_name = os.environ['S3_BUCKET_NAME']
    
    try:
        s3_client.upload_fileobj(
            file,
            bucket_name,
            filename,
            ExtraArgs={
                'ACL': 'public-read',
                'ContentType': file.content_type
            }
        )
        
        url = f"https://{bucket_name}.s3.{os.environ['AWS_REGION']}.amazonaws.com/{filename}"
        return url
    except ClientError as e:
        raise Exception(f"S3 upload failed: {str(e)}")
```

#### Environment Variables Required
```bash
# .env file
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-west-2
S3_BUCKET_NAME=quotaible-uploads
```

### Step 4: Security Best Practices

1. **File Validation**
   - Check file type (MIME type)
   - Limit file size (e.g., 5MB max)
   - Scan for malware (use AWS GuardDuty or ClamAV)

2. **Access Control**
   - Company logos: Public read, authenticated write
   - Inquiry images: Public read (for sharing quotes), write with validation
   - User uploads: JWT authentication required

3. **URL Signing (Private Images)**
```python
# Generate signed URL for temporary access
def get_signed_url(filename, expiration=3600):
    return s3_client.generate_presigned_url(
        'get_object',
        Params={'Bucket': bucket_name, 'Key': filename},
        ExpiresIn=expiration
    )
```

4. **Image Optimization**
   - Resize on upload (use Pillow library)
   - Convert to WebP for better compression
   - Generate thumbnails for galleries

### Step 5: Database Updates

#### Update Inquiry Table for Images
```sql
-- Already implemented in schema
ALTER TABLE inquiries 
ADD COLUMN images_urls TEXT[] DEFAULT '{}';
```

#### Image Metadata Table (Optional)
```sql
CREATE TABLE uploaded_images (
  id SERIAL PRIMARY KEY,
  inquiry_id INTEGER REFERENCES inquiries(id) ON DELETE CASCADE,
  company_id INTEGER REFERENCES companies(id) ON DELETE CASCADE,
  image_type VARCHAR(50), -- 'logo', 'inquiry_photo', 'quote_attachment'
  url VARCHAR(500) NOT NULL,
  filename VARCHAR(255),
  file_size INTEGER, -- bytes
  mime_type VARCHAR(50),
  uploaded_by_user_id INTEGER REFERENCES employees(id),
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🎨 Dynamic Company Branding

### Apply Company Colors to UI

```typescript
// frontend/src/contexts/ThemeContext.tsx
import { useEffect } from 'react';
import { extendTheme } from '@chakra-ui/react';

export const useCompanyTheme = (company: Company) => {
  return extendTheme({
    colors: {
      brand: {
        primary: company.primary_color || '#3B82F6',
        secondary: company.secondary_color || '#10B981',
      },
    },
  });
};

// Apply in App.tsx
<ChakraProvider theme={useCompanyTheme(company)}>
  <App />
</ChakraProvider>
```

---

## 📋 Implementation Checklist

- [ ] Set up AWS S3 bucket or cloud storage
- [ ] Implement backend upload endpoints (company logo, inquiry images)
- [ ] Add file validation (type, size, malware scanning)
- [ ] Create frontend upload components with progress indicators
- [ ] Update database schemas for image URLs
- [ ] Add image optimization (resize, WebP conversion)
- [ ] Implement signed URLs for private images
- [ ] Add company branding customization in settings
- [ ] Test image uploads from public inquiry form
- [ ] Configure CDN for faster image delivery (optional)

---

## 🔗 Integration Points

### InquiryForm Component
- Add file input for customer photos
- Upload images after inquiry creation
- Display image thumbnails in form

### Settings Page
- Company logo upload
- Brand color picker (primary/secondary)
- Preview branding changes in real-time

### Inquiry Detail Modal
- Display uploaded job site photos in gallery
- Allow employees to add photos during job

### Quote Generation
- Attach before/after photos to quotes
- Include job site images in PDF quotes
