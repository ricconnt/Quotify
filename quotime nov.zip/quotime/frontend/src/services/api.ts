import axios from 'axios';
import type { LoginCredentials, AuthResponse, User, Company, Inquiry, AnalyticsData } from '../types';
// TODO: REAL AUTH - Remove this import when switching to real authentication
import { mockAuthService } from './mockAuth';
// TODO: REAL DATA - Remove this import when switching to real backend data
import { mockInquiryService } from './mockInquiries';
// TODO: REAL ANALYTICS - Remove this import when switching to real backend analytics
import { mockAnalyticsService } from './mockAnalytics';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Track ongoing refresh attempts to prevent multiple concurrent refreshes
let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value: any) => void;
  reject: (reason?: any) => void;
}> = [];

const processQueue = (error?: any, token?: string) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (error) {
      reject(error);
    } else {
      resolve(token);
    }
  });
  
  failedQueue = [];
};

// Response interceptor to handle auth errors with token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        // If already refreshing, queue this request
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(token => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return api(originalRequest);
        }).catch(err => {
          return Promise.reject(err);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        // Attempt to refresh the token
        const response = await api.post('/auth/refresh');
        const { access_token } = response.data;
        
        localStorage.setItem('access_token', access_token);
        
        // Update the authorization header for this request
        originalRequest.headers.Authorization = `Bearer ${access_token}`;
        
        // Process the queued requests
        processQueue(undefined, access_token);
        
        isRefreshing = false;
        
        // Retry the original request
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh failed, logout user
        processQueue(refreshError, undefined);
        isRefreshing = false;
        
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        localStorage.removeItem('company');
        window.location.href = '/login';
        
        return Promise.reject(refreshError);
      }
    }
    
    return Promise.reject(error);
  }
);

export const authAPI = {
  /**
   * TODO: REAL AUTH INTEGRATION
   * ===========================
   * Currently using MOCK authentication (no database).
   * 
   * To switch to real authentication:
   * 1. Comment out the mockAuthService.login() call below
   * 2. Uncomment the real API call: api.post('/auth/login', credentials)
   * 3. Ensure backend POST /api/auth/login endpoint is working
   * 4. Remove mockAuth.ts import at top of file
   */
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    // MOCK AUTH - Remove this when ready for real authentication
    const mockResult = await mockAuthService.login(credentials.email, credentials.password);
    return mockResult as AuthResponse;
    
    // REAL AUTH - Uncomment when database is ready
    // const response = await api.post('/auth/login', credentials);
    // return response.data;
  },

  register: async (userData: any): Promise<AuthResponse> => {
    const response = await api.post('/auth/register', userData);
    return response.data;
  },

  setup2FA: async (): Promise<{ qr_code: string }> => {
    const response = await api.post('/auth/setup-2fa');
    return response.data;
  },

  verify2FA: async (totp_code: string): Promise<{ message: string }> => {
    const response = await api.post('/auth/verify-2fa', { totp_code });
    return response.data;
  },

  refreshToken: async (): Promise<{ access_token: string }> => {
    const response = await api.post('/auth/refresh');
    return response.data;
  },

  logout: async (): Promise<void> => {
    await api.post('/auth/logout');
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
  },
};

export const inquiryAPI = {
  /**
   * TODO: REAL DATA INTEGRATION
   * ============================
   * Currently using MOCK inquiry data (no database).
   * 
   * To switch to real backend data:
   * 1. Comment out the mockInquiryService calls below
   * 2. Uncomment the real API calls
   * 3. Ensure backend endpoints are working
   * 4. Remove mockInquiries.ts import at top of file
   */
  getAll: async (): Promise<Inquiry[]> => {
    // MOCK DATA - Remove this when ready for real backend
    return await mockInquiryService.getAll();
    
    // REAL API - Uncomment when backend is ready
    // const response = await api.get('/inquiries');
    // return response.data;
  },

  getById: async (id: number): Promise<Inquiry> => {
    // MOCK DATA - Remove this when ready for real backend
    return await mockInquiryService.getById(id);
    
    // REAL API - Uncomment when backend is ready
    // const response = await api.get(`/inquiries/${id}`);
    // return response.data;
  },

  create: async (inquiry: Partial<Inquiry>): Promise<Inquiry> => {
    // MOCK DATA - Remove this when ready for real backend
    return await mockInquiryService.create(inquiry);
    
    // REAL API - Uncomment when backend is ready
    // const response = await api.post('/inquiries', inquiry);
    // return response.data;
  },

  update: async (id: number, inquiry: Partial<Inquiry>): Promise<Inquiry> => {
    // REAL API - Uncomment when backend is ready
    const response = await api.put(`/inquiries/${id}`, inquiry);
    return response.data;
  },

  delete: async (id: number): Promise<void> => {
    // REAL API - Uncomment when backend is ready
    await api.delete(`/inquiries/${id}`);
  },

  assign: async (inquiryId: number, employeeId: number): Promise<Inquiry> => {
    // MOCK DATA - Remove this when ready for real backend
    return await mockInquiryService.assignEmployee(inquiryId, employeeId);
    
    // REAL API - Uncomment when backend is ready
    // const response = await api.post(`/inquiries/${inquiryId}/assign`, {
    //   employee_id: employeeId
    // });
    // return response.data;
  },
};

export const analyticsAPI = {
  /**
   * TODO: REAL ANALYTICS INTEGRATION
   * ==================================
   * Currently using MOCK analytics data (no database).
   * 
   * To switch to real backend analytics:
   * 1. Comment out the mockAnalyticsService call below
   * 2. Uncomment the real API call
   * 3. Ensure backend GET /api/analytics/manager endpoint returns AnalyticsData
   * 4. Remove mockAnalytics.ts import at top of file
   * 
   * The backend should calculate analytics from PostgreSQL database:
   * - Aggregate inquiry counts by status
   * - Calculate conversion rates and response times
   * - Group employee performance metrics
   * - Generate weekly trend data
   */
  getManagerAnalytics: async (): Promise<AnalyticsData> => {
    // MOCK ANALYTICS - Remove this when ready for real backend
    return await mockAnalyticsService.getManagerAnalytics();
    
    // REAL API - Uncomment when backend is ready
    // const response = await api.get('/analytics/manager');
    // return response.data;
  },
};

export const adminAPI = {
  getAllCompanies: async (): Promise<Company[]> => {
    const response = await api.get('/admin/companies');
    return response.data;
  },

  updateEmployeePrivileges: async (employeeId: number, privileges: string[]): Promise<User> => {
    const response = await api.put(`/admin/employees/${employeeId}/privileges`, {
      privileges
    });
    return response.data;
  },

  toggleCompanyFeatures: async (companyId: number, features: string[]): Promise<Company> => {
    const response = await api.put(`/admin/companies/${companyId}/features`, {
      features_enabled: features
    });
    return response.data;
  },
};

export const aiAPI = {
  chat: async (inquiryId: number, message: string): Promise<{ response: string }> => {
    const response = await api.post('/ai/chat', {
      inquiry_id: inquiryId,
      message
    });
    return response.data;
  },
};

export default api;