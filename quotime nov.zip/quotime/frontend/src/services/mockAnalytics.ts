/**
 * MOCK ANALYTICS DATA
 * ===================
 * 
 * Temporary hardcoded analytics data for development/testing.
 * Provides realistic business metrics to populate the dashboard and analytics page.
 * 
 * TODO: DB INTEGRATION - PostgreSQL Database Setup
 * =================================================
 * 
 * RECOMMENDED DATABASE: PostgreSQL (matches current Flask/SQLAlchemy backend)
 * 
 * When ready to use real backend analytics:
 * 
 * 1. DATABASE SCHEMA REQUIREMENTS:
 *    - Ensure 'inquiries' table has proper indexes on:
 *      - status (for filtering by inquiry status)
 *      - created_at (for time-based queries)
 *      - assigned_employee_id (for employee performance tracking)
 *      - company_id (for multi-tenant data isolation)
 *    
 * 2. ANALYTICS CALCULATION:
 *    Backend should calculate these metrics:
 *    - Total/New/In-Progress/Completed inquiry counts
 *    - Conversion rate: (completed_inquiries / total_inquiries) * 100
 *    - Average response time: AVG(response_time) WHERE response_time IS NOT NULL
 *    - Employee performance: GROUP BY assigned_employee_id with aggregate stats
 *    - Source breakdown: GROUP BY source with counts
 *    - Weekly trends: GROUP BY DATE(created_at) for time series data
 * 
 * 3. API ENDPOINT IMPLEMENTATION:
 *    Create backend route: GET /api/analytics/manager
 *    Query parameters for filtering:
 *    - start_date: ISO date string (default: 30 days ago)
 *    - end_date: ISO date string (default: today)
 *    - company_id: Automatically filtered by authenticated user's company
 * 
 * 4. FRONTEND INTEGRATION:
 *    - Remove this file (mockAnalytics.ts)
 *    - Update src/services/api.ts analyticsAPI to use real endpoint
 *    - Uncomment the real API calls
 * 
 * 5. PERFORMANCE OPTIMIZATION:
 *    - Consider caching analytics data (Redis) for 5-15 minutes
 *    - Use database materialized views for complex aggregations
 *    - Implement pagination for large datasets
 * 
 * EXAMPLE POSTGRESQL QUERY FOR ANALYTICS:
 * ```sql
 * SELECT 
 *   COUNT(*) as total_inquiries,
 *   COUNT(*) FILTER (WHERE status = 'new') as new_inquiries,
 *   COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress_inquiries,
 *   COUNT(*) FILTER (WHERE status = 'completed') as completed_inquiries,
 *   ROUND((COUNT(*) FILTER (WHERE status = 'completed')::numeric / COUNT(*)::numeric) * 100, 2) as conversion_rate,
 *   AVG(response_time) as avg_response_time
 * FROM inquiries
 * WHERE company_id = $1
 *   AND created_at >= $2
 *   AND created_at <= $3;
 * ```
 */

import type { AnalyticsData } from '../types';

export const MOCK_ANALYTICS_DATA: AnalyticsData = {
  total_inquiries: 47,
  new_inquiries: 8,
  in_progress_inquiries: 12,
  completed_inquiries: 23,
  conversion_rate: 48.9,
  avg_response_time: 135, // minutes
  
  top_performing_employees: [
    {
      name: 'Mike Wilson',
      completed_inquiries: 18,
      avg_response_time: 85,
    },
    {
      name: 'Sarah Johnson',
      completed_inquiries: 15,
      avg_response_time: 92,
    },
    {
      name: 'Tom Brown',
      completed_inquiries: 12,
      avg_response_time: 110,
    },
    {
      name: 'Lisa Anderson',
      completed_inquiries: 8,
      avg_response_time: 145,
    },
  ],
  
  inquiries_by_source: [
    { source: 'website', count: 22 },
    { source: 'phone', count: 15 },
    { source: 'social_media', count: 6 },
    { source: 'repeat_customer', count: 4 },
  ],
  
  weekly_trends: [
    { date: '2024-10-07', new_inquiries: 5, completed_inquiries: 3 },
    { date: '2024-10-08', new_inquiries: 7, completed_inquiries: 4 },
    { date: '2024-10-09', new_inquiries: 6, completed_inquiries: 5 },
    { date: '2024-10-10', new_inquiries: 8, completed_inquiries: 3 },
    { date: '2024-10-11', new_inquiries: 4, completed_inquiries: 6 },
    { date: '2024-10-12', new_inquiries: 9, completed_inquiries: 4 },
    { date: '2024-10-13', new_inquiries: 8, completed_inquiries: 5 },
  ],
};

class MockAnalyticsService {
  async getManagerAnalytics(): Promise<AnalyticsData> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return MOCK_ANALYTICS_DATA;
  }
}

export const mockAnalyticsService = new MockAnalyticsService();
