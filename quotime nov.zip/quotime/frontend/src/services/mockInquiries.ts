/**
 * MOCK INQUIRY DATA
 * =================
 * 
 * Temporary hardcoded inquiry data for development/testing.
 * Provides sample inquiries with various statuses to populate the UI.
 * 
 * TODO: REAL DATA INTEGRATION
 * ===========================
 * When ready to use real backend data:
 * 1. Remove this file (mockInquiries.ts)
 * 2. Update src/services/api.ts to use real API endpoints
 * 3. Ensure backend GET /api/inquiries returns proper data
 */

import type { Inquiry } from '../types';

export const MOCK_INQUIRIES: Inquiry[] = [
  {
    id: 1,
    customer_name: 'Robert Chen',
    customer_email: 'robert.chen@email.com',
    customer_phone: '+1 (555) 234-5678',
    location: '456 Oak Avenue, San Francisco, CA',
    job_type: 'Plumbing',
    urgency: 'high',
    description: 'Main water line leak detected in basement. Water damage spreading quickly. Need immediate attention.',
    preferred_contact_method: 'phone',
    preferred_time_slot: '2024-10-15 09:00',
    status: 'new',
    created_at: '2024-10-14T08:30:00Z',
    updated_at: '2024-10-14T08:30:00Z',
    assigned_employee_id: undefined,
    company_id: 1,
    source: 'website',
    priority_score: 95,
    tags: ['urgent', 'water-damage', 'basement'],
    images_urls: [],
  },
  {
    id: 2,
    customer_name: 'Jennifer Martinez',
    customer_email: 'j.martinez@email.com',
    customer_phone: '+1 (555) 345-6789',
    location: '789 Pine Street, Oakland, CA',
    job_type: 'HVAC',
    urgency: 'medium',
    description: 'Air conditioning unit making loud rattling noise. Not cooling properly during hot days.',
    preferred_contact_method: 'email',
    preferred_time_slot: '2024-10-16 14:00',
    status: 'in_progress',
    created_at: '2024-10-13T10:15:00Z',
    updated_at: '2024-10-14T09:00:00Z',
    assigned_employee_id: 2,
    company_id: 1,
    source: 'phone',
    priority_score: 70,
    tags: ['hvac', 'ac-repair'],
    images_urls: [],
    first_response_at: '2024-10-13T11:00:00Z',
    response_time: 45,
  },
  {
    id: 3,
    customer_name: 'Michael Thompson',
    customer_email: 'mthompson@email.com',
    customer_phone: '+1 (555) 456-7890',
    location: '321 Maple Drive, Berkeley, CA',
    job_type: 'Electrical',
    urgency: 'high',
    description: 'Circuit breaker keeps tripping in kitchen. Sparks observed from outlet. Safety concern.',
    preferred_contact_method: 'phone',
    preferred_time_slot: '2024-10-15 11:00',
    budget_range: '$500-$1000',
    status: 'quoted',
    created_at: '2024-10-12T14:20:00Z',
    updated_at: '2024-10-13T16:30:00Z',
    assigned_employee_id: 1,
    company_id: 1,
    source: 'referral',
    priority_score: 90,
    tags: ['electrical', 'safety', 'kitchen'],
    images_urls: ['https://example.com/outlet1.jpg'],
    first_response_at: '2024-10-12T15:00:00Z',
    response_time: 40,
  },
  {
    id: 4,
    customer_name: 'Sarah Williams',
    customer_email: 'sarah.w@email.com',
    customer_phone: '+1 (555) 567-8901',
    location: '654 Birch Lane, San Jose, CA',
    job_type: 'Plumbing',
    urgency: 'low',
    description: 'Kitchen faucet has slow drip. Would like to upgrade to modern fixture with water-saving features.',
    preferred_contact_method: 'email',
    preferred_time_slot: '2024-10-18 10:00',
    budget_range: '$300-$500',
    status: 'scheduled',
    created_at: '2024-10-11T09:45:00Z',
    updated_at: '2024-10-13T11:00:00Z',
    assigned_employee_id: 3,
    company_id: 1,
    source: 'website',
    priority_score: 40,
    tags: ['plumbing', 'faucet', 'upgrade'],
    images_urls: [],
    first_response_at: '2024-10-11T10:30:00Z',
    response_time: 45,
  },
  {
    id: 5,
    customer_name: 'David Park',
    customer_email: 'dpark@email.com',
    customer_phone: '+1 (555) 678-9012',
    location: '987 Cedar Court, Palo Alto, CA',
    job_type: 'HVAC',
    urgency: 'medium',
    description: 'Annual furnace maintenance and inspection before winter season. Also check air quality system.',
    preferred_contact_method: 'email',
    preferred_time_slot: '2024-10-10 13:00',
    budget_range: '$200-$400',
    status: 'completed',
    created_at: '2024-10-08T11:00:00Z',
    updated_at: '2024-10-10T15:30:00Z',
    assigned_employee_id: 6,
    company_id: 1,
    source: 'repeat_customer',
    priority_score: 60,
    tags: ['hvac', 'maintenance', 'annual-service'],
    images_urls: [],
    first_response_at: '2024-10-08T12:00:00Z',
    response_time: 60,
  },
  {
    id: 6,
    customer_name: 'Amanda Foster',
    customer_email: 'afoster@email.com',
    customer_phone: '+1 (555) 789-0123',
    location: '147 Elm Street, Fremont, CA',
    job_type: 'Electrical',
    urgency: 'low',
    description: 'Want to install ceiling fan in living room and add dimmer switches to dining area.',
    preferred_contact_method: 'phone',
    preferred_time_slot: '2024-10-20 09:00',
    budget_range: '$500-$750',
    status: 'quoted',
    created_at: '2024-10-13T13:15:00Z',
    updated_at: '2024-10-14T10:00:00Z',
    assigned_employee_id: 1,
    company_id: 1,
    source: 'social_media',
    priority_score: 45,
    tags: ['electrical', 'installation', 'home-improvement'],
    images_urls: [],
    first_response_at: '2024-10-13T14:00:00Z',
    response_time: 45,
  },
  {
    id: 7,
    customer_name: 'James Rodriguez',
    customer_email: 'jrodriguez@email.com',
    customer_phone: '+1 (555) 890-1234',
    location: '258 Spruce Avenue, Mountain View, CA',
    job_type: 'Plumbing',
    urgency: 'high',
    description: 'Toilet overflowing in main bathroom. Water leaking through ceiling to floor below.',
    preferred_contact_method: 'phone',
    preferred_time_slot: '2024-10-14 15:00',
    status: 'cancelled',
    created_at: '2024-10-14T07:00:00Z',
    updated_at: '2024-10-14T09:30:00Z',
    assigned_employee_id: undefined,
    company_id: 1,
    source: 'phone',
    priority_score: 88,
    tags: ['plumbing', 'emergency', 'water-damage'],
    images_urls: [],
  },
  {
    id: 8,
    customer_name: 'Emily Watson',
    customer_email: 'ewatson@email.com',
    customer_phone: '+1 (555) 901-2345',
    location: '369 Willow Way, Sunnyvale, CA',
    job_type: 'HVAC',
    urgency: 'medium',
    description: 'Central heating not turning on. Thermostat display working but no heat coming through vents.',
    preferred_contact_method: 'email',
    preferred_time_slot: '2024-10-17 11:00',
    budget_range: '$300-$600',
    status: 'in_progress',
    created_at: '2024-10-13T16:30:00Z',
    updated_at: '2024-10-14T08:15:00Z',
    assigned_employee_id: 2,
    company_id: 1,
    source: 'website',
    priority_score: 75,
    tags: ['hvac', 'heating', 'thermostat'],
    images_urls: [],
    first_response_at: '2024-10-13T17:00:00Z',
    response_time: 30,
  },
];

class MockInquiryService {
  private inquiries: Inquiry[] = [...MOCK_INQUIRIES];

  async getAll(): Promise<Inquiry[]> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Return sorted by most recent first
    return [...this.inquiries].sort((a, b) => 
      new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );
  }

  async getById(id: number): Promise<Inquiry> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const inquiry = this.inquiries.find(i => i.id === id);
    if (!inquiry) {
      throw new Error('Inquiry not found');
    }
    return inquiry;
  }

  async create(data: Partial<Inquiry>): Promise<Inquiry> {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    const newInquiry: Inquiry = {
      id: Math.max(...this.inquiries.map(i => i.id)) + 1,
      customer_name: data.customer_name || '',
      customer_email: data.customer_email || '',
      customer_phone: data.customer_phone || '',
      location: data.location || '',
      job_type: data.job_type || 'Plumbing',
      urgency: data.urgency || 'medium',
      description: data.description || '',
      preferred_contact_method: data.preferred_contact_method || 'email',
      preferred_time_slot: data.preferred_time_slot,
      status: 'new',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      assigned_employee_id: undefined,
      company_id: 1,
      source: 'website',
      priority_score: 50,
      tags: [],
      images_urls: [],
    };
    
    this.inquiries.push(newInquiry);
    return newInquiry;
  }

  async updateStatus(id: number, status: Inquiry['status']): Promise<Inquiry> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const inquiry = this.inquiries.find(i => i.id === id);
    if (!inquiry) {
      throw new Error('Inquiry not found');
    }
    
    inquiry.status = status;
    inquiry.updated_at = new Date().toISOString();
    
    return inquiry;
  }

  async assignEmployee(id: number, employeeId: number): Promise<Inquiry> {
    await new Promise(resolve => setTimeout(resolve, 200));
    
    const inquiry = this.inquiries.find(i => i.id === id);
    if (!inquiry) {
      throw new Error('Inquiry not found');
    }
    
    inquiry.assigned_employee_id = employeeId;
    inquiry.updated_at = new Date().toISOString();
    
    return inquiry;
  }
}

export const mockInquiryService = new MockInquiryService();
