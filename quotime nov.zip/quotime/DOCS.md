# Quotaible Documentation

> **B2B SaaS Platform for Service-Based Companies**  
> Comprehensive guide for installation, setup, and usage

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Local Installation](#local-installation)
3. [Running the Website (Admin Dashboard)](#running-the-website-admin-dashboard)
4. [Mobile App Setup](#mobile-app-setup)
5. [Website Plugin Integration](#website-plugin-integration)
6. [Demo Accounts](#demo-accounts)
7. [Architecture Overview](#architecture-overview)
8. [Database Migration Guide](#database-migration-guide)
9. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

**Quotaible** is a comprehensive B2B SaaS platform designed for service-based companies (plumbers, electricians, HVAC technicians, etc.). The platform provides:

- **Admin Web Dashboard** - Manage inquiries, generate quotes, track analytics
- **Mobile App** - On-the-go access for field technicians
- **Website Plugin** - Customer inquiry form for your business website

### Key Features
- Customer inquiry management with status tracking
- Automated quote generation
- Employee assignment and task tracking
- Business analytics and performance metrics
- Multi-tenant support with role-based access control
- Real-time notifications

---

## 💻 Local Installation

### Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js** v18+ ([Download](https://nodejs.org/))
- **Python** 3.8+ ([Download](https://www.python.org/downloads/))
- **PostgreSQL** 14+ ([Download](https://www.postgresql.org/download/)) - Optional for database features
- **Git** ([Download](https://git-scm.com/downloads))

### Step 1: Clone the Repository

```bash
git clone https://github.com/your-org/quotaible.git
cd quotaible
```

### Step 2: Backend Setup (Flask API)

```bash
# Create Python virtual environment
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt

# Set up environment variables
cp .env.example .env
# Edit .env and configure:
# - DATABASE_URL (PostgreSQL connection string)
# - SESSION_SECRET (random secret key)
# - JWT_SECRET_KEY (random JWT secret)

# Initialize database (if using PostgreSQL)
flask db upgrade

# Run backend server
python main.py
```

Backend will run on `http://localhost:8000`

### Step 3: Frontend Setup (React + Vite)

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Run development server
npm run dev
```

Frontend will run on `http://localhost:5000`

### Step 4: Mobile App Setup (Expo)

```bash
# Navigate to mobile app directory
cd QuotaibleMobile

# Install dependencies
npm install

# Start Expo development server
npx expo start
```

Scan QR code with Expo Go app on your phone or press `i`/`a` for iOS/Android simulator.

---

## 🌐 Running the Website (Admin Dashboard)

### Accessing the Dashboard

1. **Start the backend and frontend** (see installation steps above)
2. **Open your browser** and navigate to `http://localhost:5000`
3. **Login** with demo credentials (see [Demo Accounts](#demo-accounts))

### Dashboard Features

#### 1. Dashboard Home
- **Business Metrics**: View total inquiries, conversion rate, response time, and completed jobs
- **Employee Performance**: Track top-performing team members with completion stats
- **Recent Inquiries**: Quick access to the 5 most recent customer requests
- **Quick Actions**: Create new inquiry, view all inquiries, manage team

#### 2. Inquiries Management
- **Search & Filter**: Find inquiries by customer name, email, or job type
- **Status Tracking**: Monitor inquiry lifecycle (New → In Progress → Quoted → Scheduled → Completed)
- **Urgency Levels**: High priority items highlighted in red
- **Employee Assignment**: Assign inquiries to specific team members
- **Detail View**: Complete customer information, job description, and timeline

#### 3. Quotes
- **Quote List**: View all generated quotes with status indicators
- **Quick Actions**: Send, accept, or decline quotes
- **Summary Cards**: Total quotes sent, accepted, and total revenue

#### 4. Appointments
- **Calendar View**: Visual schedule of upcoming appointments
- **Week Summary**: Statistics for confirmed, completed, and pending appointments
- **Quick Scheduling**: Add new appointments directly from calendar

#### 5. Analytics
- **Revenue Trends**: 6-month area chart showing business growth
- **Conversion Funnel**: Visualize inquiry-to-completion pipeline
- **Service Breakdown**: Revenue by service type (Plumbing, HVAC, Electrical)
- **Export Reports**: Download analytics data as CSV/PDF (coming soon)

#### 6. Team Management
- **Employee Directory**: View all team members with roles and status
- **Performance Stats**: Track individual employee metrics
- **Role Assignment**: Admin/Manager/Employee permissions

#### 7. Settings
- **Company Profile**: Update business name, contact info, and address
- **Branding**: Customize primary/secondary colors and upload logo
- **Notifications**: Configure email and SMS alerts
- **Subscription**: Manage features and plan tier

---

## 📱 Mobile App Setup

### Installation Options

#### Option 1: Expo Go (Recommended for Testing)

1. **Install Expo Go** on your phone:
   - [iOS App Store](https://apps.apple.com/app/expo-go/id982107779)
   - [Google Play Store](https://play.google.com/store/apps/details?id=host.exp.exponent)

2. **Start the mobile app server**:
   ```bash
   cd QuotaibleMobile
   npx expo start --tunnel
   ```

3. **Scan QR Code**:
   - **iOS**: Use Camera app to scan QR code
   - **Android**: Use Expo Go app to scan QR code

4. **Login** with demo credentials

#### Option 2: iOS Simulator (macOS only)

1. **Install Xcode** from Mac App Store
2. **Install Xcode Command Line Tools**:
   ```bash
   xcode-select --install
   ```
3. **Start mobile app** and press `i`:
   ```bash
   cd QuotaibleMobile
   npx expo start
   # Press 'i' to open iOS simulator
   ```

#### Option 3: Android Emulator

1. **Install Android Studio** ([Download](https://developer.android.com/studio))
2. **Set up Android Virtual Device (AVD)**:
   - Open Android Studio → Tools → AVD Manager
   - Create new virtual device (Pixel 5 recommended)
3. **Start emulator** and run:
   ```bash
   cd QuotaibleMobile
   npx expo start
   # Press 'a' to open Android emulator
   ```

### Mobile App Features

- **Dashboard**: View key metrics on-the-go
- **Inquiry List**: Access assigned inquiries
- **Job Details**: Complete customer and job information
- **Status Updates**: Mark inquiries as completed from the field
- **Offline Mode**: Basic functionality works without internet (coming soon)
- **Push Notifications**: Receive alerts for new assignments

---

## 🔌 Website Plugin Integration

The Quotaible website plugin allows customers to submit inquiries directly from your business website.

### Implementation

#### Step 1: Get Your Embed Code

1. Login to Quotaible dashboard as Admin
2. Navigate to **Settings → Integrations → Website Plugin**
3. Copy your unique embed code

#### Step 2: Add to Your Website

**For WordPress:**
```html
<!-- Add to footer.php or use a Custom HTML block -->
<div id="quotaible-inquiry-form"></div>
<script src="https://cdn.quotaible.com/widget.js"></script>
<script>
  QuotaibleWidget.init({
    companyId: 'YOUR_COMPANY_ID',
    containerId: 'quotaible-inquiry-form',
    primaryColor: '#3B82F6',
    services: ['Plumbing', 'HVAC', 'Electrical']
  });
</script>
```

**For React/Next.js:**
```tsx
import { useEffect } from 'react';

export function InquiryWidget() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.quotaible.com/widget.js';
    script.async = true;
    document.body.appendChild(script);

    script.onload = () => {
      window.QuotaibleWidget.init({
        companyId: 'YOUR_COMPANY_ID',
        containerId: 'quotaible-form',
        primaryColor: '#3B82F6'
      });
    };

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return <div id="quotaible-form" />;
}
```

**For Static HTML:**
```html
<!DOCTYPE html>
<html>
<head>
  <title>Contact Us - Elite Plumbing</title>
</head>
<body>
  <h1>Request a Quote</h1>
  
  <!-- Inquiry Form Container -->
  <div id="quotaible-inquiry-form"></div>
  
  <!-- Quotaible Widget Script -->
  <script src="https://cdn.quotaible.com/widget.js"></script>
  <script>
    QuotaibleWidget.init({
      companyId: 'YOUR_COMPANY_ID',
      containerId: 'quotaible-inquiry-form'
    });
  </script>
</body>
</html>
```

### Widget Configuration Options

```javascript
QuotaibleWidget.init({
  companyId: 'YOUR_COMPANY_ID',        // Required: Your unique company ID
  containerId: 'quotaible-form',       // Required: HTML element ID
  primaryColor: '#3B82F6',             // Optional: Brand color
  services: ['Plumbing', 'HVAC'],      // Optional: Service types
  showImages: true,                    // Optional: Allow image uploads
  autoFocus: false,                    // Optional: Auto-focus first field
  redirectUrl: '/thank-you',           // Optional: Redirect after submission
  onSubmit: (data) => {                // Optional: Callback function
    console.log('Form submitted:', data);
  }
});
```

### Direct Route Access

The inquiry form is also available as a standalone page:

**URL**: `https://yourdomain.com/inquiry`

This route is **publicly accessible** (no authentication required) and can be shared directly with customers or linked from your marketing materials.

#### Features:
- Responsive design (mobile & desktop)
- Form validation with error messages
- Image upload support (job site photos)
- Auto-save draft functionality
- Success animation on submission
- Automatic email confirmation to customer

---

## 🔐 Demo Accounts

Use these credentials to test different user roles:

### Admin Account
- **Email**: `admin@quotaible.com`
- **Password**: `admin123`
- **Permissions**: Full system access, analytics, team management, settings

### Manager Account
- **Email**: `john@eliteplumbing.com`
- **Password**: `manager123`
- **Permissions**: View analytics, manage inquiries, assign team members

### Employee Account
- **Email**: `mike@eliteplumbing.com`
- **Password**: `employee123`
- **Permissions**: View assigned inquiries, update status, complete jobs

---

## 🏗️ Architecture Overview

### Tech Stack

**Frontend (Web Dashboard)**
- React 18 with TypeScript
- Vite for development and building
- Chakra UI v2 for components
- Recharts for analytics visualizations
- React Router for navigation

**Backend (REST API)**
- Flask (Python)
- PostgreSQL database
- SQLAlchemy ORM
- JWT authentication
- Flask-Migrate for database migrations

**Mobile App**
- React Native with Expo
- TypeScript
- Expo Router for navigation
- AsyncStorage for local data

### Project Structure

```
quotaible/
├── frontend/                 # React web dashboard
│   ├── src/
│   │   ├── components/      # UI components
│   │   ├── contexts/        # React contexts (Auth, Theme)
│   │   ├── services/        # API calls and mock data
│   │   ├── types/           # TypeScript interfaces
│   │   └── App.tsx          # Main app component
│   ├── public/              # Static assets
│   └── package.json
│
├── QuotaibleMobile/         # React Native mobile app
│   ├── src/
│   │   ├── screens/         # App screens
│   │   ├── components/      # Reusable components
│   │   └── navigation/      # Navigation config
│   └── package.json
│
├── backend/                  # Flask API (if separate)
│   ├── app.py               # Flask app initialization
│   ├── models.py            # Database models
│   ├── routes/              # API endpoints
│   └── requirements.txt
│
├── main.py                  # Backend entry point
├── requirements.txt         # Python dependencies
└── README.md
```

---

## 🗄️ Database Migration Guide

### Current State: Mock Data
The application currently uses **mock data** stored in:
- `frontend/src/services/mockAuth.ts` - Authentication
- `frontend/src/services/mockInquiries.ts` - Inquiry data
- `frontend/src/services/mockAnalytics.ts` - Analytics metrics

### Migrating to PostgreSQL

#### Step 1: Database Setup

```bash
# Install PostgreSQL
brew install postgresql@14  # macOS
sudo apt install postgresql-14  # Ubuntu

# Start PostgreSQL service
brew services start postgresql@14

# Create database
createdb quotaible_dev
```

#### Step 2: Configure Environment

```bash
# .env file
DATABASE_URL=postgresql://username:password@localhost/quotaible_dev
JWT_SECRET_KEY=your-secret-key-here
SESSION_SECRET=another-secret-key
```

#### Step 3: Run Migrations

```bash
# Initialize migrations (if not done)
flask db init

# Create migration
flask db migrate -m "Initial schema"

# Apply migration
flask db upgrade
```

#### Step 4: Update Frontend

1. Remove mock service files:
   ```bash
   rm frontend/src/services/mockAuth.ts
   rm frontend/src/services/mockInquiries.ts
   rm frontend/src/services/mockAnalytics.ts
   ```

2. Update `frontend/src/services/api.ts`:
   - Uncomment real API calls
   - Remove mock service imports

3. Test all endpoints:
   ```bash
   npm run test  # Run integration tests
   ```

For detailed PostgreSQL setup instructions, see the TODO comments in:
- `frontend/src/components/Dashboard/Dashboard.tsx`
- `frontend/src/components/Inquiries/InquiriesPage.tsx`
- `frontend/src/components/Analytics/AnalyticsPage.tsx`
- `frontend/src/services/mockAnalytics.ts`

---

## 💼 VS Code Development Setup

### For Developers Working from ZIP Download

If you've downloaded Quotaible as a ZIP file and want to develop using Visual Studio Code:

#### Step 1: Extract and Open Project

```bash
# Extract ZIP file
unzip quotaible-project.zip
cd quotaible

# Open in VS Code
code .
```

#### Step 2: Install Dependencies

**Backend (Python):**
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# macOS/Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# Install Python packages
pip install -r requirements.txt
```

**Frontend (React):**
```bash
# Navigate to frontend directory
cd frontend

# Install Node.js dependencies
npm install

# Return to root
cd ..
```

**Mobile App (Expo):**
```bash
# Navigate to mobile app directory
cd QuotaibleMobile

# Install dependencies
npm install

# Return to root
cd ..
```

#### Step 3: Configure Environment Variables

Create a `.env` file in the project root:

```bash
# Copy example file (if exists)
cp .env.example .env

# Or create new .env file
touch .env
```

Add the following configuration to `.env`:

```env
# Backend Configuration
FLASK_ENV=development
FLASK_DEBUG=1
SESSION_SECRET=your-secret-key-here-change-in-production
JWT_SECRET_KEY=your-jwt-secret-key-here-change-in-production

# Database (Optional - uses SQLite by default)
DATABASE_URL=postgresql://user:password@localhost:5432/quotaible

# Feature Flags (All disabled by default)
ENABLE_2FA=false
ENABLE_AI_QUOTES=false

# CORS Settings
FRONTEND_URL=http://localhost:5000
BACKEND_URL=http://localhost:8000
```

#### Step 4: Run Development Servers

**Option A: Use VS Code Tasks (Recommended)**

1. Press `Ctrl+Shift+P` (or `Cmd+Shift+P` on macOS)
2. Type "Tasks: Run Task"
3. Select one of:
   - `Run All` - Starts backend, frontend, and mobile app
   - `Run Backend` - Python Flask API only
   - `Run Frontend` - React web dashboard only
   - `Run Mobile` - Expo mobile app only

**Create `.vscode/tasks.json`:**

```json
{
  "version": "2.0.0",
  "tasks": [
    {
      "label": "Run Backend",
      "type": "shell",
      "command": "python main.py",
      "problemMatcher": [],
      "presentation": {
        "group": "dev"
      }
    },
    {
      "label": "Run Frontend",
      "type": "shell",
      "command": "cd frontend && npm run dev",
      "problemMatcher": [],
      "presentation": {
        "group": "dev"
      }
    },
    {
      "label": "Run Mobile",
      "type": "shell",
      "command": "cd QuotaibleMobile && npx expo start",
      "problemMatcher": [],
      "presentation": {
        "group": "dev"
      }
    },
    {
      "label": "Run All",
      "dependsOn": ["Run Backend", "Run Frontend"],
      "problemMatcher": []
    }
  ]
}
```

**Option B: Manual Terminal Commands**

Open 3 separate terminals in VS Code:

**Terminal 1 - Backend:**
```bash
# Activate virtual environment first
source venv/bin/activate  # or venv\Scripts\activate on Windows
python main.py
```

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```

**Terminal 3 - Mobile App (Optional):**
```bash
cd QuotaibleMobile
npx expo start
```

#### Step 5: Access the Application

- **Web Dashboard**: http://localhost:5000
- **API Endpoints**: http://localhost:8000/api
- **Mobile App**: Scan QR code in Expo CLI with Expo Go app

#### Step 6: Recommended VS Code Extensions

Install these extensions for better development experience:

```bash
# Python Development
- Python (Microsoft)
- Pylance (Microsoft)
- Python Debugger

# JavaScript/TypeScript
- ESLint
- Prettier - Code formatter
- ES7+ React/Redux/React-Native snippets

# Database
- PostgreSQL (ckolkman)

# General
- GitLens
- Auto Close Tag
- Path Intellisense
- Thunder Client (API testing)
```

Install all at once via command line:
```bash
code --install-extension ms-python.python
code --install-extension ms-python.vscode-pylance
code --install-extension dbaeumer.vscode-eslint
code --install-extension esbenp.prettier-vscode
code --install-extension ckolkman.vscode-postgres
```

#### Step 7: Debugging Setup

**Create `.vscode/launch.json`:**

```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": "Python: Flask",
      "type": "python",
      "request": "launch",
      "module": "flask",
      "env": {
        "FLASK_APP": "main.py",
        "FLASK_ENV": "development"
      },
      "args": ["run", "--port=8000"],
      "jinja": true
    },
    {
      "name": "Frontend: Chrome",
      "type": "chrome",
      "request": "launch",
      "url": "http://localhost:5000",
      "webRoot": "${workspaceFolder}/frontend/src"
    }
  ]
}
```

Press `F5` to start debugging!

#### Step 8: Database Setup (PostgreSQL)

**Install PostgreSQL:**

- **macOS**: `brew install postgresql`
- **Ubuntu/Debian**: `sudo apt-get install postgresql`
- **Windows**: Download from [postgresql.org](https://www.postgresql.org/download/windows/)

**Create Database:**

```bash
# Start PostgreSQL
sudo service postgresql start  # Linux
brew services start postgresql  # macOS

# Create database
createdb quotaible

# Update .env with connection string
DATABASE_URL=postgresql://localhost/quotaible
```

**Run Migrations:**

```bash
# Activate virtual environment
source venv/bin/activate

# Run database migrations
flask db upgrade

# Or create initial tables
python -c "from app import db; db.create_all()"
```

#### Common VS Code Issues

**Issue: Python import errors**
```bash
# Select Python interpreter
Ctrl+Shift+P → "Python: Select Interpreter"
Choose: ./venv/bin/python
```

**Issue: ESLint not working**
```bash
cd frontend
npm install --save-dev eslint
```

**Issue: Terminal not activating venv**
```bash
# Set default shell (Windows)
Ctrl+Shift+P → "Terminal: Select Default Profile"
Choose: Command Prompt or PowerShell

# Then run activation command
venv\Scripts\activate
```

---

## 🔧 Troubleshooting

### Common Issues

#### Issue: Frontend not connecting to backend

**Solution:**
```bash
# Check backend is running on port 8000
curl http://localhost:8000/api/health

# Check CORS settings in backend
# Ensure Flask-CORS is configured:
# CORS(app, resources={r"/api/*": {"origins": "*"}})
```

#### Issue: Mobile app not loading

**Solution:**
```bash
# Clear Expo cache
npx expo start --clear

# Check network connectivity
# Ensure phone and computer are on same WiFi network

# Try tunnel mode
npx expo start --tunnel
```

#### Issue: Database connection error

**Solution:**
```bash
# Verify PostgreSQL is running
pg_isready

# Check DATABASE_URL in .env
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL -c "SELECT 1;"
```

#### Issue: Mock data not displaying

**Solution:**
- Login with correct demo credentials (see [Demo Accounts](#demo-accounts))
- Check browser console for errors (F12)
- Verify `mockInquiries.ts` is imported in `api.ts`
- Clear browser localStorage and refresh

### Getting Help

- **Documentation**: Check this DOCS.md and inline code comments
- **GitHub Issues**: Report bugs at [github.com/your-org/quotaible/issues](https://github.com/your-org/quotaible/issues)
- **Discord Community**: Join our [Discord server](https://discord.gg/quotaible)
- **Email Support**: support@quotaible.com

---

## 🔒 Production Security Checklist

Before deploying Quotaible to production, complete these critical security steps:

### 1. Environment Variables & Secrets Management

**Critical Actions:**
- ✅ Generate strong, unique `SECRET_KEY` and `SESSION_SECRET` values (min 32 random characters)
- ✅ Replace all demo/mock credentials with production credentials
- ✅ Use environment-specific `.env` files (never commit `.env` to version control)
- ✅ Enable secret rotation for database credentials and API keys
- ✅ Remove or disable all demo accounts (`admin@plumbco.com`, `manager@quotaible.com`, etc.)

**Example:**
```bash
# Generate secure random secrets
python -c "import secrets; print(secrets.token_urlsafe(32))"

# Production .env should contain:
SECRET_KEY=<generated-secret-key>
SESSION_SECRET=<generated-session-secret>
DATABASE_URL=postgresql://prod_user:strong_password@prod-db.example.com/quotaible_prod
FLASK_ENV=production
DEBUG=False
```

### 2. Database Security

**Critical Actions:**
- ✅ Create dedicated database user with minimal required privileges (no `SUPERUSER`)
- ✅ Enable SSL/TLS for all database connections (`?sslmode=require`)
- ✅ Implement database backups (automated daily, tested restore procedures)
- ✅ Enable database query logging and monitoring for suspicious activity
- ✅ Never expose PostgreSQL port (5432) to the public internet

**SQL Commands:**
```sql
-- Create production database user with limited privileges
CREATE USER quotaible_prod WITH PASSWORD 'strong_unique_password_here';
GRANT CONNECT ON DATABASE quotaible_prod TO quotaible_prod;
GRANT USAGE ON SCHEMA public TO quotaible_prod;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO quotaible_prod;

-- Revoke dangerous privileges
REVOKE CREATE ON SCHEMA public FROM quotaible_prod;
```

### 3. CORS & API Security

**Critical Actions:**
- ✅ Replace wildcard CORS (`origins="*"`) with specific domain whitelist
- ✅ Enable HTTPS-only (HSTS headers, redirect HTTP to HTTPS)
- ✅ Implement rate limiting on authentication endpoints (max 5 attempts/minute)
- ✅ Enable CSRF protection for state-changing operations
- ✅ Add API authentication tokens with short expiration times (JWT: 15-60 min)

**Flask Backend (`app.py`):**
```python
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Production CORS - whitelist only your domains
CORS(app, resources={
    r"/api/*": {
        "origins": ["https://yourdomain.com", "https://app.yourdomain.com"],
        "supports_credentials": True
    }
})

# Rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@app.route('/api/auth/login', methods=['POST'])
@limiter.limit("5 per minute")  # Prevent brute force attacks
def login():
    # ... login logic
```

### 4. Input Validation & Sanitization

**Critical Actions:**
- ✅ Validate all user inputs (email format, phone numbers, text length limits)
- ✅ Sanitize HTML input to prevent XSS attacks (use `bleach` or similar)
- ✅ Use parameterized SQL queries exclusively (SQLAlchemy ORM protects against SQL injection)
- ✅ Validate file uploads (type, size, content) before processing
- ✅ Implement strict Content Security Policy (CSP) headers

**Example Validation:**
```python
from email_validator import validate_email, EmailNotValidError
from werkzeug.utils import secure_filename

# Validate email
try:
    valid = validate_email(email)
    email = valid.email  # Normalized form
except EmailNotValidError as e:
    return {"error": str(e)}, 400

# Validate file upload
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Use secure_filename() to prevent directory traversal
filename = secure_filename(file.filename)
```

### 5. Monitoring & Audit Logging

**Critical Actions:**
- ✅ Enable application logging (INFO level minimum, ERROR/CRITICAL alerts)
- ✅ Log all authentication attempts (successful and failed)
- ✅ Track sensitive operations (user creation, role changes, data exports)
- ✅ Set up security monitoring alerts (multiple failed logins, unusual API activity)
- ✅ Implement automated vulnerability scanning (Dependabot, Snyk, etc.)

**Logging Configuration:**
```python
import logging
from logging.handlers import RotatingFileHandler

# Production logging setup
handler = RotatingFileHandler('logs/quotaible.log', maxBytes=10000000, backupCount=10)
handler.setLevel(logging.INFO)
formatter = logging.Formatter(
    '[%(asctime)s] %(levelname)s in %(module)s: %(message)s'
)
handler.setFormatter(formatter)
app.logger.addHandler(handler)

# Log security events
@app.route('/api/auth/login', methods=['POST'])
def login():
    app.logger.info(f"Login attempt for user: {email}")
    # ... authentication logic
    if success:
        app.logger.info(f"Successful login: {email}")
    else:
        app.logger.warning(f"Failed login attempt: {email}")
```

### Additional Production Hardening

- 🔐 Enable 2FA (TOTP) for all admin accounts
- 🔐 Use a Web Application Firewall (WAF) like Cloudflare or AWS WAF
- 🔐 Implement IP whitelisting for admin panel access
- 🔐 Regular security audits and penetration testing
- 🔐 Keep all dependencies updated (automated via Dependabot)
- 🔐 Implement session timeout (auto-logout after 30 min inactivity)
- 🔐 Use secure cookie settings (`httpOnly`, `secure`, `sameSite=strict`)

---

## 📚 Additional Resources

- [PostgreSQL Integration Guide](frontend/src/services/mockAnalytics.ts) - Database setup details
- [Image Upload Guide](frontend/src/services/IMAGE_UPLOAD_GUIDE.md) - File upload implementation
- [API Documentation](API.md) - Complete REST API reference
- [Contributing Guide](CONTRIBUTING.md) - How to contribute to the project

---

## 📄 License

Quotaible is proprietary software. All rights reserved.

---

**Last Updated**: October 14, 2025  
**Version**: 1.0.0 (Mock Data Phase)
