// API service for connecting to Flask backend
import { LoginResponse, RegisterData, ApiResponse, User, Company } from '../types';

// Get the backend URL - use Replit domain for mobile access
const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'https://72918c73-7502-4034-8069-a1e1ba633b35-00-2lctpxqkbamzp.riker.replit.dev/api';

class ApiService {
  private baseURL: string;
  private token: string | null = null;

  constructor(baseURL: string) {
    this.baseURL = baseURL;
  }

  setToken(token: string | null) {
    this.token = token;
  }

  private async makeRequest<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    try {
      const url = `${this.baseURL}${endpoint}`;
      const headers = {
        'Content-Type': 'application/json',
        ...options.headers,
      };

      if (this.token) {
        headers['Authorization'] = `Bearer ${this.token}`;
      }

      const response = await fetch(url, {
        ...options,
        headers,
      });

      const data = await response.json();

      return {
        success: response.ok,
        data: response.ok ? data : undefined,
        message: response.ok ? undefined : data.message || 'An error occurred',
      };
    } catch (error) {
      console.error('API Request Error:', error);
      return {
        success: false,
        message: 'Network error. Please check your connection.',
      };
    }
  }

  async login(email: string, password: string): Promise<LoginResponse> {
    const response = await this.makeRequest<LoginResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.success && response.data) {
      return {
        success: true,
        user: response.data.user,
        company: response.data.company,
        token: response.data.token,
      };
    }

    return {
      success: false,
      message: response.message || 'Login failed',
    };
  }

  async register(userData: RegisterData): Promise<LoginResponse> {
    const response = await this.makeRequest<LoginResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });

    if (response.success && response.data) {
      return {
        success: true,
        user: response.data.user,
        company: response.data.company,
        token: response.data.token,
      };
    }

    return {
      success: false,
      message: response.message || 'Registration failed',
    };
  }

  async verifyToken(): Promise<{ user: User; company: Company } | null> {
    if (!this.token) return null;

    const response = await this.makeRequest<{ user: User; company: Company }>('/auth/verify');

    return response.success ? response.data || null : null;
  }

  async logout(): Promise<void> {
    await this.makeRequest('/auth/logout', {
      method: 'POST',
    });
    this.token = null;
  }

  // Inquiries endpoints for field workers
  async getInquiries(): Promise<ApiResponse<any[]>> {
    return this.makeRequest('/inquiries');
  }

  async getInquiry(id: string): Promise<ApiResponse<any>> {
    return this.makeRequest(`/inquiries/${id}`);
  }

  async updateInquiry(id: string, updates: any): Promise<ApiResponse<any>> {
    return this.makeRequest(`/inquiries/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }
}

export default new ApiService(API_BASE_URL);