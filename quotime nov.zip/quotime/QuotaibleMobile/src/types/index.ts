// Type definitions for the mobile app
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'employee';
  company_id: string;
}

export interface Company {
  id: string;
  name: string;
  industry: string;
  plan: string;
}

export interface AuthContextType {
  user: User | null;
  company: Company | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  register: (userData: RegisterData) => Promise<boolean>;
}

export interface RegisterData {
  name: string;
  email: string;
  password: string;
  company_name: string;
  industry: string;
}

export interface LoginResponse {
  success: boolean;
  message?: string;
  user?: User;
  company?: Company;
  token?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
}

// Navigation types
export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Login: undefined;
  Register: undefined;
  Dashboard: undefined;
  Inquiries: undefined;
  Quotes: undefined;
  Profile: undefined;
};