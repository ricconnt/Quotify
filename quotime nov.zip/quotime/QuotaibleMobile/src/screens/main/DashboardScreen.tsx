import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useAuth } from '../../contexts/AuthContext';
import apiService from '../../services/api';

interface QuickStats {
  totalInquiries: number;
  pendingQuotes: number;
  scheduledAppointments: number;
  completedJobs: number;
}

interface RecentInquiry {
  id: string;
  customer_name: string;
  service_type: string;
  status: string;
  created_at: string;
  priority: 'low' | 'medium' | 'high';
}

export const DashboardScreen: React.FC = () => {
  const { user, company, logout } = useAuth();
  const [stats, setStats] = useState<QuickStats | null>(null);
  const [recentInquiries, setRecentInquiries] = useState<RecentInquiry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      
      // Simulate API calls for demo - replace with real API calls
      const mockStats: QuickStats = {
        totalInquiries: 48,
        pendingQuotes: 12,
        scheduledAppointments: 8,
        completedJobs: 156,
      };

      const mockInquiries: RecentInquiry[] = [
        {
          id: '1',
          customer_name: 'Sarah Johnson',
          service_type: 'Leak Repair',
          status: 'new',
          created_at: '2025-01-20T10:30:00Z',
          priority: 'high',
        },
        {
          id: '2',
          customer_name: 'Mike Chen',
          service_type: 'Outlet Installation',
          status: 'quoted',
          created_at: '2025-01-20T09:15:00Z',
          priority: 'medium',
        },
        {
          id: '3',
          customer_name: 'Lisa Williams',
          service_type: 'Drain Cleaning',
          status: 'scheduled',
          created_at: '2025-01-19T16:45:00Z',
          priority: 'low',
        },
      ];

      setStats(mockStats);
      setRecentInquiries(mockInquiries);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      Alert.alert('Error', 'Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout },
      ]
    );
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit',
      hour12: true 
    });
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return '#EF4444';
      case 'medium': return '#F59E0B';
      case 'low': return '#10B981';
      default: return '#64748B';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return '#3B82F6';
      case 'quoted': return '#F59E0B';
      case 'scheduled': return '#10B981';
      case 'completed': return '#64748B';
      default: return '#64748B';
    }
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#3B82F6" />
        <Text style={styles.loadingText}>Loading Dashboard...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View>
            <Text style={styles.greeting}>Good Morning</Text>
            <Text style={styles.userName}>{user?.name}</Text>
            <Text style={styles.companyName}>{company?.name}</Text>
          </View>
          <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
            <Text style={styles.logoutText}>Logout</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Quick Stats */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats?.totalInquiries}</Text>
              <Text style={styles.statLabel}>Total Inquiries</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats?.pendingQuotes}</Text>
              <Text style={styles.statLabel}>Pending Quotes</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats?.scheduledAppointments}</Text>
              <Text style={styles.statLabel}>Appointments</Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats?.completedJobs}</Text>
              <Text style={styles.statLabel}>Completed Jobs</Text>
            </View>
          </View>
        </View>

        {/* Recent Inquiries */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Inquiries</Text>
          {recentInquiries.map((inquiry) => (
            <TouchableOpacity key={inquiry.id} style={styles.inquiryCard}>
              <View style={styles.inquiryHeader}>
                <Text style={styles.customerName}>{inquiry.customer_name}</Text>
                <Text style={styles.inquiryTime}>{formatTime(inquiry.created_at)}</Text>
              </View>
              <Text style={styles.serviceType}>{inquiry.service_type}</Text>
              <View style={styles.inquiryFooter}>
                <View 
                  style={[
                    styles.statusBadge, 
                    { backgroundColor: getStatusColor(inquiry.status) }
                  ]}
                >
                  <Text style={styles.statusText}>{inquiry.status.toUpperCase()}</Text>
                </View>
                <View 
                  style={[
                    styles.priorityDot, 
                    { backgroundColor: getPriorityColor(inquiry.priority) }
                  ]}
                />
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton}>
              <Text style={styles.actionButtonText}>View All Inquiries</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Text style={styles.actionButtonText}>Create Quote</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <Text style={styles.actionButtonText}>Schedule Appointment</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F172A',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0F172A',
  },
  loadingText: {
    color: '#F1F5F9',
    fontSize: 16,
    marginTop: 12,
  },
  header: {
    backgroundColor: '#1E293B',
    paddingTop: 50,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    color: '#94A3B8',
    fontSize: 16,
  },
  userName: {
    color: '#F1F5F9',
    fontSize: 20,
    fontWeight: 'bold',
  },
  companyName: {
    color: '#3B82F6',
    fontSize: 14,
    marginTop: 2,
  },
  logoutButton: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
  },
  logoutText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginTop: 24,
  },
  sectionTitle: {
    color: '#F1F5F9',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    backgroundColor: '#1E293B',
    borderRadius: 12,
    padding: 16,
    flex: 0.48,
    alignItems: 'center',
  },
  statNumber: {
    color: '#3B82F6',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  statLabel: {
    color: '#94A3B8',
    fontSize: 12,
    textAlign: 'center',
  },
  inquiryCard: {
    backgroundColor: '#1E293B',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  inquiryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  customerName: {
    color: '#F1F5F9',
    fontSize: 16,
    fontWeight: '600',
  },
  inquiryTime: {
    color: '#94A3B8',
    fontSize: 12,
  },
  serviceType: {
    color: '#CBD5E1',
    fontSize: 14,
    marginBottom: 12,
  },
  inquiryFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    color: 'white',
    fontSize: 10,
    fontWeight: '600',
  },
  priorityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  actionButtons: {
    gap: 12,
  },
  actionButton: {
    backgroundColor: '#3B82F6',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});