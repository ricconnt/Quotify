import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import * as SecureStore from 'expo-secure-store';
import apiService from '../services/api';
import { AuthContextType, User, Company, RegisterData } from '../types';

const TOKEN_KEY = 'quotime_token';
const USER_KEY = 'quotime_user';
const COMPANY_KEY = 'quotime_company';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuthState();
  }, []);

  const checkAuthState = async () => {
    try {
      setIsLoading(true);
      
      const token = await SecureStore.getItemAsync(TOKEN_KEY);
      if (!token) {
        setIsLoading(false);
        return;
      }

      apiService.setToken(token);
      const authData = await apiService.verifyToken();
      
      if (authData) {
        setUser(authData.user);
        setCompany(authData.company);
      } else {
        // Token is invalid, clear stored data
        await clearAuthData();
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      await clearAuthData();
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      const response = await apiService.login(email, password);
      
      if (response.success && response.user && response.company && response.token) {
        // Store auth data securely
        await SecureStore.setItemAsync(TOKEN_KEY, response.token);
        await SecureStore.setItemAsync(USER_KEY, JSON.stringify(response.user));
        await SecureStore.setItemAsync(COMPANY_KEY, JSON.stringify(response.company));
        
        // Set API token
        apiService.setToken(response.token);
        
        // Update state
        setUser(response.user);
        setCompany(response.company);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      setIsLoading(true);
      
      const response = await apiService.register(userData);
      
      if (response.success && response.user && response.company && response.token) {
        // Store auth data securely
        await SecureStore.setItemAsync(TOKEN_KEY, response.token);
        await SecureStore.setItemAsync(USER_KEY, JSON.stringify(response.user));
        await SecureStore.setItemAsync(COMPANY_KEY, JSON.stringify(response.company));
        
        // Set API token
        apiService.setToken(response.token);
        
        // Update state
        setUser(response.user);
        setCompany(response.company);
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      setIsLoading(true);
      
      // Call logout endpoint
      await apiService.logout();
      
      // Clear local data
      await clearAuthData();
      
    } catch (error) {
      console.error('Logout error:', error);
      // Still clear local data even if API call fails
      await clearAuthData();
    } finally {
      setIsLoading(false);
    }
  };

  const clearAuthData = async () => {
    try {
      await SecureStore.deleteItemAsync(TOKEN_KEY);
      await SecureStore.deleteItemAsync(USER_KEY);
      await SecureStore.deleteItemAsync(COMPANY_KEY);
    } catch (error) {
      console.error('Error clearing auth data:', error);
    }
    
    apiService.setToken(null);
    setUser(null);
    setCompany(null);
  };

  const contextValue: AuthContextType = {
    user,
    company,
    isLoading,
    login,
    logout,
    register,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};