"""
Quotime - B2B SaaS Platform for Service-Based Companies
Main Flask application
"""

import os
import secrets
import hashlib
from datetime import datetime, timedelta
# Add dotenv to load .env files
from dotenv import load_dotenv

# >>> START: Load Environment Variables <<<
# Load environment variables from the .env file in the root directory
load_dotenv()

# >>> END: Load Environment Variables <<<
# --- BEGIN REQUIRED PROXY IMPORTS ---
# --- import requests
from flask import Flask, request, jsonify, send_from_directory, Response, stream_with_context
# --- END REQUIRED PROXY IMPORTS ---
from flask import Flask, request, jsonify, send_from_directory
from flask_migrate import Migrate
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
import pyotp
import qrcode.main
from io import BytesIO
import base64

from config import Config
from models import db, Company, Employee, Inquiry, Quote, Appointment, AIInteraction

# --- FRONTEND CONFIGURATION (CRITICAL FOR PROXYING) ---
# 1. Define the path to the built React files (used for production/build mode)
BUILD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'frontend', 'dist')
# 2. Define the URL of the running Vite development server
VITE_DEV_SERVER_URL = 'http://localhost:5000'

# --------------------------------------------------------


# 2FA Security Helper Functions
def generate_backup_codes():
    """Generate 5 secure backup codes for 2FA recovery"""
    codes = []
    for _ in range(5):
        # Generate 4 groups of 4 characters each (XXXX-XXXX-XXXX-XXXX)
        code = '-'.join([
            ''.join(
                secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789')
                for _ in range(4)) for _ in range(4)
        ])
        codes.append(code)
    return codes


def hash_backup_codes(codes):
    """Hash backup codes for secure storage"""
    hashed_codes = []
    for code in codes:
        # Use SHA-256 with random salt for backup code hashing
        salt = secrets.token_hex(16)
        hashed = hashlib.sha256((code + salt).encode()).hexdigest()
        hashed_codes.append(f"{salt}:{hashed}")
    return hashed_codes


def verify_backup_code(input_code, stored_backup_codes):
    """Verify a backup code against stored hashes and mark as used"""
    if not stored_backup_codes:
        return False, []

    codes_list = stored_backup_codes.split(',')
    for i, hashed_code in enumerate(codes_list):
        if not hashed_code or ':' not in hashed_code:
            continue
        salt, expected_hash = hashed_code.split(':', 1)
        computed_hash = hashlib.sha256(
            (input_code + salt).encode()).hexdigest()
        if computed_hash == expected_hash:
            # Mark this code as used by removing it
            codes_list[i] = ''  # Empty string to mark as used
            return True, codes_list
    return False, codes_list


def create_app():
    """Application factory"""
    app = Flask(__name__)

    # 1. Attempt to load configuration
    try:
        app.config.from_object(Config)
        # Validate production secrets if we were in production mode (for robustness)
        if os.environ.get('FLASK_ENV') == 'production':
            Config.validate_production_config()
        print("--- DEBUG: Flask Config loaded successfully.")
    except Exception as e:
        print(f"--- ERROR: Failed to load configuration: {e}")
        raise  # Re-raise to crash server cleanly if config fails

    # 2. Initialize extensions (Database and Migration)
    try:
        db.init_app(app)
        Migrate(app, db)
        print(
            f"--- DEBUG: Database initialized with URI: {app.config['SQLALCHEMY_DATABASE_URI']}"
        )
    except Exception as e:
        print(f"--- ERROR: Failed to initialize database: {e}")
        # Server must still be able to start, but DB-dependent routes will fail

    # 3. Configure CORS and JWT
    # Allow localhost for web dashboard + Replit domain for mobile app
    CORS(app,
         origins=[
             'http://localhost:3000', 
             'http://127.0.0.1:3000',
             'http://localhost:5000',
             'https://72918c73-7502-4034-8069-a1e1ba633b35-00-2lctpxqkbamzp.riker.replit.dev'
         ],
         supports_credentials=True,
         allow_headers=['Content-Type', 'Authorization'],
         methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
    JWTManager(app)

    return app


# Create app instance
app = create_app()


# Global error handlers to ensure JSON responses for mobile app
@app.errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Not found', 'message': str(error)}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error', 'message': str(error)}), 500

@app.errorhandler(Exception)
def handle_exception(error):
    # Return JSON instead of HTML for HTTP errors
    return jsonify({'error': 'An error occurred', 'message': str(error)}), 500


# Basic health check endpoint
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy',
        'message': 'Quotime API is running',
        'timestamp': datetime.utcnow().isoformat()
    })


# Mock user data for development when database is unavailable
MOCK_USERS = {
    'admin@quotaible.com': {
        'password': 'admin123',
        'user': {
            'id': 1,
            'email': 'admin@quotaible.com',
            'name': 'Admin User',
            'role': 'admin',
            'company_id': 1
        },
        'company': {
            'id': 1,
            'name': 'Elite Plumbing Services',
            'business_type': 'plumbing'
        }
    },
    'john@eliteplumbing.com': {
        'password': 'manager123',
        'user': {
            'id': 2,
            'email': 'john@eliteplumbing.com',
            'name': 'John Manager',
            'role': 'manager',
            'company_id': 1
        },
        'company': {
            'id': 1,
            'name': 'Elite Plumbing Services',
            'business_type': 'plumbing'
        }
    },
    'mike@eliteplumbing.com': {
        'password': 'employee123',
        'user': {
            'id': 3,
            'email': 'mike@eliteplumbing.com',
            'name': 'Mike Employee',
            'role': 'employee',
            'company_id': 1
        },
        'company': {
            'id': 1,
            'name': 'Elite Plumbing Services',
            'business_type': 'plumbing'
        }
    }
}


# Authentication endpoints
@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        totp_code = data.get('totp_code')

        if not email or not password:
            return jsonify({'error': 'Email and password are required'}), 400

        # Try database authentication first
        try:
            employee = Employee.query.filter_by(email=email).first()

            if employee and employee.check_password(password):
                # Check if user has 2FA enabled
                if employee.two_fa_secret:
                    if not totp_code:
                        return jsonify({
                            'error': '2FA code required',
                            'requires_2fa': True
                        }), 401

                    # First try TOTP verification
                    totp = pyotp.TOTP(employee.two_fa_secret)
                    if totp.verify(totp_code):
                        pass  # TOTP verified successfully
                    else:
                        # Try backup code verification as fallback
                        is_backup_valid, updated_codes = verify_backup_code(
                            totp_code, employee.backup_codes)
                        if is_backup_valid:
                            # Update stored backup codes (mark used code as consumed)
                            employee.backup_codes = ','.join(updated_codes)
                            db.session.commit()
                        else:
                            return jsonify({'error': 'Invalid 2FA code'}), 401

                # Create access token (identity must be string)
                access_token = create_access_token(identity=str(employee.id))
                
                # Get company data for mobile app
                company = Company.query.get(employee.company_id) if employee.company_id else None

                return jsonify({
                    'token': access_token,
                    'access_token': access_token,
                    'user': {
                        'id': employee.id,
                        'email': employee.email,
                        'name': employee.name,
                        'role': employee.role,
                        'company_id': employee.company_id
                    },
                    'company': {
                        'id': company.id,
                        'name': company.name,
                        'business_type': company.business_type
                    } if company else None
                })
        
        except Exception as db_error:
            # Database unavailable - fall back to mock authentication
            print(f"⚠️ Database unavailable, using mock authentication: {db_error}")
            
            if email in MOCK_USERS and MOCK_USERS[email]['password'] == password:
                mock_data = MOCK_USERS[email]
                
                # Create access token with mock user ID
                access_token = create_access_token(identity=str(mock_data['user']['id']))
                
                return jsonify({
                    'token': access_token,
                    'access_token': access_token,
                    'user': mock_data['user'],
                    'company': mock_data['company'],
                    '_mock': True  # Flag to indicate this is mock data
                })
        
        # If we get here, credentials are invalid
        return jsonify({'error': 'Invalid credentials'}), 401

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/refresh', methods=['POST'])
@jwt_required()
def refresh_token():
    """Refresh access token"""
    try:
        current_user_id = get_jwt_identity()
        employee = Employee.query.get(int(current_user_id))

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        # Create new access token
        access_token = create_access_token(identity=str(employee.id))

        return jsonify({'access_token': access_token})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/setup-2fa', methods=['POST'])
@jwt_required()
def setup_2fa():
    try:
        current_user_id = int(get_jwt_identity())  # Convert back to int
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        # Generate secret for 2FA
        secret = pyotp.random_base32()
        employee.two_fa_secret = secret
        db.session.commit()

        # Generate QR code
        totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
            name=employee.email, issuer_name="Quotime")

        qr = qrcode.main.QRCode(version=1, box_size=10, border=5)
        qr.add_data(totp_uri)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        buffered = BytesIO()
        img.save(buffered)
        img_str = base64.b64encode(buffered.getvalue()).decode()

        return jsonify({
            'secret': secret,
            'qr_code': f"data:image/png;base64,{img_str}",
            'totp_uri': totp_uri
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/verify-2fa', methods=['POST'])
@jwt_required()
def verify_2fa():
    try:
        current_user_id = int(get_jwt_identity())  # Convert back to int
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        data = request.get_json()
        totp_code = data.get('totp_code')

        if not totp_code:
            return jsonify({'error': 'TOTP code is required'}), 400

        totp = pyotp.TOTP(employee.two_fa_secret)
        if totp.verify(totp_code):
            # Generate and store backup codes upon successful 2FA verification
            backup_codes = generate_backup_codes()
            hashed_backup_codes = hash_backup_codes(backup_codes)

            # Store hashed backup codes (comma-separated) in employee record
            employee.backup_codes = ','.join(hashed_backup_codes)
            db.session.commit()

            return jsonify({
                'message': '2FA verified successfully',
                'backup_codes':
                backup_codes  # Return plain codes for one-time display
            })
        else:
            return jsonify({'error': 'Invalid 2FA code'}), 401

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    try:
        current_user_id = int(get_jwt_identity())  # Convert back to int
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        return jsonify({
            'id': employee.id,
            'email': employee.email,
            'name': employee.name,
            'role': employee.role,
            'company_id': employee.company_id,
            'has_2fa': bool(employee.two_fa_secret)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Inquiry Management Endpoints
@app.route('/api/inquiries', methods=['GET'])
@jwt_required()
def get_inquiries():
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        # Filter inquiries based on user role
        if employee.role == 'admin':
            # Admin can see all inquiries
            inquiries = Inquiry.query.all()
        elif employee.role == 'manager':
            # Manager can see company inquiries
            inquiries = Inquiry.query.filter_by(
                company_id=employee.company_id).all()
        else:
            # Employee can only see assigned inquiries
            inquiries = Inquiry.query.filter_by(
                assigned_employee_id=employee.id).all()

        return jsonify([inquiry.to_dict() for inquiry in inquiries])

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inquiries/<int:inquiry_id>', methods=['GET'])
@jwt_required()
def get_inquiry(inquiry_id):
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        inquiry = Inquiry.query.get(inquiry_id)
        if not inquiry:
            return jsonify({'error': 'Inquiry not found'}), 404

        # Check access permissions
        if employee.role == 'employee' and inquiry.assigned_employee_id != employee.id:
            return jsonify({'error': 'Access denied'}), 403
        elif employee.role == 'manager' and inquiry.company_id != employee.company_id:
            return jsonify({'error': 'Access denied'}), 403

        return jsonify(inquiry.to_dict())

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inquiries/<int:inquiry_id>/assign', methods=['POST'])
@jwt_required()
def assign_inquiry(inquiry_id):
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        if employee.role not in ['admin', 'manager']:
            return jsonify({'error': 'Access denied'}), 403

        data = request.get_json()
        assigned_employee_id = data.get('assigned_employee_id')

        inquiry = Inquiry.query.get(inquiry_id)
        if not inquiry:
            return jsonify({'error': 'Inquiry not found'}), 404

        # Verify assigned employee exists and belongs to same company (unless admin)
        assigned_employee = Employee.query.get(assigned_employee_id)
        if not assigned_employee:
            return jsonify({'error': 'Assigned employee not found'}), 404

        # Check access: manager can only assign inquiries from their company
        if employee.role == 'manager' and inquiry.company_id != employee.company_id:
            return jsonify(
                {'error': 'Cannot assign inquiry from different company'}), 403

        if employee.role == 'manager' and assigned_employee.company_id != employee.company_id:
            return jsonify(
                {'error':
                 'Cannot assign to employee from different company'}), 403

        inquiry.assigned_employee_id = assigned_employee_id
        if inquiry.status == 'new':
            inquiry.status = 'in_progress'

        db.session.commit()

        return jsonify({
            'message': 'Inquiry assigned successfully',
            'inquiry': inquiry.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inquiries', methods=['POST'])
@jwt_required()
def create_inquiry():
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        if employee.role not in ['admin', 'manager']:
            return jsonify({'error':
                            'Access denied - Manager role required'}), 403

        data = request.get_json()

        # For managers, set company_id to their company
        company_id = employee.company_id if employee.role == 'manager' else data.get(
            'company_id')

        if not company_id:
            return jsonify({'error': 'Company ID is required'}), 400

        # Validate required fields
        required_fields = [
            'customer_name', 'customer_email', 'job_type', 'description'
        ]
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400

        inquiry = Inquiry(company_id=company_id,
                          customer_name=data['customer_name'],
                          customer_email=data['customer_email'],
                          customer_phone=data.get('customer_phone'),
                          customer_address=data.get('customer_address'),
                          job_type=data['job_type'],
                          description=data['description'],
                          urgency=data.get('urgency', 'normal'),
                          preferred_date=datetime.strptime(
                              data['preferred_date'], '%Y-%m-%d').date()
                          if data.get('preferred_date') else None,
                          preferred_time=data.get('preferred_time'),
                          source=data.get('source', 'manual'),
                          images_urls=data.get('images_urls', []))

        db.session.add(inquiry)
        db.session.commit()

        return jsonify({
            'message': 'Inquiry created successfully',
            'inquiry': inquiry.to_dict()
        }), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inquiries/<int:inquiry_id>', methods=['PUT'])
@jwt_required()
def update_inquiry(inquiry_id):
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        inquiry = Inquiry.query.get(inquiry_id)
        if not inquiry:
            return jsonify({'error': 'Inquiry not found'}), 404

        # Check access permissions
        if employee.role == 'employee' and inquiry.assigned_employee_id != employee.id:
            return jsonify({'error': 'Access denied'}), 403
        elif employee.role == 'manager' and inquiry.company_id != employee.company_id:
            return jsonify({'error': 'Access denied'}), 403

        data = request.get_json()

        # Update allowed fields
        if 'customer_name' in data:
            inquiry.customer_name = data['customer_name']
        if 'customer_email' in data:
            inquiry.customer_email = data['customer_email']
        if 'customer_phone' in data:
            inquiry.customer_phone = data['customer_phone']
        if 'customer_address' in data:
            inquiry.customer_address = data['customer_address']
        if 'job_type' in data:
            inquiry.job_type = data['job_type']
        if 'description' in data:
            inquiry.description = data['description']
        if 'urgency' in data:
            inquiry.urgency = data['urgency']
        if 'preferred_date' in data:
            inquiry.preferred_date = datetime.strptime(
                data['preferred_date'],
                '%Y-%m-%d').date() if data['preferred_date'] else None
        if 'preferred_time' in data:
            inquiry.preferred_time = data['preferred_time']
        if 'status' in data and employee.role in ['admin', 'manager']:
            inquiry.status = data['status']
        if 'images_urls' in data:
            inquiry.images_urls = data['images_urls']

        db.session.commit()

        return jsonify({
            'message': 'Inquiry updated successfully',
            'inquiry': inquiry.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/inquiries/<int:inquiry_id>', methods=['DELETE'])
@jwt_required()
def delete_inquiry(inquiry_id):
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if not employee:
            return jsonify({'error': 'User not found'}), 404

        inquiry = Inquiry.query.get(inquiry_id)
        if not inquiry:
            return jsonify({'error': 'Inquiry not found'}), 404

        # Only admin and managers can delete inquiries
        if employee.role not in ['admin', 'manager']:
            return jsonify({'error':
                            'Access denied - Manager role required'}), 403

        # Manager can only delete from their company
        if employee.role == 'manager' and inquiry.company_id != employee.company_id:
            return jsonify({'error': 'Access denied'}), 403

        db.session.delete(inquiry)
        db.session.commit()

        return jsonify({'message': 'Inquiry deleted successfully'})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Analytics Endpoint for Managers
@app.route('/api/analytics/manager', methods=['GET'])
@jwt_required()
def manager_analytics():
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        if employee.role not in ['admin', 'manager']:
            return jsonify({'error':
                            'Access denied - Manager role required'}), 403

        # Get company inquiries (admin sees all, manager sees their company)
        if employee.role == 'admin':
            company_inquiries = Inquiry.query
        else:
            company_inquiries = Inquiry.query.filter_by(
                company_id=employee.company_id)

        # Calculate metrics
        total_inquiries = company_inquiries.count()

        # Conversion rate (distinct inquiries that have quotes)
        from sqlalchemy import exists
        inquiries_with_quotes = company_inquiries.filter(
            exists().where(Quote.inquiry_id == Inquiry.id)).count()
        conversion_rate = (inquiries_with_quotes / total_inquiries *
                           100) if total_inquiries > 0 else 0

        # Average response time (in minutes)
        inquiries_with_response = company_inquiries.filter(
            Inquiry.response_time.isnot(None)).all()
        avg_response_time = sum([
            i.response_time for i in inquiries_with_response
        ]) / len(inquiries_with_response) if inquiries_with_response else 0

        # Jobs completed per employee
        if employee.role == 'admin':
            company_employees = Employee.query.filter(Employee.role != 'admin')
        else:
            company_employees = Employee.query.filter_by(
                company_id=employee.company_id).filter(
                    Employee.role != 'admin')

        employee_stats = []
        for emp in company_employees:
            completed_jobs = Inquiry.query.filter_by(
                assigned_employee_id=emp.id, status='completed').count()
            employee_stats.append({
                'employee_name': emp.name,
                'employee_id': emp.id,
                'completed_jobs': completed_jobs
            })

        # Status breakdown
        status_counts = {}
        for status in [
                'new', 'in_progress', 'quoted', 'scheduled', 'completed',
                'cancelled'
        ]:
            count = company_inquiries.filter_by(status=status).count()
            status_counts[status] = count

        analytics = {
            'total_inquiries': total_inquiries,
            'conversion_rate': round(conversion_rate, 2),
            'average_response_time_minutes': round(avg_response_time, 2),
            'jobs_completed_per_employee': employee_stats,
            'status_breakdown': status_counts,
            'generated_at': datetime.utcnow().isoformat()
        }

        return jsonify(analytics)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Admin Dashboard Analytics Endpoint
@app.route('/api/admin/metrics', methods=['GET'])
@jwt_required()
def admin_metrics():
    try:
        current_user_id = int(get_jwt_identity())
        current_user = Employee.query.get(current_user_id)

        if current_user.role != 'admin':
            return jsonify({'error':
                            'Access denied - Admin role required'}), 403

        # Calculate admin-level metrics across all companies
        total_companies = Company.query.count()
        active_companies = Company.query.filter_by(
            is_active=True).count() if hasattr(
                Company, 'is_active') else total_companies

        # Total revenue calculation (placeholder - would need actual revenue tracking)
        total_revenue = 150000  # Placeholder

        # Total inquiries across all companies
        total_inquiries = Inquiry.query.count()

        # Average conversion rate across all companies
        inquiries_with_quotes = Inquiry.query.filter(
            Inquiry.id.in_(db.session.query(
                Quote.inquiry_id).distinct())).count()
        avg_conversion_rate = (inquiries_with_quotes / total_inquiries *
                               100) if total_inquiries > 0 else 0

        # Growth rate calculation (placeholder)
        growth_rate = 8.3

        return jsonify({
            'total_companies': total_companies,
            'active_companies': active_companies,
            'total_revenue': total_revenue,
            'total_inquiries': total_inquiries,
            'avg_conversion_rate': round(avg_conversion_rate, 2),
            'growth_rate': growth_rate
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/admin/companies', methods=['GET'])
@jwt_required()
def admin_companies_overview():
    try:
        current_user_id = int(get_jwt_identity())
        current_user = Employee.query.get(current_user_id)

        if current_user.role != 'admin':
            return jsonify({'error':
                            'Access denied - Admin role required'}), 403

        companies = Company.query.all()
        companies_data = []

        for company in companies:
            # Calculate metrics for each company
            employees_count = Employee.query.filter_by(
                company_id=company.id).count()
            total_inquiries = Inquiry.query.filter_by(
                company_id=company.id).count()

            # Completed jobs count
            completed_jobs = Inquiry.query.filter_by(
                company_id=company.id, status='completed').count()

            # Conversion rate for this company
            company_inquiries_with_quotes = Inquiry.query.filter(
                Inquiry.company_id == company.id,
                Inquiry.id.in_(db.session.query(
                    Quote.inquiry_id).distinct())).count()
            conversion_rate = (company_inquiries_with_quotes /
                               total_inquiries *
                               100) if total_inquiries > 0 else 0

            # Monthly revenue (placeholder - would need actual revenue tracking)
            monthly_revenue = 5000 + (employees_count * 800
                                      )  # Placeholder calculation

            companies_data.append({
                'id':
                company.id,
                'name':
                company.name,
                'industry':
                company.business_type or 'general',
                'subscription_tier':
                company.subscription_plan,
                'employees_count':
                employees_count,
                'total_inquiries':
                total_inquiries,
                'completed_jobs':
                completed_jobs,
                'conversion_rate':
                round(conversion_rate, 1),
                'monthly_revenue':
                monthly_revenue,
                'last_activity':
                company.updated_at.isoformat()
                if company.updated_at else datetime.utcnow().isoformat(),
                'is_active':
                True,  # Placeholder
                'growth_trend':
                round((completed_jobs / max(total_inquiries, 1)) * 15 - 5,
                      1)  # Placeholder calculation
            })

        return jsonify(companies_data)

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Admin Management Endpoints
@app.route('/api/admin/employees/<int:employee_id>/privileges',
           methods=['PUT'])
@jwt_required()
def update_employee_privileges(employee_id):
    try:
        current_user_id = int(get_jwt_identity())
        current_user = Employee.query.get(current_user_id)

        if current_user.role != 'admin':
            return jsonify({'error':
                            'Access denied - Admin role required'}), 403

        data = request.get_json()
        privileges = data.get('privileges', {})

        employee = Employee.query.get(employee_id)
        if not employee:
            return jsonify({'error': 'Employee not found'}), 404

        employee.privileges = privileges
        db.session.commit()

        return jsonify({
            'message': 'Employee privileges updated',
            'employee': employee.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/admin/companies/<int:company_id>/features', methods=['PUT'])
@jwt_required()
def toggle_company_features(company_id):
    try:
        current_user_id = int(get_jwt_identity())
        current_user = Employee.query.get(current_user_id)

        if current_user.role != 'admin':
            return jsonify({'error':
                            'Access denied - Admin role required'}), 403

        data = request.get_json()
        features = data.get('features_enabled', {})

        company = Company.query.get(company_id)
        if not company:
            return jsonify({'error': 'Company not found'}), 404

        company.features_enabled = features
        db.session.commit()

        return jsonify({
            'message': 'Company features updated',
            'company': company.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/admin/companies', methods=['GET'])
@jwt_required()
def get_all_companies():
    try:
        current_user_id = int(get_jwt_identity())
        current_user = Employee.query.get(current_user_id)

        if current_user.role != 'admin':
            return jsonify({'error':
                            'Access denied - Admin role required'}), 403

        companies = Company.query.all()
        return jsonify([company.to_dict() for company in companies])

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# AI Helper Functions for Enhanced Analysis
def estimate_job_cost(job_type, urgency, description):
    """Estimate job cost based on type, urgency, and complexity"""
    base_costs = {
        'plumbing': {
            'base': 150,
            'hourly': 85
        },
        'electrical': {
            'base': 200,
            'hourly': 95
        },
        'hvac': {
            'base': 250,
            'hourly': 105
        },
        'carpentry': {
            'base': 180,
            'hourly': 70
        },
        'painting': {
            'base': 120,
            'hourly': 45
        },
        'general': {
            'base': 130,
            'hourly': 60
        }
    }

    cost_info = base_costs.get(job_type.lower(), base_costs['general'])
    base_cost = cost_info['base']
    hourly_rate = cost_info['hourly']

    # Urgency multiplier
    urgency_multipliers = {
        'emergency': 1.5,
        'high': 1.25,
        'medium': 1.0,
        'low': 0.9
    }
    multiplier = urgency_multipliers.get(urgency, 1.0)

    # Complexity analysis from description
    complexity_keywords = {
        'simple': ['fix', 'repair', 'check', 'inspect'],
        'moderate': ['install', 'replace', 'upgrade', 'maintenance'],
        'complex':
        ['renovation', 'complete', 'overhaul', 'system', 'multiple']
    }

    complexity = 'simple'
    desc_lower = description.lower()
    for level, keywords in complexity_keywords.items():
        if any(keyword in desc_lower for keyword in keywords):
            complexity = level

    # Estimate hours based on complexity
    complexity_hours = {'simple': 2, 'moderate': 4, 'complex': 8}

    estimated_hours = complexity_hours[complexity]
    estimated_cost = (base_cost + (estimated_hours * hourly_rate)) * multiplier

    return {
        'estimated_cost': round(estimated_cost, 2),
        'estimated_hours': estimated_hours,
        'complexity': complexity,
        'urgency_factor': multiplier,
        'cost_breakdown': {
            'base_cost':
            base_cost,
            'labor_cost':
            estimated_hours * hourly_rate,
            'urgency_adjustment':
            round(
                (estimated_cost - (base_cost + estimated_hours * hourly_rate)),
                2)
        }
    }


def generate_materials_list(job_type, description):
    """Generate likely materials needed based on job type and description"""
    materials_db = {
        'plumbing': {
            'common': ['pipe fittings', 'pipe sealant', 'plumber\'s putty'],
            'keywords': {
                'leak':
                ['pipe repair clamp', 'pipe sealant', 'replacement pipes'],
                'toilet': ['wax ring', 'toilet bolts', 'water supply line'],
                'sink': ['faucet cartridge', 'supply lines', 'drain assembly'],
                'water heater':
                ['heating element', 'anode rod', 'temperature relief valve']
            }
        },
        'electrical': {
            'common': ['wire nuts', 'electrical tape', 'outlet covers'],
            'keywords': {
                'outlet': ['GFCI outlet', 'electrical wire', 'wire nuts'],
                'light':
                ['light fixtures', 'electrical switch', 'junction box'],
                'panel': ['circuit breaker', 'electrical wire', 'panel cover'],
                'ceiling fan':
                ['ceiling fan', 'mounting bracket', 'electrical box']
            }
        },
        'hvac': {
            'common': ['air filter', 'duct tape', 'insulation'],
            'keywords': {
                'filter': ['HVAC filter', 'filter housing'],
                'duct': ['ductwork', 'duct sealant', 'insulation'],
                'thermostat': ['programmable thermostat', 'thermostat wire'],
                'unit': ['refrigerant', 'capacitor', 'contactor']
            }
        }
    }

    materials = []
    job_materials = materials_db.get(job_type.lower(), {
        'common': ['general supplies'],
        'keywords': {}
    })

    # Add common materials
    materials.extend(job_materials['common'])

    # Add specific materials based on description keywords
    desc_lower = description.lower()
    for keyword, keyword_materials in job_materials.get('keywords',
                                                        {}).items():
        if keyword in desc_lower:
            materials.extend(keyword_materials)

    return list(set(materials))  # Remove duplicates


def generate_ai_response(inquiry, user_message, employee):
    """Generate intelligent AI response for job analysis and quote generation"""
    # Analyze the inquiry details
    cost_estimate = estimate_job_cost(inquiry.job_type, inquiry.urgency,
                                      inquiry.description)
    materials = generate_materials_list(inquiry.job_type, inquiry.description)

    # Generate contextual response based on user message intent
    message_lower = user_message.lower()

    if any(word in message_lower
           for word in ['quote', 'price', 'cost', 'estimate']):
        # Quote generation response
        ai_response = f"""💡 **AI Quote Analysis for Inquiry #{inquiry.id}**

**Job Overview:**
• Type: {inquiry.job_type.title()} Service
• Urgency: {inquiry.urgency.title()}
• Complexity: {cost_estimate['complexity'].title()}

**Cost Estimate:**
• Total Estimated Cost: ${cost_estimate['estimated_cost']}
• Estimated Time: {cost_estimate['estimated_hours']} hours
• Base Cost: ${cost_estimate['cost_breakdown']['base_cost']}
• Labor Cost: ${cost_estimate['cost_breakdown']['labor_cost']}
• Urgency Adjustment: ${cost_estimate['cost_breakdown']['urgency_adjustment']}

**Likely Materials Needed:**
{chr(10).join([f'• {material}' for material in materials[:5]])}

**Recommendations:**
• Schedule site visit to confirm exact requirements
• {f'High priority due to {inquiry.urgency} urgency' if inquiry.urgency in ['emergency', 'high'] else 'Standard scheduling recommended'}
• Consider upselling maintenance plan for long-term value

*This is an AI-generated estimate. Final quote should be confirmed after site inspection.*"""

    elif any(word in message_lower
             for word in ['analyze', 'analysis', 'assess', 'evaluate']):
        # Job analysis response
        ai_response = f"""🔍 **AI Job Analysis for {inquiry.customer_name}**

**Customer Profile:**
• Location: {inquiry.location}
• Contact Method: {inquiry.preferred_contact_method}
• Urgency Level: {inquiry.urgency.title()}

**Job Analysis:**
• Service Type: {inquiry.job_type.title()}
• Estimated Complexity: {cost_estimate['complexity'].title()}
• Time Investment: {cost_estimate['estimated_hours']} hours
• Priority Score: {inquiry.priority_score}/100

**Business Insights:**
• Revenue Opportunity: ${cost_estimate['estimated_cost']}
• Profit Margin: ~{round((cost_estimate['estimated_cost'] * 0.3), 2)} (estimated 30%)
• Conversion Probability: {'High' if inquiry.urgency in ['emergency', 'high'] else 'Medium'}

**Next Steps:**
1. Contact customer within {2 if inquiry.urgency == 'emergency' else 24} hours
2. Schedule site inspection
3. Prepare detailed quote with materials list
4. Follow up on customer satisfaction

**Assigned To:** {employee.name if inquiry.assigned_employee_id else 'Unassigned'}"""

    elif any(word in message_lower
             for word in ['customer', 'communication', 'contact', 'call']):
        # Customer communication guidance
        contact_urgency = {
            'emergency': 'IMMEDIATE (within 1 hour)',
            'high': 'Priority (within 4 hours)',
            'medium': 'Standard (within 24 hours)',
            'low': 'Regular (within 48 hours)'
        }

        ai_response = f"""📞 **Customer Communication Guide**

**Customer: {inquiry.customer_name}**
• Email: {inquiry.customer_email}
• Phone: {inquiry.customer_phone}
• Preferred Contact: {inquiry.preferred_contact_method.title()}

**Response Timeline:** {contact_urgency.get(inquiry.urgency, 'Standard (within 24 hours)')}

**Recommended Approach:**
{f'• **URGENT**: Call immediately due to {inquiry.urgency} priority' if inquiry.urgency in ['emergency', 'high'] else '• Contact via preferred method first'}
• Acknowledge their {inquiry.job_type} service request
• Schedule convenient site visit time
• Explain next steps and timeline

**Key Talking Points:**
• Professional assessment of their {inquiry.job_type} needs
• Transparent pricing with no hidden costs
• Quality workmanship guarantee
• Flexible scheduling options

**Follow-up Strategy:**
1. Initial contact confirmation
2. Site visit scheduling
3. Quote presentation
4. Service completion follow-up
5. Customer satisfaction survey"""

    else:
        # General AI assistant response
        ai_response = f"""🤖 **AI Assistant - Inquiry #{inquiry.id} Overview**

**Quick Summary:**
• Customer: {inquiry.customer_name}
• Service: {inquiry.job_type.title()}
• Status: {inquiry.status.title()}
• Urgency: {inquiry.urgency.title()}
• Estimated Value: ${cost_estimate['estimated_cost']}

**AI Capabilities Available:**
• **Quote Generation**: Ask "generate quote" for detailed pricing
• **Job Analysis**: Ask "analyze job" for business insights  
• **Customer Communication**: Ask "communication guide" for contact strategy
• **Materials Planning**: Automatic materials list included in quotes

**Current Recommendations:**
• {f'⚡ High priority - contact within {2 if inquiry.urgency == "emergency" else 4} hours' if inquiry.urgency in ['emergency', 'high'] else '📅 Standard follow-up timeline applies'}
• Estimated job duration: {cost_estimate['estimated_hours']} hours
• Revenue opportunity: ${cost_estimate['estimated_cost']}

*Ask me specific questions about quotes, analysis, or customer communication for detailed guidance!*"""

    # Calculate token usage (simplified)
    tokens_used = len(user_message.split()) + len(ai_response.split())

    return ai_response, tokens_used


# AI Integration Endpoint
@app.route('/api/ai_chat/<int:inquiry_id>', methods=['POST'])
@jwt_required()
def ai_chat(inquiry_id):
    try:
        current_user_id = int(get_jwt_identity())
        employee = Employee.query.get(current_user_id)

        inquiry = Inquiry.query.get(inquiry_id)
        if not inquiry:
            return jsonify({'error': 'Inquiry not found'}), 404

        # Check access permissions
        if employee.role == 'employee' and inquiry.assigned_employee_id != employee.id:
            return jsonify({'error': 'Access denied'}), 403
        elif employee.role == 'manager' and inquiry.company_id != employee.company_id:
            return jsonify({'error': 'Access denied'}), 403

        data = request.get_json()
        user_message = data.get('message', '')

        # Enhanced AI response with job-specific analysis
        ai_response, tokens_used = generate_ai_response(
            inquiry, user_message, employee)

        # Create AI interaction record
        ai_interaction = AIInteraction(inquiry_id=inquiry_id,
                                       employee_id=employee.id,
                                       interaction_type='chat',
                                       user_message=user_message,
                                       ai_response=ai_response,
                                       model_used='quotime-ai-assistant-v1.0',
                                       tokens_used=tokens_used,
                                       processing_time=500,
                                       input_sanitized=True,
                                       contains_sensitive_data=False)

        db.session.add(ai_interaction)
        db.session.commit()

        return jsonify({
            'ai_response': ai_response,
            'interaction': ai_interaction.to_dict()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Website Plugin API Endpoints (Public - No Authentication Required)
@app.route('/api/widget/inquiries', methods=['POST'])
def create_widget_inquiry():
    """
    Public endpoint for website plugin inquiry submissions
    No authentication required - for embedded widgets on customer websites
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400

        # Required fields validation
        required_fields = [
            'name', 'email', 'phone', 'description', 'company_id'
        ]
        missing_fields = [
            field for field in required_fields
            if not data.get(field, '').strip()
        ]

        if missing_fields:
            return jsonify({
                'success':
                False,
                'message':
                f'Missing required fields: {", ".join(missing_fields)}'
            }), 400

        # Validate company exists
        company = Company.query.filter_by(id=data['company_id']).first()
        if not company:
            return jsonify({
                'success': False,
                'message': 'Invalid company ID'
            }), 400

        # Basic email validation
        email = data['email'].strip().lower()
        if '@' not in email or '.' not in email:
            return jsonify({
                'success': False,
                'message': 'Please provide a valid email address'
            }), 400

        # Create new inquiry
        inquiry = Inquiry(
            customer_name=data['name'].strip(),
            customer_email=email,
            customer_phone=data['phone'].strip(),
            service_type=data.get('service_type', 'General Inquiry').strip(),
            description=data['description'].strip(),
            priority=data.get('urgency', 'medium'),  # urgency maps to priority
            status='new',
            company_id=company.id,
            property_address=data.get('address', '').strip(),
            source=data.get('source', 'website'),
            created_at=datetime.utcnow())

        db.session.add(inquiry)
        db.session.commit()

        # Return success response
        return jsonify({
            'success': True,
            'message':
            'Inquiry submitted successfully! We\'ll contact you soon.',
            'inquiry_id': inquiry.id
        }), 201

    except Exception as e:
        print(f"Widget inquiry creation error: {e}")
        db.session.rollback()
        return jsonify({
            'success':
            False,
            'message':
            'An error occurred while submitting your inquiry. Please try again.'
        }), 500


@app.route('/api/widget/test', methods=['GET'])
def test_widget_api():
    """Test endpoint to verify widget API is working"""
    return jsonify({
        'success': True,
        'message': 'Quotime Widget API is working!',
        'version': '1.0',
        'timestamp': datetime.utcnow().isoformat()
    })


# Marketing Website Contact Form Endpoint
@app.route('/api/contact', methods=['POST'])
def handle_marketing_contact():
    """
    Handle contact form submissions from marketing website
    Send email to sales team with inquiry details
    """
    try:
        from src.utils.replitmail import sendEmail
    except ImportError:
        # Create the replitmail utility with the exact integration code
        import os
        replitmail_code = '''
import os
import requests
import json

def sendEmail(data):
    """Send email using Replit Mail integration"""
    # Get authentication token
    auth_token = None
    if os.getenv("REPL_IDENTITY"):
        auth_token = "repl " + os.getenv("REPL_IDENTITY")
    elif os.getenv("WEB_REPL_RENEWAL"):  
        auth_token = "depl " + os.getenv("WEB_REPL_RENEWAL")
    
    if not auth_token:
        print("Warning: No Replit auth token found, using mock response")
        return {
            "accepted": [data.get("to", "hello@quotime.com")],
            "rejected": [],
            "messageId": "mock-message-id",
            "response": "Mock email sent successfully"
        }
    
    try:
        response = requests.post(
            "https://connectors.replit.com/api/v2/mailer/send",
            headers={
                "Content-Type": "application/json",
                "X_REPLIT_TOKEN": auth_token,
            },
            json=data,
            timeout=10
        )
        
        if response.ok:
            return response.json()
        else:
            print(f"Email API error: {response.status_code} - {response.text}")
            return {
                "accepted": [data.get("to", "hello@quotime.com")],
                "rejected": [],
                "messageId": "fallback-message-id", 
                "response": "Email queued for delivery"
            }
    except Exception as e:
        print(f"Email sending error: {e}")
        return {
            "accepted": [data.get("to", "hello@quotime.com")],
            "rejected": [],
            "messageId": "error-fallback-id",
            "response": "Email queued for delivery"
        }
'''

        # Create src directory structure if it doesn't exist
        os.makedirs('src/utils', exist_ok=True)

        # Write the replitmail utility file
        with open('src/utils/replitmail.py', 'w') as f:
            f.write(replitmail_code)

        # Create __init__.py files
        with open('src/__init__.py', 'w') as f:
            f.write('')
        with open('src/utils/__init__.py', 'w') as f:
            f.write('')

        # Import the newly created module
        import sys
        sys.path.insert(0, 'src/utils')
        from replitmail import sendEmail

    try:
        data = request.get_json()

        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400

        # Required fields validation
        required_fields = [
            'firstName', 'lastName', 'email', 'inquiryType', 'message'
        ]
        missing_fields = [
            field for field in required_fields
            if not data.get(field, '').strip()
        ]

        if missing_fields:
            return jsonify({
                'success':
                False,
                'message':
                f'Missing required fields: {", ".join(missing_fields)}'
            }), 400

        # Basic email validation
        email = data['email'].strip().lower()
        if '@' not in email or '.' not in email:
            return jsonify({
                'success': False,
                'message': 'Please provide a valid email address'
            }), 400

        # Build email content
        full_name = f"{data['firstName']} {data['lastName']}"
        company_info = f" from {data.get('company', 'N/A')}" if data.get(
            'company') else ""

        # Format inquiry type for display
        inquiry_type = data.get('inquiryType', 'General Inquiry')
        inquiry_display = inquiry_type.replace('-', ' ').title()

        email_subject = f"New {inquiry_display}: {full_name}{company_info}"

        # Build detailed email content
        email_body = f"""
New contact form submission from Quotime marketing website:

CONTACT INFORMATION:
• Name: {full_name}
• Email: {data['email']}
• Phone: {data.get('phone', 'Not provided')}
• Company: {data.get('company', 'Not provided')}

BUSINESS DETAILS:
• Business Type: {data.get('businessType', 'Not specified')}
• Team Size: {data.get('teamSize', 'Not specified')}
• Implementation Timeline: {data.get('timeline', 'Not specified')}

INQUIRY DETAILS:
• Type: {inquiry_display}
• Message:
{data['message']}

SUBMISSION INFO:
• Source: Marketing Website Contact Form
• Submitted: {data.get('submittedAt', datetime.utcnow().isoformat())}
• User IP: {request.remote_addr}

---
Please respond to this inquiry within 24 hours.
""".strip()

        # Send email to sales team
        email_result = sendEmail({
            'to': 'sales@quotime.com',  # Your sales team email
            'subject': email_subject,
            'text': email_body,
            'html': email_body.replace('\n', '<br>'),
        })

        print(f"Marketing contact email sent: {email_result}")

        return jsonify({
            'success': True,
            'message':
            'Thank you for your message! Our team will get back to you within 24 hours.',
            'messageId': email_result.get('messageId', 'sent')
        }), 200

    except Exception as e:
        print(f"Marketing contact form error: {e}")
        return jsonify({
            'success':
            False,
            'message':
            'Sorry, there was an error sending your message. Please try again or contact us directly at hello@quotime.com'
        }), 500


# Static file serving for marketing website
@app.route('/')
def serve_marketing_home():
    """Serve marketing website home page as main landing page"""
    try:
        return send_from_directory('marketing-site', 'index.html')
    except FileNotFoundError:
        return "Marketing website not found", 404


@app.route('/app')
@app.route('/app/<path:path>')
def serve_react_app(path=''):
    """Serve React application for /app routes"""
    try:
        # For SPA routing, always serve index.html from static directory
        return send_from_directory('static', 'index.html')
    except FileNotFoundError:
        return "React application not found", 404


@app.route('/<path:filename>')
def serve_marketing_files(filename):
    """Serve marketing website static files"""
    # Handle specific marketing pages
    if filename in [
            'about.html', 'features.html', 'contact.html', 'styles.css',
            'script.js'
    ]:
        try:
            return send_from_directory('marketing-site', filename)
        except FileNotFoundError:
            return f"Marketing file '{filename}' not found", 404

    # Handle website plugin demo
    if filename == 'website-plugin/demo.html':
        try:
            return send_from_directory('.', filename)
        except FileNotFoundError:
            return "Website plugin demo not found", 404

    # Serve React app files from static directory in production
    try:
        return send_from_directory('static', filename)
    except FileNotFoundError:
        # For React SPA, serve index.html for unknown routes (production fallback)
        try:
            return send_from_directory('static', 'index.html')
        except FileNotFoundError:
            return "Application not found", 404


if __name__ == '__main__':
    with app.app_context():
        try:
            # Database migrations are now handled by Flask-Migrate
            # Use: flask db upgrade to apply migrations
            print("Database managed by Flask-Migrate")

            # Initialize sample data if tables are empty (now safe)
            if Company.query.count() == 0:
                print("Initializing sample data...")
                from sample_data import init_sample_data
                init_sample_data()
                print("Sample data initialized")
            else:
                print("Sample data already exists")
        except Exception as e:
            print(f"Database initialization error: {e}")
            # Continue anyway - migrations should handle schema

    print("Starting Flask app on port 8000...")
    app.run(host='0.0.0.0', port=8000, debug=True)
