/**
 * Quotaible Website Plugin v1.0
 * Embeddable contact form and chat widget for service businesses
 * 
 * Usage:
 * <script src="quotime-widget.js"></script>
 * <script>
 *   QuotaibleWidget.init({
 *     companyId: 'your-company-id',
 *     apiUrl: 'https://your-quotime-instance.com/api',
 *     theme: 'light', // 'light' or 'dark'
 *     widget: 'contact-form', // 'contact-form' or 'chat-widget'
 *     position: 'bottom-right' // for chat widget
 *   });
 * </script>
 */

(function(window, document) {
  'use strict';

  // Prevent multiple initializations
  if (window.QuotaibleWidget) {
    return;
  }

  // Widget configuration
  let config = {
    companyId: null,
    apiUrl: 'https://api.quotime.com/api',
    theme: 'light',
    widget: 'contact-form',
    position: 'bottom-right',
    title: 'Get a Quote',
    description: 'Tell us about your project and we\'ll get back to you quickly!',
    services: ['Plumbing', 'Electrical', 'HVAC', 'General Repair', 'Other'],
    privacy: 'We respect your privacy and will never share your information.',
    submitText: 'Request Quote',
    successMessage: 'Thank you! We\'ll contact you soon.',
    errorMessage: 'Sorry, there was an error. Please try again.'
  };

  // Widget instance
  let widgetInstance = null;
  let isVisible = false;

  /**
   * Main QuotaibleWidget object
   */
  const QuotaibleWidget = {
    /**
     * Initialize the widget
     */
    init: function(options) {
      if (options) {
        config = Object.assign(config, options);
      }

      if (!config.companyId) {
        console.error('QuotaibleWidget: companyId is required');
        return;
      }

      // Wait for DOM to be ready
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', this._initializeWidget.bind(this));
      } else {
        this._initializeWidget();
      }
    },

    /**
     * Show the widget
     */
    show: function() {
      if (widgetInstance) {
        widgetInstance.style.display = 'block';
        widgetInstance.style.opacity = '1';
        widgetInstance.style.transform = config.widget === 'chat-widget' 
          ? 'translateY(0)' : 'scale(1)';
        isVisible = true;
      }
    },

    /**
     * Hide the widget
     */
    hide: function() {
      if (widgetInstance) {
        widgetInstance.style.opacity = '0';
        widgetInstance.style.transform = config.widget === 'chat-widget' 
          ? 'translateY(100%)' : 'scale(0.95)';
        isVisible = false;
        setTimeout(() => {
          if (widgetInstance) widgetInstance.style.display = 'none';
        }, 300);
      }
    },

    /**
     * Toggle widget visibility
     */
    toggle: function() {
      if (isVisible) {
        this.hide();
      } else {
        this.show();
      }
    },

    /**
     * Destroy the widget
     */
    destroy: function() {
      if (widgetInstance && widgetInstance.parentNode) {
        widgetInstance.parentNode.removeChild(widgetInstance);
        widgetInstance = null;
        isVisible = false;
      }
    },

    /**
     * Initialize the widget based on configuration
     */
    _initializeWidget: function() {
      // Inject CSS
      this._injectStyles();

      // Create widget based on type
      if (config.widget === 'chat-widget') {
        this._createChatWidget();
      } else {
        this._createContactForm();
      }
    },

    /**
     * Create contact form widget
     */
    _createContactForm: function() {
      const container = document.createElement('div');
      container.id = 'quotime-contact-form';
      container.className = `quotime-widget quotime-contact-form quotime-theme-${config.theme}`;
      
      container.innerHTML = `
        <div class="quotime-form-container">
          <div class="quotime-form-header">
            <h3 class="quotime-form-title">${config.title}</h3>
            <p class="quotime-form-description">${config.description}</p>
          </div>
          
          <form class="quotime-form" id="quotime-form">
            <div class="quotime-form-row">
              <div class="quotime-form-group">
                <label for="quotime-name">Full Name *</label>
                <input type="text" id="quotime-name" name="name" required>
              </div>
              
              <div class="quotime-form-group">
                <label for="quotime-email">Email *</label>
                <input type="email" id="quotime-email" name="email" required>
              </div>
            </div>
            
            <div class="quotime-form-row">
              <div class="quotime-form-group">
                <label for="quotime-phone">Phone Number *</label>
                <input type="tel" id="quotime-phone" name="phone" required>
              </div>
              
              <div class="quotime-form-group">
                <label for="quotime-service">Service Type *</label>
                <select id="quotime-service" name="service_type" required>
                  <option value="">Select Service</option>
                  ${config.services.map(service => 
                    `<option value="${service}">${service}</option>`
                  ).join('')}
                </select>
              </div>
            </div>
            
            <div class="quotime-form-group">
              <label for="quotime-address">Property Address</label>
              <input type="text" id="quotime-address" name="address" placeholder="Street address, city, state">
            </div>
            
            <div class="quotime-form-group">
              <label for="quotime-description">Project Description *</label>
              <textarea id="quotime-description" name="description" rows="4" 
                placeholder="Please describe your project, timeline, and any specific requirements..." required></textarea>
            </div>
            
            <div class="quotime-form-group">
              <label for="quotime-urgency">Urgency Level</label>
              <select id="quotime-urgency" name="urgency">
                <option value="low">No Rush</option>
                <option value="medium" selected>Within a Week</option>
                <option value="high">ASAP / Emergency</option>
              </select>
            </div>
            
            <div class="quotime-form-actions">
              <button type="submit" class="quotime-submit-btn">
                <span class="quotime-btn-text">${config.submitText}</span>
                <span class="quotime-btn-loader" style="display: none;">Submitting...</span>
              </button>
            </div>
            
            <div class="quotime-form-footer">
              <p class="quotime-privacy">${config.privacy}</p>
            </div>
          </form>
          
          <div class="quotime-form-success" id="quotime-success" style="display: none;">
            <div class="quotime-success-icon">✓</div>
            <h3>Thank You!</h3>
            <p>${config.successMessage}</p>
          </div>
          
          <div class="quotime-form-error" id="quotime-error" style="display: none;">
            <div class="quotime-error-icon">⚠</div>
            <p>${config.errorMessage}</p>
            <button class="quotime-retry-btn" onclick="QuotaibleWidget._resetForm()">Try Again</button>
          </div>
        </div>
      `;

      // Append to body
      document.body.appendChild(container);
      widgetInstance = container;

      // Attach event listeners
      this._attachFormListeners();
      
      // Show widget
      this.show();
    },

    /**
     * Create chat widget
     */
    _createChatWidget: function() {
      // Chat toggle button
      const toggleBtn = document.createElement('div');
      toggleBtn.id = 'quotime-chat-toggle';
      toggleBtn.className = `quotime-chat-toggle quotime-position-${config.position} quotime-theme-${config.theme}`;
      toggleBtn.innerHTML = `
        <div class="quotime-chat-icon">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z"/>
          </svg>
        </div>
      `;

      // Chat container
      const chatContainer = document.createElement('div');
      chatContainer.id = 'quotime-chat-container';
      chatContainer.className = `quotime-chat-container quotime-position-${config.position} quotime-theme-${config.theme}`;
      chatContainer.style.display = 'none';
      
      chatContainer.innerHTML = `
        <div class="quotime-chat-header">
          <h4>${config.title}</h4>
          <button class="quotime-chat-close" onclick="QuotaibleWidget.hide()">×</button>
        </div>
        
        <div class="quotime-chat-body">
          <div class="quotime-chat-intro">
            <p>${config.description}</p>
          </div>
          
          <form class="quotime-chat-form" id="quotime-chat-form">
            <div class="quotime-chat-input-group">
              <input type="text" name="name" placeholder="Your name" required>
              <input type="email" name="email" placeholder="Email address" required>
              <input type="tel" name="phone" placeholder="Phone number" required>
            </div>
            
            <div class="quotime-chat-input-group">
              <select name="service_type" required>
                <option value="">Service needed</option>
                ${config.services.map(service => 
                  `<option value="${service}">${service}</option>`
                ).join('')}
              </select>
            </div>
            
            <div class="quotime-chat-input-group">
              <textarea name="description" rows="3" placeholder="Describe your project..." required></textarea>
            </div>
            
            <button type="submit" class="quotime-chat-submit">
              Send Message
            </button>
          </form>
        </div>
      `;

      // Append both elements
      document.body.appendChild(toggleBtn);
      document.body.appendChild(chatContainer);
      
      widgetInstance = chatContainer;

      // Toggle functionality
      toggleBtn.addEventListener('click', this.toggle.bind(this));

      // Attach form listeners
      this._attachChatListeners();
    },

    /**
     * Attach event listeners to contact form
     */
    _attachFormListeners: function() {
      const form = document.getElementById('quotime-form');
      if (form) {
        form.addEventListener('submit', this._handleFormSubmit.bind(this));
      }
    },

    /**
     * Attach event listeners to chat widget
     */
    _attachChatListeners: function() {
      const form = document.getElementById('quotime-chat-form');
      if (form) {
        form.addEventListener('submit', this._handleChatSubmit.bind(this));
      }
    },

    /**
     * Handle contact form submission
     */
    _handleFormSubmit: function(e) {
      e.preventDefault();
      
      const form = e.target;
      const formData = new FormData(form);
      const data = {};
      
      for (let [key, value] of formData.entries()) {
        data[key] = value;
      }
      
      // Add company ID and source
      data.company_id = config.companyId;
      data.source = 'website-plugin';
      data.widget_type = 'contact-form';

      this._submitInquiry(data, form);
    },

    /**
     * Handle chat widget submission
     */
    _handleChatSubmit: function(e) {
      e.preventDefault();
      
      const form = e.target;
      const formData = new FormData(form);
      const data = {};
      
      for (let [key, value] of formData.entries()) {
        data[key] = value;
      }
      
      // Add company ID and source
      data.company_id = config.companyId;
      data.source = 'website-plugin';
      data.widget_type = 'chat-widget';

      this._submitInquiry(data, form);
    },

    /**
     * Submit inquiry to API
     */
    _submitInquiry: function(data, form) {
      // Show loading state
      const submitBtn = form.querySelector('button[type="submit"]');
      const btnText = submitBtn.querySelector('.quotime-btn-text') || submitBtn;
      const btnLoader = submitBtn.querySelector('.quotime-btn-loader');
      
      if (btnText) btnText.style.display = 'none';
      if (btnLoader) btnLoader.style.display = 'inline';
      submitBtn.disabled = true;

      // Make API request
      fetch(`${config.apiUrl}/inquiries`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(result => {
        if (result.success) {
          this._showSuccess();
        } else {
          throw new Error(result.message || 'Submission failed');
        }
      })
      .catch(error => {
        console.error('QuotaibleWidget submission error:', error);
        this._showError();
      })
      .finally(() => {
        // Reset button state
        if (btnText) btnText.style.display = 'inline';
        if (btnLoader) btnLoader.style.display = 'none';
        submitBtn.disabled = false;
      });
    },

    /**
     * Show success message
     */
    _showSuccess: function() {
      const form = document.querySelector('.quotime-form') || document.querySelector('.quotime-chat-form');
      const success = document.getElementById('quotime-success');
      
      if (form) form.style.display = 'none';
      if (success) success.style.display = 'block';

      // Auto-hide chat widget after success
      if (config.widget === 'chat-widget') {
        setTimeout(() => {
          this.hide();
          this._resetForm();
        }, 3000);
      }
    },

    /**
     * Show error message
     */
    _showError: function() {
      const form = document.querySelector('.quotime-form') || document.querySelector('.quotime-chat-form');
      const error = document.getElementById('quotime-error');
      
      if (form) form.style.display = 'none';
      if (error) error.style.display = 'block';
    },

    /**
     * Reset form to initial state
     */
    _resetForm: function() {
      const form = document.querySelector('.quotime-form') || document.querySelector('.quotime-chat-form');
      const success = document.getElementById('quotime-success');
      const error = document.getElementById('quotime-error');
      
      if (form) {
        form.style.display = 'block';
        form.reset();
      }
      if (success) success.style.display = 'none';
      if (error) error.style.display = 'none';
    },

    /**
     * Inject CSS styles
     */
    _injectStyles: function() {
      if (document.getElementById('quotime-widget-styles')) {
        return;
      }

      const styles = document.createElement('style');
      styles.id = 'quotime-widget-styles';
      styles.textContent = this._getWidgetStyles();
      document.head.appendChild(styles);
    },

    /**
     * Get widget CSS styles
     */
    _getWidgetStyles: function() {
      return `
        /* Quotaible Widget Base Styles */
        .quotime-widget * {
          box-sizing: border-box;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        /* Contact Form Styles */
        .quotime-contact-form {
          max-width: 600px;
          margin: 40px auto;
          background: #ffffff;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          transition: all 0.3s ease;
        }

        .quotime-theme-dark .quotime-contact-form {
          background: #1e293b;
          color: #f1f5f9;
        }

        .quotime-form-container {
          padding: 32px;
        }

        .quotime-form-header {
          text-align: center;
          margin-bottom: 32px;
        }

        .quotime-form-title {
          font-size: 24px;
          font-weight: 700;
          color: #1e293b;
          margin: 0 0 8px 0;
        }

        .quotime-theme-dark .quotime-form-title {
          color: #f1f5f9;
        }

        .quotime-form-description {
          color: #64748b;
          font-size: 16px;
          margin: 0;
          line-height: 1.5;
        }

        .quotime-theme-dark .quotime-form-description {
          color: #94a3b8;
        }

        .quotime-form-row {
          display: flex;
          gap: 16px;
          margin-bottom: 16px;
        }

        .quotime-form-group {
          flex: 1;
          margin-bottom: 16px;
        }

        .quotime-form-group label {
          display: block;
          font-weight: 600;
          color: #374151;
          margin-bottom: 6px;
          font-size: 14px;
        }

        .quotime-theme-dark .quotime-form-group label {
          color: #f1f5f9;
        }

        .quotime-form-group input,
        .quotime-form-group select,
        .quotime-form-group textarea {
          width: 100%;
          padding: 12px;
          border: 1px solid #d1d5db;
          border-radius: 6px;
          font-size: 16px;
          transition: all 0.2s ease;
          background: #ffffff;
          color: #1f2937;
        }

        .quotime-theme-dark .quotime-form-group input,
        .quotime-theme-dark .quotime-form-group select,
        .quotime-theme-dark .quotime-form-group textarea {
          background: #334155;
          border-color: #475569;
          color: #f1f5f9;
        }

        .quotime-form-group input:focus,
        .quotime-form-group select:focus,
        .quotime-form-group textarea:focus {
          outline: none;
          border-color: #3b82f6;
          box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .quotime-submit-btn {
          width: 100%;
          background: #3b82f6;
          color: white;
          border: none;
          padding: 14px 24px;
          border-radius: 8px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s ease;
          position: relative;
        }

        .quotime-submit-btn:hover {
          background: #2563eb;
          transform: translateY(-1px);
        }

        .quotime-submit-btn:disabled {
          background: #94a3b8;
          cursor: not-allowed;
          transform: none;
        }

        .quotime-form-footer {
          margin-top: 20px;
          text-align: center;
        }

        .quotime-privacy {
          font-size: 12px;
          color: #6b7280;
          margin: 0;
        }

        .quotime-theme-dark .quotime-privacy {
          color: #9ca3af;
        }

        /* Success/Error States */
        .quotime-form-success,
        .quotime-form-error {
          text-align: center;
          padding: 40px 20px;
        }

        .quotime-success-icon,
        .quotime-error-icon {
          width: 60px;
          height: 60px;
          margin: 0 auto 20px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          font-weight: bold;
        }

        .quotime-success-icon {
          background: #10b981;
          color: white;
        }

        .quotime-error-icon {
          background: #ef4444;
          color: white;
        }

        .quotime-retry-btn {
          background: #ef4444;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 6px;
          cursor: pointer;
          margin-top: 12px;
        }

        /* Chat Widget Styles */
        .quotime-chat-toggle {
          position: fixed;
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: #3b82f6;
          color: white;
          border: none;
          cursor: pointer;
          z-index: 10000;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
          transition: all 0.3s ease;
        }

        .quotime-chat-toggle:hover {
          transform: scale(1.1);
          background: #2563eb;
        }

        .quotime-position-bottom-right {
          bottom: 20px;
          right: 20px;
        }

        .quotime-position-bottom-left {
          bottom: 20px;
          left: 20px;
        }

        .quotime-chat-container {
          position: fixed;
          width: 350px;
          height: 500px;
          background: white;
          border-radius: 12px;
          box-shadow: 0 8px 40px rgba(0, 0, 0, 0.15);
          z-index: 9999;
          display: flex;
          flex-direction: column;
          transform: translateY(100%);
          opacity: 0;
          transition: all 0.3s ease;
        }

        .quotime-chat-container.quotime-position-bottom-right {
          bottom: 90px;
          right: 20px;
        }

        .quotime-chat-container.quotime-position-bottom-left {
          bottom: 90px;
          left: 20px;
        }

        .quotime-theme-dark .quotime-chat-container {
          background: #1e293b;
          color: #f1f5f9;
        }

        .quotime-chat-header {
          padding: 16px;
          background: #3b82f6;
          color: white;
          border-radius: 12px 12px 0 0;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }

        .quotime-chat-header h4 {
          margin: 0;
          font-size: 16px;
          font-weight: 600;
        }

        .quotime-chat-close {
          background: none;
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          padding: 0;
          width: 24px;
          height: 24px;
        }

        .quotime-chat-body {
          padding: 16px;
          flex: 1;
          overflow-y: auto;
        }

        .quotime-chat-intro {
          margin-bottom: 16px;
        }

        .quotime-chat-intro p {
          margin: 0;
          color: #64748b;
          font-size: 14px;
          line-height: 1.5;
        }

        .quotime-theme-dark .quotime-chat-intro p {
          color: #94a3b8;
        }

        .quotime-chat-input-group {
          margin-bottom: 12px;
        }

        .quotime-chat-form input,
        .quotime-chat-form select,
        .quotime-chat-form textarea {
          width: 100%;
          padding: 10px;
          border: 1px solid #d1d5db;
          border-radius: 6px;
          font-size: 14px;
          margin-bottom: 8px;
        }

        .quotime-theme-dark .quotime-chat-form input,
        .quotime-theme-dark .quotime-chat-form select,
        .quotime-theme-dark .quotime-chat-form textarea {
          background: #334155;
          border-color: #475569;
          color: #f1f5f9;
        }

        .quotime-chat-submit {
          width: 100%;
          background: #3b82f6;
          color: white;
          border: none;
          padding: 12px;
          border-radius: 6px;
          font-weight: 600;
          cursor: pointer;
        }

        .quotime-chat-submit:hover {
          background: #2563eb;
        }

        /* Responsive Design */
        @media (max-width: 640px) {
          .quotime-contact-form {
            margin: 20px;
            max-width: none;
          }
          
          .quotime-form-container {
            padding: 20px;
          }
          
          .quotime-form-row {
            flex-direction: column;
            gap: 0;
          }
          
          .quotime-chat-container {
            width: calc(100vw - 40px);
            height: calc(100vh - 40px);
            bottom: 20px;
            right: 20px;
            left: 20px;
          }
          
          .quotime-chat-container.quotime-position-bottom-left {
            right: 20px;
          }
        }
      `;
    }
  };

  // Expose to global scope
  window.QuotaibleWidget = QuotaibleWidget;

})(window, document);