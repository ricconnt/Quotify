"""
Configuration settings for Quotaible Flask application
"""
import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Base configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'stable-dev-secret-key-do-not-change-in-dev')
    
    # Handle PostgreSQL SSL connection issues
    database_url = os.environ.get('DATABASE_URL')
    if database_url:
        # Convert postgres:// to postgresql:// if needed
        if database_url.startswith('postgres://'):
            database_url = database_url.replace('postgres://', 'postgresql://', 1)
        
        # Add SSL configuration to prevent connection issues
        if 'sslmode' not in database_url and database_url.startswith('postgresql://'):
            database_url += '?sslmode=prefer'
    
    SQLALCHEMY_DATABASE_URI = database_url
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'stable-jwt-secret-key-do-not-change-in-dev')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)
    
    @staticmethod
    def validate_production_config():
        """Validate that production secrets are set"""
        required_vars = ['SECRET_KEY', 'JWT_SECRET_KEY', 'DATABASE_URL']
        missing = [var for var in required_vars if not os.environ.get(var)]
        if missing:
            raise ValueError(f"Missing required environment variables: {missing}")